package com.concord.internationaldesk.pages;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;
import com.concord.internationaldesk.pages.SearchDossierPage;
import com.concord.internationaldesk.constants.ImportDocumentPageObjects;


public class ImportDocumentPage extends BasePage {
	
	@FindBy(xpath=ImportDocumentPageObjects.IMPORTDOCUMENT_LABLE)
	protected WebElement importdocument_l;
	
	@FindBy(xpath=ImportDocumentPageObjects.IMPORT_DOCUMENT_BUTTON)
	protected WebElement import_Document_b;
	
	@FindBy(xpath=ImportDocumentPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName;

	@FindBy(xpath=ImportDocumentPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_ta;

	@FindBy(xpath=ImportDocumentPageObjects.T24_ACCOUNT_ID)
	protected WebElement T24_account_id;
	
	@FindBy(xpath=ImportDocumentPageObjects.T24_CUSTOMER_ID)
	protected WebElement T24_customer_id ;
	
	@FindBy(xpath=ImportDocumentPageObjects.T24_CONTRACT_ID)
	protected WebElement T24_contract_id;
	
	@FindBy(xpath=ImportDocumentPageObjects.REMOVE_BUTTON)
	protected WebElement remove;
	
	@FindBy(xpath=ImportDocumentPageObjects.SUBMIT_BUTTON)
	protected static WebElement submit_b;
	
	@FindBy(xpath=ImportDocumentPageObjects.CANCEL_BUTTON)
	protected WebElement cancel;
	
	@FindBy(xpath=ImportDocumentPageObjects.ADD_DOCUMENT_BUTTON)
	protected WebElement addDocument;
	
	@FindBy(xpath=ImportDocumentPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected static WebElement returnToSearchScreen;
	
	@FindBy(xpath = ImportDocumentPageObjects.DROP_FILE_AREA)
	protected static WebElement dropFile_A;
	
	
	public ImportDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
		Thread.sleep(2000);
	} 
	
	public void importDocument(String documentName, String documentType) {
		DropFile(new File(System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
				dropFile_A, 0, 0);
		Actions action = new Actions(driver);
		action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		submit_b.click();
	}
	
	public void isAllTheElementsInImportDocumentsIsDisplayed(String documentPath ,String documenttype) throws IOException
	{
		import_Document_b.click();
		
		Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\AutoItScripts\\UploadDocument.exe"+" "+System.getProperty("user.dir")+"\\ExtentReports\\Snapshots\\UploadFiles\\"+"Scanner.png");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		documentType_ta.click();
		documentType_ta.sendKeys(documenttype);
		submit_b.click();
	}
	
	public static SearchDossierPage navigateToSearchDossierScreen() throws InterruptedException, AWTException, IOException
	{
		waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		returnToSearchScreen.click();
		waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		return new SearchDossierPage(driver);
	}
	
	public static void submitDossierAndDocuments() {
		submit_b.click();
	}
	
}
