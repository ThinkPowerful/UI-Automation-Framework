package com.concord.internationaldesk.constants;

import com.concord.base.constants.BasePageObjects;

public class SearchDocumentObjects extends BasePageObjects{
	
	

}
