package com.concord.internationaldesk.constants;

public class UpdateDossierPageObjects {
	
	public static final String T24_CUSTOMER_ID_TEXTFIELD = "//input[@id='customerNumber']";
	public static final String T24_ACCOUNT_ID_TEXTFIELD = "//input[@id='accNumber']";
	public static final String T24_CONTRACT_ID_TEXTFIELD = "//input[@id='crcNumber']";
	public static final String LENS_ICON_BUTTON = "//span[@title='Search Customer']";
	public static final String RESET_BUTTON = "//button[text()='Reset']";
	public static final String VALIDATE_BUTTON = "//button[text()='Validate']";
	public static final String COUNTRY_DROP_DOWN="//select[@id='countryId']";
	public static final String TYPE_PRODUCT_BUTTON = "(//label[contains(normalize-space(.),'Product')])[1]";
	public static final String TYPE_PROCESS_BUTTON = "//label[contains(normalize-space(.),'Process')]";
	public static final String DESCRIPTION_TEXTFIELD = "//input[@id='description']";
	public static final String CANCEL_BUTTON = "//button[text()='Cancel']";
	public static final String SUBMIT_BUTTON = "//button[text()='Submit']";
	public static final String RETURN_TO_SEARCH_SCREEN_BUTTON = "//button[text()='Return to Search Screen']";
	public static final String DESCRIPTION_CLIENT_NAME_TEXTFIELD = "//input[@id='clientName']";
	
	

}
