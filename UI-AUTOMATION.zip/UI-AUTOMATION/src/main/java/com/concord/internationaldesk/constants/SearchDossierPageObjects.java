package com.concord.internationaldesk.constants;

public class SearchDossierPageObjects {
	//International desk SearchDossierPage
	public static final String DOSSIER_TAB	=	"//button[@href='/gdc/web/client/dossiers']";
	public static final String CUSTOMER_ADMIN_TYPE_DROPDOWN =	"//select[@ng-model='searchObject.adminType']";
	public static final String IDENTIFIER_TEXTFIELD =	"//input[@id='identifier']";
	public static final String SEARCH_BUTTON =	"//button[text()='Search']";
	public static final String T24_CUSTOMERID_VALIDATION_MESSAGES =	"//p[@class='help-block ng-scope']";
	public static final String CLIENT_NAME_MESSAGE	=	"//span[contains(text(),'Please provide atleast 3 characters')]";
	public static final String CREATE_DOSSIER_BUTTON = "//span[@title='Create dossier']";
	public static final String DOSSIER_METADATA_INFO_BUTTON = "//div[@aria-expanded='true']//button[@ng-click='listenerCallbackViewDossierMetadata()']";
	public static final String VALID_FROM_METADATA_VALUE = "//dt[text()='Valid from']/following-sibling::dd";
	public static final String VALID_TO_METADATA_VALUE = "//dt[text()='Valid from']/following-sibling::dd";
	public static final String DOSSIER_NAME_TEXTFIELD ="//input[@placeholder='Dossier name']"; 
	public static final String FROM_DATE_TEXTFIELD = "//input[@id='fromDate']";
	public static final String TO_DATE_TEXTFIELD = "//input[@id='toDate']";
	public static final String ACTIONS_DROPDOWN ="//button[@id='actionsInDossier']";
	public static final String EDIT_OPTION = "//li[@ng-click='listenerCallbackEditDossier()']";
	public static final String CLIENTNAME_TEXTFIELD = "//input[@name='clientName']";
	public static final String T24_CUSTOMER_ID_METADATA_VALUE = "//dt[contains(text(),'T24 Customer ID')]/following-sibling::dd";
	
}
