package com.concord.internationaldesk.constants;

public class UpdateDocumentPageObjects {
	
	public static final String EDIT_DOCUMENT_TITLE = "//h2[text()='Edit information about the document']";
	public static final String DOCUMENT_NAME_TEXTFIELD = "//input[@id='fileName']";
	public static final String DOCUMENT_TYPE_TYPEAHEAD = "//input[@id='documentType']";
	public static final String T24_ACCOUNT_ID_TEXTFIELD = "//input[@id='accNumber']";
	public static final String T24_CUSTOMER_ID_TEXTFIELD = "//input[@id='customerNumber']";
	public static final String T24_CONTRACT_ID_TEXTFIELD = "//input[@id='crcNumber']";
	public static final String VALID_FROM_TEXTFIELD = "//input[@id='issueDate']";
	public static final String VALID_TO_TEXTFIELD = "//input[@id='expirationDate']";
	public static final String SCANNER_ID_TEXTFIELD = "//input[@id='scannerId']";
	public static final String CANCEL_BUTTON = "//button[text()='Cancel']";
	//public static final String CANCEL_BUTTON ="//button[@class='btn btn-default ocf-btn-cancel ng-scope']";
	public static final String SUBMIT_BUTTOM = "//button[text()='Submit']";
	public static final String RETURN_TO_SEARCH_SCREEN_BUTTON ="//button[@class='btn btn-primary ocf-btn- ng-scope']";
	public static final String FROM_DATE_VALIDATION_MESSAGE = "(//p[@ng-message='invalidDate']//span)[1]";
	public static final String TO_DATE_VALIDATION_MESSAGE = "(//p[@ng-message='invalidDate']//span)[2]";
	public static final String MANDATORY_VALIDATION_MESSAGE = "//span[text()='Please provide sufficient information about all documents and proceed']";
	public static final String DOCUMENT_TYPE_VALUE="//div[@class='panel-border']//dd[@class='ng-binding'][contains(text(),'Invoice')]";
}
