package com.concord.internationaldesk.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;

import com.concord.internationaldesk.constants.UpdateDossierPageObjects;



public class UpdateDossierPage extends BasePage{

	@FindBy(xpath=UpdateDossierPageObjects.T24_CUSTOMER_ID_TEXTFIELD)
	protected WebElement t24_customer_id_textfield;

	@FindBy(xpath=UpdateDossierPageObjects.T24_ACCOUNT_ID_TEXTFIELD)
	protected WebElement t24_account_id_textfield;

	@FindBy(xpath=UpdateDossierPageObjects.T24_CONTRACT_ID_TEXTFIELD)
	protected WebElement t24_contract_id_textfield;

	@FindBy(xpath=UpdateDossierPageObjects.LENS_ICON_BUTTON)
	protected WebElement lens_icon_b;

	@FindBy(xpath=UpdateDossierPageObjects.RESET_BUTTON)
	protected WebElement reset_b;

	@FindBy(xpath=UpdateDossierPageObjects.VALIDATE_BUTTON)
	protected WebElement validate_b;

	@FindBy(xpath=UpdateDossierPageObjects.TYPE_PRODUCT_BUTTON)
	protected WebElement typeProduct_b;

	@FindBy(xpath=UpdateDossierPageObjects.TYPE_PROCESS_BUTTON)
	protected WebElement typeProcess_b;

	@FindBy(xpath=UpdateDossierPageObjects.COUNTRY_DROP_DOWN)
	protected WebElement country_dd;

	@FindBy(xpath=UpdateDossierPageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;

	@FindBy(xpath=UpdateDossierPageObjects.SUBMIT_BUTTON)
	protected WebElement submit_b;

	@FindBy(xpath=UpdateDossierPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected static WebElement returnToSearchScreen_b;

	@FindBy(xpath=UpdateDossierPageObjects.DESCRIPTION_CLIENT_NAME_TEXTFIELD)
	protected WebElement description_cn_Tf;

	public UpdateDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void updateDossierDescription(String description)
	{
		description_cn_Tf.clear();
		description_cn_Tf.sendKeys(description);
		validate_b.click();
		submit_b.click();
	}

	public boolean isDossierUpdatedSuccessfully()
	{

		try{
			boolean updateStatusMessage = driver.findElement(By.xpath("//div[text()='Information about the dossier updated successfully']")).isDisplayed();
			return updateStatusMessage;
		}
		catch(Exception e){
			return false;
		}
	}

	public static SearchDossierPage returnToSearchScreen() throws InterruptedException, AWTException, IOException
	{
		returnToSearchScreen_b.click();
		return new SearchDossierPage(driver);
	}

	public SearchDossierPage cancelAndReturnToSearchScreen() throws InterruptedException, AWTException, IOException
	{
		cancel_b.click();
		return new SearchDossierPage(driver);
	}

	public boolean CheckdossierForClientOnboarding() {

		String name =driver.findElement(By.xpath("//dl[@ng-if='dossierMetadata.dossierName']//dt[text()='Name']/following-sibling::dd[1]")).getText(); 

		if (name.contains("Client Onboarding"))
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	public void UpdateDossierDescriptionforOthers(String description) {

		validate_b.click();
		description_cn_Tf.clear();
		description_cn_Tf.sendKeys(description);
		submit_b.click();
	}

	public void updateDossierWithT24Number(String t24customerid) {
		// TODO Auto-generated method stub
		t24_customer_id_textfield.clear();
		t24_customer_id_textfield.click();
		t24_customer_id_textfield.sendKeys(t24customerid);
		validate_b.click();
		submit_b.click();
		
		////dl[@class='custom-dl-metadata ng-scope']//div[@ng-repeat='identificationInfo in documentMetadata.relatedEntity']//dt[text()='T24 Customer ID']/following-sibling::dd[1]
	}

	public String ValidatingCustIdinDocumentInfo() {
		
		 
		driver.findElement(By.xpath("//span[@class='pull-left glyphicon ocf-icon-accordion-closed']")).click();
		
		//driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		System.out.println("doc");
		driver.findElement(By.xpath("//a[@ng-click='callViewAllMetadata()']//span[@class='drmicon drmicon-file-text2 hidden-xxs ng-scope']")).click();
		
	String T24customerNumber=driver.findElement(By.xpath("//dl[@class='custom-dl-metadata ng-scope']//div[@ng-repeat='identificationInfo in documentMetadata.relatedEntity']//dt[text()='T24 Customer ID']/following-sibling::dd[1]")).getText();
	System.out.println("num:"+T24customerNumber);
	System.out.println("doc info button");	
	return T24customerNumber;	
		

	}




}
