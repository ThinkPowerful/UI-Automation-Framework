package com.concord.internationaldesk.constants;

public class ImportDocumentPageObjects {
	
	public static final String IMPORTDOCUMENT_LABLE = "//h2[text()='Import document']";
	public static final String IMPORT_DOCUMENT_BUTTON = "//span[@title='Import document']";
    public static final String DOCUMENT_NAME_TEXTFIELD = "//input[@id='fileName']";
	public static final String DOCUMENT_TYPE_TYPEAHEAD = "(//input[@id='documentType'])[1]";
	public static final String T24_ACCOUNT_ID = "//*[@id=\"accNumber\"]";
	public static final String T24_CUSTOMER_ID = "(//input[@id='documentType'])[1]";
	public static final String T24_CONTRACT_ID = "(//input[@id='documentType'])[1]";
	public static final String STATUS = "(//*[@class='form-control font-resize ng-pristine ng-untouched ng-valid ng-scope ng-not-empty'])";
	public static final String SUBMIT_BUTTON = "//button[text()='Submit']";
	public static final String CANCEL_BUTTON = "//button[text()='Cancel']";
	public static final String ADD_DOCUMENT_BUTTON = "//button[contains(text(),'Add Document')]";
	public static final String RETURN_TO_SEARCH_SCREEN_BUTTON="//button[@class='btn btn-primary pull-right ng-binding ng-scope']";
	public static final String REMOVE_BUTTON = "//span[@title='Delete']";
	public static final String DROP_FILE_AREA = "//span[text()='Drop files here']/..//div[@role='tablist']";
	
}
