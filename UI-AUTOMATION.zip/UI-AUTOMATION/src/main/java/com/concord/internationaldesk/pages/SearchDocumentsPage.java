package com.concord.internationaldesk.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;

public class SearchDocumentsPage extends BasePage{
	
	public SearchDocumentsPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		launchConcordApplication();
		menu.selectBusinessContext("International Desk");
		menu.selectLanguage("EN");
		Thread.sleep(2000);
	}

}
