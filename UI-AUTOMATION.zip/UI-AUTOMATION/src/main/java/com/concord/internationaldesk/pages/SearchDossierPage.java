package com.concord.internationaldesk.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.internationaldesk.constants.SearchDossierPageObjects;
import com.concord.utility.DateUtil;


public class SearchDossierPage extends BasePage{

	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_TAB)
	protected WebElement dossier_tab;

	@FindBy(xpath=SearchDossierPageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;

	@FindBy(xpath=SearchDossierPageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;
	
	@FindBy(xpath=SearchDossierPageObjects.CLIENTNAME_TEXTFIELD)
	protected WebElement clientName_Tf;

	@FindBy(xpath=SearchDossierPageObjects.SEARCH_BUTTON)
	public WebElement search_b;

	@FindBy(xpath=SearchDossierPageObjects.T24_CUSTOMERID_VALIDATION_MESSAGES)
	protected WebElement t24CustomerIdvalidationMessages_m;

	@FindBy(xpath=SearchDossierPageObjects.CLIENT_NAME_MESSAGE)
	protected WebElement clientName_message;

	@FindBy(xpath=SearchDossierPageObjects.CREATE_DOSSIER_BUTTON)
	protected static WebElement createDossier_b;

	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_METADATA_INFO_BUTTON)
	protected WebElement dossierMetadataInfo_b;

	@FindBy(xpath=SearchDossierPageObjects.VALID_FROM_METADATA_VALUE)
	protected WebElement validFromMetadata_v;

	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_NAME_TEXTFIELD)
	protected WebElement dossierName_Tf;


	@FindBy(xpath=SearchDossierPageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;

	@FindBy(xpath=SearchDossierPageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;

	@FindBy(xpath=SearchDossierPageObjects.ACTIONS_DROPDOWN)
	protected static List<WebElement> actions_dd;

	@FindBy(xpath=SearchDossierPageObjects.EDIT_OPTION)
	protected static List<WebElement> edit_o;


	@FindBy(xpath=SearchDossierPageObjects.VALID_TO_METADATA_VALUE)
	protected WebElement validToMetadata_v;
	
	@FindBy(xpath=SearchDossierPageObjects.T24_CUSTOMER_ID_METADATA_VALUE)
	protected WebElement t24CustomerIDMetadata_v;

	static int openedDossier;

	public SearchDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
		dossier_tab.click();
		Thread.sleep(2000);
	}

	public static CreateDossierPage navigateToCreateDossierPage() throws InterruptedException, AWTException, IOException
	{
		createDossier_b.click();
		return new CreateDossierPage(driver);
	}
	
	public void searchDossierWithClientName(String clientName)
	{
		waitForElementToBeClickable(search_b);
		clientName_Tf.clear();
		clientName_Tf.sendKeys(clientName);
		search_b.click();
	}


	public void searchDossierWith24CustomerId(String CustomerId)
	{
			selectOptionByValue(customerAdminType_Dd, "1:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(CustomerId);
			search_b.click();
	}


	public void searchDossierWith24CustomerId(String CustomerId,String dossierName,String fromDate,String toDate)
	{
			selectOptionByValue(customerAdminType_Dd, "1:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(CustomerId);
			dossierName_Tf.clear();
			dossierName_Tf.sendKeys(dossierName);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
	}


	public void searchDossierWith24AccountId(String AccountId)
	{
			selectOptionByValue(customerAdminType_Dd, "1:account");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(AccountId);
			search_b.click();
	}

	public void searchDossierWith24CustomerIdAndClientName(String CutomerId, String ClientName)
	{
			selectOptionByValue(customerAdminType_Dd, "1:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(CutomerId);
			clientName_Tf.clear();
			clientName_Tf.sendKeys(ClientName);
			search_b.click();
	}

	public void searchDossierWith24ContractId(String ContractId)
	{
			selectOptionByValue(customerAdminType_Dd, "1:contract");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(ContractId);
			search_b.click();
	}

	public String getMandatoryValidationMessageForT24CustomerId()
	{
		wait= new WebDriverWait(driver, 3);
		wait.until(ExpectedConditions.visibilityOf(t24CustomerIdvalidationMessages_m));
		return t24CustomerIdvalidationMessages_m.getText();
	}

	public String getMandatoryValidationMessageForClinetName()
	{
		wait= new WebDriverWait(driver, 3);
		wait.until(ExpectedConditions.visibilityOf(clientName_message));
		return clientName_message.getText();
	}

	public void scrollToTop(int dossierIndex)
	{
			driver.findElement(By.xpath("(//span[text()='Scroll top'])["+dossierIndex+"]")).isDisplayed();
			singleClickOnElement(driver.findElement(By.xpath("(//span[text()='Scroll top'])["+dossierIndex+"]")));
	}

	public boolean isDossierFoundForUpdateDossier(String dossierName, String creationDate) throws ParseException
	{
		//JavascriptExecutor executor = (JavascriptExecutor)driver;
		//return (Boolean) executor.executeScript("return document.evaluate(\"//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[text()='"+dossierName+"'] and //dt[text()='Created on']/following-sibling::dd[text()='"+creationDate+"']\", document, null, XPathResult.BOOLEAN_TYPE, null).booleanValue");
		boolean isdossierFound=false;
		int listOfDossiers = driver.findElements(By.xpath("//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[contains(text(),'"+dossierName+"')]")).size();
		for(int dossierCount=0;dossierCount<listOfDossiers;dossierCount++)
		{
			driver.findElements(By.xpath("//div[contains(@class,'panel-title-wrapper cursor-click-enable ng-scope')]//span[contains(text(),'"+dossierName+"')]")).get(dossierCount).click();
			//waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
			scrollToTop(dossierCount+1);
			dossierMetadataInfo_b.click();
			String creationDateTimeActual = driver.findElement(By.xpath("//dl[@ng-if='dossierMetadata.dossierName']//dt[text()='Created on']/following-sibling::dd[1]")).getText();
			String creationDateTimeForJenkins=DateUtil.oneHourBefore(creationDate);
			if(creationDateTimeActual.equals(creationDate) || creationDateTimeActual.equals(creationDateTimeForJenkins))
			{
				//driver.findElement(By.xpath("//span[@title='Close']")).click();
				isdossierFound=true;
				openedDossier = dossierCount;
				break;
			}
			else
			{
				//driver.findElement(By.xpath("//span[@title='Close']")).click();
			}
		}
		return isdossierFound;
	}
	
	public boolean isDossierFound(String dossierName, String creationDate) throws ParseException
	{
		//JavascriptExecutor executor = (JavascriptExecutor)driver;
		//return (Boolean) executor.executeScript("return document.evaluate(\"//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[text()='"+dossierName+"'] and //dt[text()='Created on']/following-sibling::dd[text()='"+creationDate+"']\", document, null, XPathResult.BOOLEAN_TYPE, null).booleanValue");
		 boolean isdossierFound=false;
		 int listOfDossiers = driver.findElements(By.xpath("//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[contains(text(),'"+dossierName+"')]")).size();
		 for(int dossierCount=0;dossierCount<listOfDossiers;dossierCount++)
		 {
				driver.findElements(By.xpath("//div[contains(@class,'panel-title-wrapper cursor-click-enable ng-scope')]//span[contains(text(),'"+dossierName+"')]")).get(dossierCount).click();
				 waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
				 if(isElementPresent("//span[text()='Scroll top']"))
				 {
					 scrollToTop(dossierCount+1);
				 }
				 WebElement dossierMetadataInfo_b=driver.findElement(By.xpath("//span[contains(text(),'"+dossierName+"')]/../../../../../..//span[@title='Info']"));
				 dossierMetadataInfo_b.click();
				 String creationDateTimeActual = driver.findElement(By.xpath("//dl[@ng-if='dossierMetadata.dossierName']//dt[text()='Created on']/following-sibling::dd[1]")).getText();
				 if(creationDateTimeActual.contains(creationDate))
				 {
					 driver.findElement(By.xpath("//a[@ng-click='removeDocument()']")).click();
					 isdossierFound=true;
					 openedDossier = dossierCount;
					 break;
				 }
				 else
				 {
					 driver.findElement(By.xpath("//a[@ng-click='removeDocument()']")).click();
				 }
		 }
		 return isdossierFound;
	}
	
	public void expandFirstDossierInTheList(String dossierName) throws ParseException
	{
		dossierName=dossierName+"_"+DateUtil.convertDateToStringInddMMyyyy(DateUtil.getCurrentdateInddMMyyyy());
		driver.findElements(By.xpath("//div[contains(@class,'panel-title-wrapper cursor-click-enable ng-scope')]//span[contains(text(),'"+dossierName+"')]")).get(0).click();
	}
	

	public static UpdateDocumentPage navigateToUpdateDocumentPage(String documentName) throws InterruptedException, AWTException, IOException
	{
		int documents = driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+documentName+"']/../../../..//button[@id='documentInDossierActionId']")).size();
		if(documents>0){
			driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+documentName+"']/../../../..//button[@id='documentInDossierActionId']")).get(0).click();
			driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+documentName+"']/../../../..//button[@id='documentInDossierActionId']/..//span[text()='Edit information']")).get(0).click();
		}else{
			throw new NoSuchElementException();
		}
		return new UpdateDocumentPage(driver);
	}

	public void viewAllMetadataForADocument(String documentName, int documentIndex) throws InterruptedException
	{
		driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+documentName+"']/../../../..//span[@title='View metadata']")).get(documentIndex).click();
	}

	public String getDocumentMetadataValidFrom()
	{
		return validFromMetadata_v.getText();
	}

	public String getDocumentMetadataValidTo()
	{
		return validToMetadata_v.getText();
	}
	
	public String getDocumentMetadataT24CustomerID()
	{
		return t24CustomerIDMetadata_v.getText();
	}


	public static UpdateDossierPage navigateToUpdateDossierPage() throws InterruptedException, AWTException, IOException
	{
		actions_dd.get(openedDossier).click();
		driver.findElement(By.xpath("//span[@title='Edit']")).click();
		return new UpdateDossierPage(driver);
	}

}
