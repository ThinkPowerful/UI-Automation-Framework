package com.concord.internationaldesk.constants;

public class CreateDossierPageObjects {
	
	public static final String CREATEDOSSIER_CLIENT_ON_BOARDING_RADIOBUTTON ="//input[@type='radio'][1]";
	public static final String CREATEDOSSIER_OTHERS_RADIOBUTTON ="//input[@type='radio'][2]";
	public static final String OK_BUTTON ="//button[@class='btn btn-primary ng-scope']";
	public static final String CLIENT_NAME_TEXTFIELD ="//input[@id='clientName']";
	public static final String VALIDATE_BUTTON="//button[@class='btn btn-secondary-focus pull-right ng-scope']";
	public static final String CLEAR_BUTTON ="//button[text()='Clear']";
	public static final String COUNTRY_DROP_DOWN ="//*[@id='countryId']";
	public static final String PROCESS_NAME_FIELD_CAP_TYPEAHEAD ="//*[@class='form-control ng-pristine ng-untouched ng-valid-editable ng-empty ng-invalid ng-invalid-required']";
	public static final String CANCEL_BUTTON="//button[@class='btn btn-default ocf-btn-cancel ng-scope']";
	public static final String NEXT_BUTTON="//button[@class='btn btn-primary ng-scope']";
	public static final String T24_ACCOUNT_ID_TEXTFIELD ="//input[@id='accNumber']";
	public static final String T24_CUSTOMER_ID_TEXTFIELD ="//input[@id='customerNumber']";
	public static final String T24_CONTRACT_ID_TEXTFIELD="//input[@id='crcNumber']";
	public static final String PROCESS_NAME_OTHERS_TYPEHEAD="//input[@name='processName'][1]";
	public static final String CLIENT_NAME_IDENTIFICATION_MESSAGE="//span[@class='glyphicon glyphicon-ok-circle ng-scope']";
	public static final String T24_CUSTOMER_ID_IDENTIFICATION_MESSAGE="//span[@class='glyphicon glyphicon-ok-circle ng-scope']";
	public static final String PRODUCT_DOSSIER_OTHERS_TOGGLE_BUTTON="//*[@id=\"type\"]/label[2]";
	public static final String PROCESS_DOSSIER_OTHERS_TOGGLE_BUTTON = "//*[@id='type']/label[1]";
	public static final String ACTION_DROP_DOWN ="//*[@id=\"actionContextId\"]";
	public static final String PRODUCT_GROUP_DROP_DOWN="//*[@class='form-control ng-pristine ng-untouched ng-valid-editable ng-empty ng-invalid ng-invalid-required']";
	public static final String CLIENT_NAME_FOR_OTHERS="//input[@id='clientName']";
	public static final String CLIENT_NAME_VALIDATION_MESSAGE="//span[contains(text(),'Please provide atleast 3 characters')]";
	public static final String T24_CUSTOMER_ID_VALIDATION_MESSAGE ="//input[@id='customerNumber']/../../div[@id='identifier']/div/p/span";
	public static final String T24_CONTRACT_ID_VALIDATION_MESSAGE = "//span[contains(text(),'Please use only letters and/or numbers')]";
	public static final String T24_ACCOUNT_ID_VALIDATION_MESSAGE="//*[@id=\"identifier\"]/div/p/span";
	public static final String T24_CONTRACT_ID_IDENTIFICATION_MESSAGE ="//span[@class='glyphicon glyphicon-ok-circle ng-scope']";
	public static final String T24_ACCOUNT_ID_IDENTIFICATION_MESSAGE ="//span[@class='glyphicon glyphicon-ok-circle ng-scope']";
	public static final String TYPE_PROCESS_BUTTON = "(//input[@id='processOrProduct'])[1]";
	public static final String TYPE_PRODUCT_BUTTON = "//*[@id=\"type\"]/label[2]";
	public static final String NEXT_PRODUCT_BUTTON="//button[@class='btn btn-primary ng-scope']";
	public static final String DOSSIER_IDENTIFICATION_VALIDATION_MESSAGE="//form[@name='dossierIdentificationForm']//p[text()='Please provide sufficient information to proceed']";
	public static final String T24_CUSTOMERID_VALIDATION_MESSAGES="//p[@class='help-block ng-scope']";
}
