package com.concord.internationaldesk.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.internationaldesk.constants.UpdateDocumentPageObjects;

public class UpdateDocumentPage extends BasePage {

	@FindBy(xpath=UpdateDocumentPageObjects.EDIT_DOCUMENT_TITLE)
	protected WebElement editDocument_t;

	@FindBy(xpath=UpdateDocumentPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_tf;

	@FindBy(xpath=UpdateDocumentPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_ta;

	@FindBy(xpath=UpdateDocumentPageObjects.T24_ACCOUNT_ID_TEXTFIELD)
	protected WebElement t24_account_id_tf;

	@FindBy(xpath=UpdateDocumentPageObjects.T24_CUSTOMER_ID_TEXTFIELD)
	protected WebElement t24_customer_id_tf;

	@FindBy(xpath=UpdateDocumentPageObjects.T24_CONTRACT_ID_TEXTFIELD)
	protected WebElement t24_contract_id_tf;

	@FindBy(xpath=UpdateDocumentPageObjects.VALID_FROM_TEXTFIELD)
	protected WebElement validFrom_tf;

	@FindBy(xpath=UpdateDocumentPageObjects.VALID_TO_TEXTFIELD)
	protected WebElement validTo_tf;

	@FindBy(xpath=UpdateDocumentPageObjects.SCANNER_ID_TEXTFIELD)
	protected WebElement scannerID_tf;

	@FindBy(xpath=UpdateDocumentPageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;

	@FindBy(xpath=UpdateDocumentPageObjects.SUBMIT_BUTTOM)
	protected WebElement submit_b;

	@FindBy(xpath=UpdateDocumentPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected WebElement returnToSearchScreen_b;

	@FindBy(xpath=UpdateDocumentPageObjects.FROM_DATE_VALIDATION_MESSAGE)
	protected WebElement fromDateValidation_m;

	@FindBy(xpath=UpdateDocumentPageObjects.TO_DATE_VALIDATION_MESSAGE)
	protected WebElement toDateValidation_m;

	@FindBy(xpath=UpdateDocumentPageObjects.MANDATORY_VALIDATION_MESSAGE)
	protected WebElement mandatoryValidation_m;

	@FindBy(xpath=UpdateDocumentPageObjects.DOCUMENT_TYPE_VALUE)
	protected WebElement getDocumentType_v;


	public UpdateDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void updateAllEditablefields(String documentType,String t24AccountId,String t24CustomerId,String t24ContractId,
			String validFrom, String validTo, String scannerID) throws InterruptedException{
		Actions action = new Actions(driver);
		action.click(documentType_ta).keyDown(Keys.CONTROL).sendKeys(String.valueOf('\u0061')).perform();
		action.keyUp(Keys.CONTROL).perform();
		Thread.sleep(2000);
		action.sendKeys(Keys.BACK_SPACE).perform();
		action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		t24_account_id_tf.clear();
		t24_account_id_tf.sendKeys(t24AccountId);
		t24_customer_id_tf.clear();
		t24_customer_id_tf.sendKeys(t24CustomerId);
		t24_contract_id_tf.clear();
		t24_contract_id_tf.sendKeys(t24ContractId);
		validFrom_tf.clear();
		validFrom_tf.sendKeys(validFrom);
		validTo_tf.clear();
		validTo_tf.sendKeys(validTo);
		scannerID_tf.clear();
		scannerID_tf.sendKeys(scannerID);
		submit_b.click();
	}

	public boolean isDocumentUpdatedSuccessfully()
	{
		try{
			boolean updateStatusMessage = driver.findElement(By.xpath("//p[text()='Information about the document updated successfully']")).isDisplayed();
			return updateStatusMessage;
		}
		catch(Exception e){
			return false;
		}
	}

	public boolean areFieldsnonEditable()
	{
		try{
			boolean documentNameNonEditable = documentName_tf.getAttribute("disabled").equals("true");
			boolean isFieldsNonEditable = documentNameNonEditable;
			return isFieldsNonEditable;
		}catch(Exception e){
			return false;
		}
	}

	public String getFromDateValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(fromDateValidation_m));
		return fromDateValidation_m.getText();
	}

	public String getToDateValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(toDateValidation_m));
		return toDateValidation_m.getText();
	}

	public boolean isMandatoryFieldValidationDisplayed()
	{
		try{
			Actions action = new Actions(driver);
			action.click(documentType_ta).sendKeys(Keys.chord(Keys.CONTROL, "a")).sendKeys(Keys.BACK_SPACE).perform();
			//Thread.sleep(1000);
			submit_b.click();
			return mandatoryValidation_m.isDisplayed();
		}catch(Exception e){
			return false;
		}
	}

	public SearchDossierPage returnToSearchScreen() throws InterruptedException, AWTException, IOException
	{
		returnToSearchScreen_b.click();
		return new SearchDossierPage(driver);
	}

	public void cancelAndReturnToSearchScreen() throws InterruptedException, AWTException, IOException
	{
		cancel_b.click();
		//Thread.sleep(1000);
		//return new SearchDossierPage(driver);
	}

	public String getDocumentType()
	{
		return getDocumentType_v.getText();
	}

	public String getDocumentMetadataValidTo()
	{
		return validTo_tf.getText();
	}

	public void returnToSearchScreenFromUpdateDocument() throws InterruptedException 
	{
		returnToSearchScreen_b.click();

	}

	public boolean isMandatoryFieldValidationDisplayedFromDate(String validFrom) {
		try {
			validFrom_tf.clear();
			validFrom_tf.sendKeys(validFrom);
			submit_b.click();
			//Thread.sleep(1000);
			return fromDateValidation_m.isDisplayed();

		}
		catch(Exception e) {
			return false;
		}
	}

}
