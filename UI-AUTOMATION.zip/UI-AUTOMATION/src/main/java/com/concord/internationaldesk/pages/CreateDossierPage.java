package com.concord.internationaldesk.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.internationaldesk.constants.CreateDossierPageObjects;
import com.concord.internationaldesk.constants.SearchDossierPageObjects;
public class CreateDossierPage extends BasePage {

	@FindBy(xpath=CreateDossierPageObjects.CREATEDOSSIER_CLIENT_ON_BOARDING_RADIOBUTTON)
	protected WebElement createDossier_clientonboarding_r;

	@FindBy(xpath=CreateDossierPageObjects.CREATEDOSSIER_OTHERS_RADIOBUTTON )
	protected WebElement createdossier_others_r;

	@FindBy(xpath=CreateDossierPageObjects.OK_BUTTON)
	protected WebElement ok_b;

	@FindBy(xpath=CreateDossierPageObjects.CLIENT_NAME_TEXTFIELD)
	protected WebElement client_name_tf;

	@FindBy(xpath=CreateDossierPageObjects.VALIDATE_BUTTON)
	protected WebElement validate_b;

	@FindBy(xpath=CreateDossierPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;

	@FindBy(xpath=CreateDossierPageObjects.PROCESS_NAME_FIELD_CAP_TYPEAHEAD)
	protected WebElement process_name_field_cap_th;


	@FindBy(xpath=CreateDossierPageObjects.NEXT_BUTTON)
	protected static WebElement next_b;

	@FindBy(xpath=CreateDossierPageObjects.T24_ACCOUNT_ID_TEXTFIELD)
	protected WebElement T24_account_id_tf;

	@FindBy(xpath=CreateDossierPageObjects.T24_CUSTOMER_ID_TEXTFIELD)
	protected WebElement T24_customer_id_tf;

	@FindBy(xpath=CreateDossierPageObjects.T24_CONTRACT_ID_TEXTFIELD)
	protected WebElement T24_contract_id_tf;

	@FindBy(xpath=CreateDossierPageObjects.PROCESS_NAME_OTHERS_TYPEHEAD)
	protected WebElement process_name_others_th;

	@FindBy(xpath=CreateDossierPageObjects.CLIENT_NAME_IDENTIFICATION_MESSAGE)
	protected WebElement client_name_identification_m;

	@FindBy(xpath=CreateDossierPageObjects.T24_CUSTOMER_ID_VALIDATION_MESSAGE)
	protected WebElement T24_customer_id_identification_m;

	@FindBy(xpath=CreateDossierPageObjects.T24_CONTRACT_ID_VALIDATION_MESSAGE)
	protected WebElement T24_contract_id_validation_m;

	@FindBy(xpath=CreateDossierPageObjects.T24_ACCOUNT_ID_VALIDATION_MESSAGE)
	protected WebElement T24_account_id_identification_m;


	@FindBy(xpath=CreateDossierPageObjects.COUNTRY_DROP_DOWN)
	protected WebElement country_dd;

	@FindBy(xpath=CreateDossierPageObjects.PRODUCT_DOSSIER_OTHERS_TOGGLE_BUTTON)
	protected WebElement product_dossier_others_box_tb;

	@FindBy(xpath=CreateDossierPageObjects.PROCESS_DOSSIER_OTHERS_TOGGLE_BUTTON)
	protected WebElement process_dossier_others_box_tb;

	@FindBy(xpath=CreateDossierPageObjects.PRODUCT_GROUP_DROP_DOWN)
	protected WebElement product_group_dd;

	@FindBy(xpath=CreateDossierPageObjects.ACTION_DROP_DOWN)
	protected WebElement action_dd;

	@FindBy(xpath=CreateDossierPageObjects.CLIENT_NAME_FOR_OTHERS)
	protected WebElement client_name_for_others;

	@FindBy(xpath=CreateDossierPageObjects.CLIENT_NAME_VALIDATION_MESSAGE)
	protected WebElement client_name_validation_m;

	@FindBy(xpath=CreateDossierPageObjects.T24_CUSTOMER_ID_VALIDATION_MESSAGE)
	protected WebElement T24_customer_id_validation_m;

//	@FindBy(xpath=CreateDossierPageObjects.T24_CONTRACT_ID_TEXTFIELD)
//	protected WebElement T24_contract_id_tf;

	@FindBy(xpath=CreateDossierPageObjects.T24_ACCOUNT_ID_VALIDATION_MESSAGE)
	protected WebElement T24_account_id_validation_m;

	@FindBy(xpath=CreateDossierPageObjects.TYPE_PROCESS_BUTTON)
	protected WebElement process_b;

	@FindBy(xpath=CreateDossierPageObjects.TYPE_PRODUCT_BUTTON)
	protected WebElement product_b;

	@FindBy(xpath=CreateDossierPageObjects.NEXT_PRODUCT_BUTTON)
	protected WebElement next_product_b;
	
	@FindBy(xpath=CreateDossierPageObjects.DOSSIER_IDENTIFICATION_VALIDATION_MESSAGE)
	protected WebElement identification_Validation_m;
	
	@FindBy(xpath=CreateDossierPageObjects.T24_CUSTOMERID_VALIDATION_MESSAGES)
	protected WebElement t24CustomerIdvalidationMessages_m;
	
	
	
	public CreateDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		Thread.sleep(2000);

	}
	public boolean selectingCreateDossierTypeCAP()
	{
		try {
			createDossier_clientonboarding_r.click();
			ok_b.click();
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	
	public boolean selectingCreateDossierTypeOther()
	{
		try {
			createdossier_others_r.click();
			ok_b.click();
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}

	public void enterClientNameAndValidate(String clientname) 
	{
		clear_b.click();
		client_name_tf.sendKeys(clientname);
		validate_b.click();
	}

	public void enterCustomerIdAndValidate(String customerid) 
	{
		clear_b.click();
		T24_customer_id_tf.sendKeys(customerid);
		validate_b.click();
	}

	public void enterContractIdAndValidate(String contractid) 
	{
		clear_b.click();
		T24_contract_id_tf.sendKeys(contractid);
		validate_b.click();
	}

	public void enterAccountIdAndValidate(String accountid) 
	{
		clear_b.click();
		T24_account_id_tf.sendKeys(accountid);
		validate_b.click();
	}
	
	
	public void createDossierForCapProcess (String clientname , String country ) throws InterruptedException 
	{
		clear_b.click();
		client_name_tf.sendKeys(clientname);
		validate_b.click();
		Actions action = new Actions(driver);
		action.click(country_dd).sendKeys(country).sendKeys(Keys.ENTER).perform();
		next_b.click();
		Thread.sleep(2000);
	}

	public void processDossierForOthers (String accountid,String contractid,String country,String processname,String clientName,String customerid) throws InterruptedException 
	{
		clear_b.click();
		T24_account_id_tf.sendKeys(accountid);
		T24_contract_id_tf.sendKeys(contractid);
		T24_customer_id_tf.sendKeys(customerid);
		validate_b.click();
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		action.click(country_dd).sendKeys(country).sendKeys(Keys.ENTER).perform();
		action.click(process_name_others_th).sendKeys(processname).sendKeys(Keys.ENTER).perform();
		action.click(client_name_for_others).sendKeys(clientName).sendKeys(Keys.ENTER).perform();
		next_b.click();
		Thread.sleep(1000);
	}

	public void  productDossierForOthers (String accountid , String customerid, String contractid, String country, String action_name ,String productgroup, String clientname) throws InterruptedException 
	{
		clear_b.click();
		T24_account_id_tf.sendKeys(accountid);
		T24_customer_id_tf.sendKeys(customerid);
		T24_contract_id_tf.sendKeys(contractid);
		validate_b.click();
		Thread.sleep(1000);
		Actions action = new Actions(driver);
		action.click(country_dd).sendKeys(country).sendKeys(Keys.ENTER).perform();
		product_b.click();
		action.click(action_dd).sendKeys(action_name).sendKeys(Keys.ENTER).perform();
		action.click(product_group_dd).sendKeys(productgroup).sendKeys(Keys.ENTER).perform();
		action.click(client_name_for_others).sendKeys(clientname).sendKeys(Keys.ENTER).perform();
		next_product_b.click();
		Thread.sleep(2000);
	}

	public String getClientNameValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(client_name_validation_m));
		return client_name_validation_m.getText();
	}
	
	public void enterCustomerNumberAccountNumberAndValidate(String customerNumber, String accountNumber) {
		clear_b.click();
		T24_customer_id_tf.sendKeys(customerNumber);
		T24_account_id_tf.sendKeys(accountNumber);
		validate_b.click();
		
	}
	public void enterCustomerNumberContractNumberAndValidate(String customerNumber, String contractNumber) {
		clear_b.click();
		T24_customer_id_tf.sendKeys(customerNumber);
		T24_contract_id_tf.sendKeys(contractNumber);
		validate_b.click();
		
	}
	

	public boolean isIdentificationValidationDisplayedForCAP()
	{
		try {
			client_name_identification_m.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public String getCustomerIdValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(T24_customer_id_validation_m)); return
				T24_customer_id_validation_m.getText();

	}
	public boolean isIdentificationValidationDisplayedForOthersCustomerId()
	{
		try {
			identification_Validation_m.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}

	}
	public String getMandatoryValidationMessageForT24CustomerId()
	{
		wait= new WebDriverWait(driver, 3);
		wait.until(ExpectedConditions.visibilityOf(t24CustomerIdvalidationMessages_m));
		return t24CustomerIdvalidationMessages_m.getText();
	}
	
	public String getAccountIdValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(T24_account_id_validation_m)); 
		return T24_account_id_validation_m.getText();
	}

	public boolean isIdentificationValidationDisplayedForOthersAccountId()
	{
		try {
			identification_Validation_m.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}

	}
	

	public String getContractIdValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(T24_contract_id_validation_m));
		return T24_contract_id_validation_m.getText();
	}

	public boolean isIdentificationValidationDisplayedForOthersContractId()
	{
		try {
			identification_Validation_m.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}

	}
	public static ImportDocumentPage navigateToImportDocumentPage() throws InterruptedException, AWTException, IOException
	{
		next_b.click();
		return new ImportDocumentPage(driver);
	}

}


