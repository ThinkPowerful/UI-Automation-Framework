package com.concord.base.constants;

public class BasePageObjects {
	
		//Reports
		public static final String REPORT_FILE_PATH = System.getProperty("user.dir")+"/ExtentReports/";
		
		//Top Menu
		public static final String BUSINESS_CONTEXT_DROPDOWN = "//select[@id='businessContext']";
		public static final String LANGUAGE_TYPE_DROPDOWN = "//select[@ng-model='header.langType']";
		
		//CommonPageObjects
		public static final String CUSTOMER_ADMIN_TYPE_DROPDOWN = "//select[@ng-model='searchObject.adminType']";
		public static final String IDENTIFIER_TEXTFIELD = "//input[@id='identifier']";
		public static final String FROM_DATE_TEXTFIELD = "//input[@id='fromDate']";
		public static final String TO_DATE_TEXTFIELD = "//input[@id='toDate']";
		public static final String SEARCH_BUTTON = "//button[text()='Search']";
		public static final String TO_INFO_BUTTON = "//button[@id='enableIText6']";
		public static final String CUSTOMER_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
		public static final String TO_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
		public static final String CLIENT_NAME_TEXT = "//div[@id='customerName']/input";
		public static final String BC_CONTRACT_VALIDATION_MESSAGES = "//div[@id='identifierAdministration']//p/span";
		public static final String DATE_VALIDATION_MESSAGES = "//div[@id='datePicker']//span";
		public static final String CLEAR_BUTTON = "//button[text()='Clear']";
		public static final String CLOSE_BUTTON = "//button[text()='Close']";
		public static final String VIEW_PDF_TOOLBAR = "//div[@id='toolbarViewerMiddle']";
		public static final String NEXT_BUTTON = "//button[text()='Next']";
		public static final String LENS_BUTTON="//span[@title='Search Customer']";
		public static final String CUSTOMER_INFO_BUTTON = "//button[@id='enableIText1']";
		public static final String CANCEL_BUTTON = "//button[text()='Cancel']";
		public static final String RETURN_TO_SEARCH_SCREEN_BUTTON = "//button[contains(text(),'Return to Search Screen')]";
		
		//SearchDocumentPage
		public static final String DOCUMENT_TYPE_TYPEAHEAD = "(//input[@ng-model='searchObject.documentTypes'])[1]";
		public static final String DOCUMENT_SOURCE_TYPEAHEAD = "(//input[@ng-model='searchObject.docSource'])[1]";
		public static final String DOCUMENT_NAME_TEXTFIELD = "(//input[@ng-model='searchObject.objectName'])[1]";
		public static final String ZERO_DOCUMENTS_FOUND_MESSAGE = "//span[contains(text(),'document(s) found')]/..";
		public static final String DOCUMENT_TYPE_INFO_BUTTON = "//button[@id='enableIText2']";
		public static final String DOCUMENT_SOURCE_INFO_BUTTON = "//button[@id='enableIText3']";
		public static final String DOCUMENT_NAME_INFO_BUTTON = "//button[@id='enableIText5']";
		public static final String DOCUMENT_TYPE_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
		public static final String DOCUMENT_SOURCE_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
		public static final String DOCUMENT_NAME_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
		public static final String SORT_BY_BUTTON = "//button[@id='documentsFilterButtonId']";
		public static final String SORT_DATE_OPTION = "//button[@id='documentsFilterButtonId']/following-sibling::ul//a[contains(text(),'Date')]";
		public static final String SORT_ASCENDING_OPTION = "//button[@id='documentsFilterButtonId']/following-sibling::ul//a[contains(text(),'Ascending')]";
		public static final String SORT_DESCENDING_OPTION = "//button[@id='documentsFilterButtonId']/following-sibling::ul//a[contains(text(),'Descending')]";
		public static final String OPTIONS_DROPDOWN = "//button[@id='documentsActionButtonId']";
		public static final String VIEW_ONEBYONE_OPTION = "//a[text()='View one by one']";
		public static final String DOWNLOAD_AS_ZIP_OPTION = "//a[text()='Download as Zip']";
		public static final String COMBINED_VIEW_OPTION = "//a[text()='Combined View (pdf)']";
		public static final String SEPERATE_TABS_VIEW_OPTION = "//a[text()='Separate tabs view']";
		public static final String SCROLL_TO_TOP_BUTTON = "//a[@ng-click='goTop()']";
		public static final String PAGE_SIZE_DROPDOWN = "//button[@title='Page Size']";
		public static final String SORT_BUTTON= "//button[@id='documentsFilterButtonId']";
		public static final String DATE_OPTION="//a[@class='ng-binding']";	
		public static final String DOCUMENT_TABLE="//table[@class='variables-matrix table table-responsive table-hover']";

		
		//Search Dossier Page Objects
		public static final String DOSSIER_TAB="//button[@href='/gdc/web/client/dossiers']";
		public static final String DOSSIER_NAME_TEXTFIELD = "(//input[@ng-model='searchObject.dossierName'])[1]";
		public static final String ZERO_DOSSIER_FOUND_MESSAGE = "//span[text()='dossier(s) found']/..";
		public static final String DOSSIER_NAME_INFO_BUTTON = "//button[@id='enableIText4']";
		public static final String DOSSIER_NAME_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
		public static final String VIEW_BUTTON = "//button[text()='View']";
		public static final String DOWNLOAD_BUTTON = "//button[text()='Download']";
		public static final String SEARCH_VIEW_BUTTON = "//span[@title='Search view']";
		public static final String SCROLL_TOP_BUTTON = "(//span[text()='Scroll top'])[4]";
		public static final String CREATE_DOSSIER_BUTTON = "//span[@title='Create dossier']";
		public static final String ACTIONS_DROPDOWN ="//button[@id='actionsInDossier']";
		public static final String IMPORT_OPTION ="//span[contains(text(),'Import')]";
		public static final String EDIT_OPTION = "//span[text()='Edit']";
		public static final String CLOSE_OPTION ="//li[@ng-click='listenerCallbackOpenModal()']";
		public static final String YES_POPUP_BUTTON = "//button[text()[normalize-space() ='Yes']]";
		public static final String NO_POPUP_BUTTON = "//button[text()='No']";
		public static final String VALID_FROM_METADATA_LABEL = "//dt[text()='Valid from']";
		public static final String VALID_FROM_METADATA_VALUE = "//dt[text()='Valid from']/following-sibling::dd";
		public static final String VALID_TO_METADATA_LABEL = "//dt[text()='Valid to']";
		public static final String VALID_TO_METADATA_VALUE = "//dt[text()='Valid from']/following-sibling::dd";
		public static final String IMPORT_BUTTON = "//*[@id=\"main\"]/ui-view/ui-view/ui-view/div/div/div[2]/div/div[1]/a/span";
		public static final String SELECT_ALL_BUTTON = "//button[text()='Select All']";
		public static final String UNSELECTED_CHECKBOXES = "//div[@class='container-fluid']//span[@class='drmicon drmicon-sm drmicon-checkbox-unchecked']";
		public static final String SELECTED_CHECKBOXES = "//div[@class='container-fluid']//span[@class='drmicon drmicon-sm drmicon-checkbox-checked']";
		public static final String UPDATE_STATUS_BUTTON = "//span[contains(text(),'Update Status')]";
		public static final String DESELECT_ALL_BUTTON = "//button[text()='Deselect All']";
		public static final String NUMBER_OF_DOCUMENTS_LABEL = "//span[@class='pull-right ng-binding']";
		public static final String DOCUMENTS_NAME = "//dd[@class='dossier-description-overflow ng-binding']";
		public static final String DOCUMENT_PREVIEW_WARNING_LABEL = "//div[@class='alert alert-warning ng-scope']";
		public static final String DOCUMENT_PREVIEW_NEXT_BUTTON = "//button[text()='Next']";
		public static final String DOCUMENT_PREVIEW_CLOSE_BUTTON = "//button[text()='Close']";
		public static final String DOCUMENT_PREVIEW_TITLE_LABEL = "//div[@class='drm-align-middle']//h4[@class='modal-title ng-binding']";
		public static final String IDENTIFY_CHECKBOX_BY_DOCUMENTNAME = "//*[@title='DocumentName']/ancestor::div[2]//span[@class='drmicon drmicon-sm drmicon-checkbox-unchecked']";
		public static final String CHECKED_OK_LABEL = "//span[@class='dropdown open']//span[@class='ng-scope'][contains(text(),'Checked Ok')]";
		public static final String CHECKED_NOTOK_LABEL = "//span[@class='dropdown open']//span[@class='ng-scope'][contains(text(),'Checked Not Ok')]";
		public static final String ARCHIVED_LABEL = "//span[@class='dropdown open']//span[@class='ng-scope'][contains(text(),'Archived')]";
		public static final String UPDATE_SUCCESS_IMAGE = "//div[@class='panel-body']//span[@ng-if='file.successStatus']";
		public static final String UPDATE_SUCCESS_DOCUMENT_NAME = "//div[@class='col-sm-4 col-xxs-4 ng-binding' and text()='DocumentName']";
		public static final String UPDATE_SUCCESS_MESSAGE = "//span[@ng-if='file.successStatus' and text()='Document status changed successfully']";
		public static final String STATUS_METADATA_VALUE = "//dt[contains(text(),'Status')]/following-sibling::dd";
		public static final String CLOSE_METADATA_FORM_ICON="//div[@class='panel panel-default metadata-view-panel']//span[@title='Close']";
		public static final String COMMENTS_TEXTAREA = "//textarea[@name='annotationText']";
		public static final String ADD_BUTTON = "//button[text()='Add']";
		public static final String DOCUMENT_TYPE_METADATA_VALUE = "//div[@class='panel panel-default metadata-view-panel']//dt[text()='Document type']/following-sibling::dd[1]";
		
		
		//Create Dossier Page Objects
		
		public static final String CREATEDOSSIER_LABLE = "//h2[text()='Create dossier']";
		public static final String CONTRACT_NUMBER_TEXTFIELD = "//input[@id='crcNumber']";
		public static final String VALIDATE_BUTTON = "//button[text()='Validate']";
		public static final String TYPE_PROCESS_BUTTON = "(//input[@id='processOrProduct'])[1]";
		public static final String TYPE_PRODUCT_BUTTON = "(//input[@id='processOrProduct'])[2]";
		public static final String CLIENTTYPE_NATURAL_RADIOBUTTON = "//input[@value='natural']";
		public static final String CLIENTTYPE_LEGAL_RADIOBUTTON= "//input[@value='legal']";
		public static final String ACTION_TYPEAHEAD = "//input[@id='actionContextId']";
		public static final String PROCESSNAME_TYPEAHEAD = "(//input[@id='processName'])[1]";
		public static final String DESCRIPTION_TEXTFIELD = "//input[@id='description']";
		public static final String PRODUCTGROUP_TYPEAHEAD = "(//input[@id='productName'])[1]";
		public static final String DOSSIER_IDENTIFICATION_VALIDATION_MESSAGE="//form[@name='dossierIdentificationForm']//p[text()='Please provide sufficient information to proceed']";
		public static final String BC_NUMBER_VALIDATION_MESSAGE="//input[@id='bcNumber']/../../div[@id='identifier']//p//span";
		public static final String CONTRACT_NUMBER_VALIDATION_MESSAGE="//input[@id='crcNumber']/../../div[@id='identifier']//p//span";
		public static final String DOSSIER_CONTEXT_VALIDATION_MESSAGE="//form[@name='dossierContextForm']//p[text()='Please provide sufficient information to proceed']";
		
		//Import Document Page Objects
		public static final String VALID_FROM_TEXTFIELD = "//input[@id='issueDate']";
		public static final String VALID_TO_TEXTFIELD = "//input[@id='expirationDate']";
		public static final String SCANNERID_TEXTFIELD = "//input[@id='scannerId']";
		public static final String ADD_MORE_INFORMATION_LINK = "//span[text()='Add more information']";
		public static final String REMOVE_BUTTON = "//span[@title='Delete']";
		public static final String IMPORTDOCUMENT_LABLE = "//h2[text()='Import document']";
		public static final String IMPORT_DOCUMENT_BUTTON = "//span[@title='Import document']";
		//public static final String SUBMIT_BUTTON = "//button[text()='Submit']";
		public static final String ADD_DOCUMENT_BUTTON = "//button[contains(text(),'Add Document')]";
		public static final String DROP_FILE_AREA = "//span[text()='Drop files here']/..//div[@role='tablist']";
		// added as part of import Multiple Document
		public static final String DOCUMENT_TYPE_TYPEAHEAD_MULTIPLE = 
				"(//div[@class='col-sm-8 drm-ui-select-wizard ng-scope']//input[@class='form-control ng-pristine ng-untouched ng-scope ng-valid-editable ng-empty ng-invalid ng-invalid-required font-resize'])[1]";
		public static final String DATE_VALIDATION_MESSAGE = "//span[text()='This is an invalid date, please type dd-mm-yyyy (in digits)']";
		

}
