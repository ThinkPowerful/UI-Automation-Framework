package com.concord.base.pages;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.internal.WrapsDriver;
import org.openqa.selenium.internal.WrapsElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.concord.utility.DateUtil;
import com.concord.utility.SMSessionCreator;

public class BasePage {
    public static WebDriver driver;
    public Actions action;
    String parentWindow;
    String childWindow;
    public ExtentTest test;
    public TopMenu menu;
    public List<Date> alertDate = new ArrayList<Date>();
    public String timeStamp;
    public WebDriverWait wait;
    public static Properties prop = new Properties();
    public static InputStream input = null;
    public static boolean isApplicationlaunched = false;
    public static String businessLine = "AllOtherBusinessLines";

    public BasePage(WebDriver driver) throws InterruptedException, AWTException, IOException {
        BasePage.driver = driver;
        PageFactory.initElements(driver, this);
        menu = new TopMenu(driver);
        PageFactory.initElements(driver, menu);
        launchConcordApplication();

    }

    public BasePage(WebDriver driver, ExtentTest test) throws InterruptedException, AWTException, IOException {
        BasePage.driver = driver;
        PageFactory.initElements(driver, this);
        this.test = test;
        menu = new TopMenu(driver);
        PageFactory.initElements(driver, menu);
        launchConcordApplication();
    }

    public void launchConcordApplication() throws InterruptedException, AWTException, IOException {
        if (!isApplicationlaunched) {
            input = new FileInputStream(System.getProperty("user.dir") + "\\src\\main\\resources\\config.properties");
            prop.load(input);
            driver.get(prop.getProperty("DOMAINTOSETCOOKIE"));
            Cookie ck = null;
            ck = new Cookie("SMSESSION",
                    SMSessionCreator.employeeSession(prop.getProperty("UN"), prop.getProperty("PW"),
                            prop.getProperty("DOMAIN"), prop.getProperty("ENVIRONMENT")),
                    ".nl.eu.abnamro.com", "/", null);
            System.out.println(ck);
            driver.manage().addCookie(ck);
            driver.navigate().refresh();
            Thread.sleep(500);
            driver.get(prop.getProperty("URL"));
            if (isElementPresent("//button[@ng-click='notification.closeModal()']")) {
                driver.findElement(By.xpath("//button[@ng-click='notification.closeModal()']")).click();
            }
            driver.manage().addCookie(ck);
            isApplicationlaunched = true;
        }
    }

    public static void navigateToHomePage(WebDriver driver) throws IOException, InterruptedException {
        if (isApplicationlaunched == false) {
            BasePage.driver = driver;
            input = new FileInputStream(System.getProperty("user.dir") + "\\src\\main\\resources\\config.properties");
            prop.load(input);
            driver.get(prop.getProperty("DOMAINTOSETCOOKIE"));
            Cookie ck = null;
            ck = new Cookie("SMSESSION",
                    SMSessionCreator.employeeSession(prop.getProperty("UN"), prop.getProperty("PW"),
                            prop.getProperty("DOMAIN"), prop.getProperty("ENVIRONMENT")),
                    ".nl.eu.abnamro.com", "/", null);
            System.out.println(ck);
            driver.manage().addCookie(ck);
            driver.navigate().refresh();
            Thread.sleep(500);
            if (businessLine.equals("Facility Management")) {
                String facilityManagementURL = prop.getProperty("URL");
                facilityManagementURL.replace("client", "building");
                driver.get(facilityManagementURL);
            } else if (businessLine.equals("AllOtherBusinessLines")) {
                driver.get(prop.getProperty("URL"));
            }
            if (isElementPresent("//button[@ng-click='notification.closeModal()']")) {
                driver.findElement(By.xpath("//button[@ng-click='notification.closeModal()']")).click();
            }
            driver.manage().addCookie(ck);
            isApplicationlaunched = true;
        } else {
            if (businessLine.equals("Facility Management")) {
                String facilityManagementURL = prop.getProperty("URL");
                facilityManagementURL.replace("client", "building");
                driver.get(facilityManagementURL);
            } else if (businessLine.equals("AllOtherBusinessLines")) {
                driver.get(prop.getProperty("URL"));
            }
        }
    }

    public String takeScreenshot() {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            long fileName = Calendar.getInstance().getTimeInMillis();
            FileUtils.copyFile(src,
                    new File(System.getProperty("user.dir") + "/ExtentReports/Snapshots/" + fileName + ".png"));
            return "Snapshots/" + fileName + ".png";
        } catch (Exception e) {
            e.getMessage();
            return "";
        }
    }

    public static boolean isElementPresent(String xpath) {
        int element_Size = driver.findElements(By.xpath(xpath)).size();
        if (element_Size == 0)
            return false;
        else
            return true;
    }

    public static String getCountOfElement(String xpath) {
        int element_Size = driver.findElements(By.xpath(xpath)).size();
        return String.valueOf(element_Size);
    }

    public void doubleClickOnElement(WebElement element) {
        action = new Actions(driver);
        action.doubleClick(element).perform();
    }

    public void singleClickOnElement(WebElement element) {
        action = new Actions(driver);
        action.click(element).perform();
    }

    public List<String> getAllValuesFromaAttributeInSearchResults(String attributeName) {
        List<String> attributeValues = new ArrayList<String>();
        int rowCountOfAlerts = driver.findElements(By.xpath(
                "//div[contains(@id,'drm-scroll')]//dt[text()='" + attributeName + "']/following-sibling::dd[1]"))
                .size();
        for (int rowIndex = 0; rowIndex < rowCountOfAlerts; rowIndex++) {
            String attributeValue = driver.findElements(By.xpath(
                    "//div[contains(@id,'drm-scroll')]//dt[text()='" + attributeName + "']/following-sibling::dd[1]"))
                    .get(rowIndex).getText();
            attributeValues.add(attributeValue);
        }
        return attributeValues;
    }

    public List<String> getDateValuesFromSearchResults() {
        List<String> attributeValues = new ArrayList<String>();
        int rowCountOfAlerts = driver
                .findElements(By.xpath("//table[@class='variables-matrix table table-responsive table-hover']//td[3]"))
                .size();
        for (int rowIndex = 0; rowIndex < rowCountOfAlerts; rowIndex++) {
            String attributeValue = driver
                    .findElements(
                            By.xpath("//table[@class='variables-matrix table table-responsive table-hover']//td[3]"))
                    .get(rowIndex).getText();
            attributeValues.add(attributeValue);
        }
        return attributeValues;
    }

    public List<String> getAllDocumentTypeValuesFromSearchResults() {
        List<String> attributeValues = new ArrayList<String>();
        int rowCountOfAlerts = driver
                .findElements(By.xpath("//table[@class='variables-matrix table table-responsive table-hover']//td[2]"))
                .size();
        for (int rowIndex = 0; rowIndex < rowCountOfAlerts; rowIndex++) {
            String attributeValue = driver
                    .findElements(
                            By.xpath("//table[@class='variables-matrix table table-responsive table-hover']//td[2]"))
                    .get(rowIndex).getText();
            attributeValues.add(attributeValue);
        }
        return attributeValues;
    }

    public boolean isEarchiveDocumentPresentInSearchResults(String originalDocumentID) {
        int numberofDocs = driver
                .findElements(By
                        .xpath("//table[@class='variables-matrix table table-responsive table-hover']//a[@ng-click='listenerCallbackDocumentPreview()']"))
                .size();
        for (int i = 0; i <= numberofDocs; i++) {
            if (numberofDocs != 0) {
                driver.findElements(By
                        .xpath("//table[@class='variables-matrix table table-responsive table-hover']//a[@ng-click='listenerCallbackDocumentPreview()']"))
                        .get(i).click();
                String originalDocIDFromWebPage = driver
                        .findElement(By.xpath("//dt[text()='Original document Id']/following-sibling::dd[1]"))
                        .getText();
                if (originalDocIDFromWebPage.equals(originalDocumentID)) {
                    return true;
                }
                driver.findElement(By.xpath("//button[text()='Close']")).click();
            } else {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
            }
        }
        return false;
    }

    public boolean isDocumentPresentInSearchResults(String documentName, String documentID) {
        int numberofDocs = driver
                .findElements(By.xpath("(//table[@class='variables-matrix table table-responsive table-hover']//td[1]//span[@title='" + documentName + "'])[1]")).size();
        for (int i = 0; i <= numberofDocs; i++) {
            if (numberofDocs != 0) {
                driver.findElements(By.xpath("(//table[@class='variables-matrix table table-responsive table-hover']//td[1]//span[@title='"
                        + documentName + "'])[1]/../..//a[@ng-click='listenerCallbackDocumentPreview()']")).get(i).click();
                if (driver
                        .findElement(By
                                .xpath("//div[@class='panel-body']//dt[text()='Document ID']/following-sibling::dd[1]"))
                        .getText().equals(documentID)) {
                    return true;
                }
            } else {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
            }
        }
        return false;
    }

    public boolean isDocumentPresentInSearchResults(String documentName) {
        int numberofDocs = driver
                .findElements(By.xpath("(//table[@class='variables-matrix table table-responsive table-hover']//td[1]//span[@title='" + documentName + "'])[1]")).size();
        for (int i = 0; i <= numberofDocs; i++) {
            if (numberofDocs != 0) {
                driver.findElements(By
                        .xpath("(//table[@class='variables-matrix table table-responsive table-hover']//td[1]//span[@title='"
                                + documentName + "'])[1]/../..//a[@ng-click='listenerCallbackDocumentPreview()']"))
                        .get(i).click();
                if (driver
                        .findElement(By
                                .xpath("//div[@class='panel-body']//dt[text()='Name']/following-sibling::dd[1]"))
                        .getText().equals(documentName)) {
                    return true;
                }
            } else {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
            }
        }
        return false;
    }

    public void waitForVisiblityOfElement(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 40);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void waitForInVisiblityOfElement(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 40);
        wait.until(ExpectedConditions.invisibilityOf(element));
    }

    public void waitForElementToBeClickable(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 40);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitForPageRefresh(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 40);
        wait.until(ExpectedConditions.refreshed(ExpectedConditions.stalenessOf(element)));
    }

    public void waitForNotStalenessOfElement(WebElement element) {
        boolean isStillOnOldPage = true;
        while (isStillOnOldPage) {
            try {
                element.getAttribute("value");
            } catch (StaleElementReferenceException e) {
                isStillOnOldPage = false;
            }
        }
        waitForVisiblityOfElement(element);
    }

    public void selectOptionByVisibleText(WebElement element, String text) {
        Select select = new Select(element);
        select.selectByVisibleText(text);
    }

    public void selectOptionByValue(WebElement element, String text) {
        Select select = new Select(element);
        select.selectByValue(text);
    }

    public static void waitForInVisiblityOfAllElements(List<WebElement> elements) {
        WebDriverWait wait = new WebDriverWait(driver, 40);
        wait.until(ExpectedConditions.invisibilityOfAllElements(elements));
    }

    public void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public static boolean isNotClickable(WebElement el, WebDriver driver) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 6);
            wait.until(ExpectedConditions.elementToBeClickable(el));
            return false;
        } catch (Exception e) {
            return true;
        }
    }

    public static File[] getFilenamesMatchingRegex(String regex, File dir) {
        return dir.listFiles(file -> file.getName().matches(regex));
    }

    public static void DropFile(File filePath, WebElement target, int offsetX, int offsetY) {
        if (!filePath.exists())
            throw new WebDriverException("File not found: " + filePath.toString());

        // WebDriver driver;
        if (WrapsElement.class.isAssignableFrom(target.getClass()))
            driver = ((WrapsDriver) ((WrapsElement) target).getWrappedElement()).getWrappedDriver();
        else
            driver = ((WrapsDriver) target).getWrappedDriver();

        // WebDriver driver = ((RemoteWebElement)target).getWrappedDriver();
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String JS_DROP_FILE = "var target = arguments[0]," + "    offsetX = arguments[1],"
                + "    offsetY = arguments[2]," + "    document = target.ownerDocument || document,"
                + "    window = document.defaultView || window;" + "" + "var input = document.createElement('INPUT');"
                + "input.type = 'file';" + "input.style.display = 'none';" + "input.onchange = function () {"
                + "  var rect = target.getBoundingClientRect(),"
                + "      x = rect.left + (offsetX || (rect.width >> 1)),"
                + "      y = rect.top + (offsetY || (rect.height >> 1)),"
                + "      dataTransfer = { files: this.files };" + ""
                + "  ['dragenter', 'dragover', 'drop'].forEach(function (name) {"
                + "    var evt = document.createEvent('MouseEvent');"
                + "    evt.initMouseEvent(name, !0, !0, window, 0, 0, 0, x, y, !1, !1, !1, !1, 0, null);"
                + "    evt.dataTransfer = dataTransfer;" + "    target.dispatchEvent(evt);" + "  });" + ""
                + "  setTimeout(function () { document.body.removeChild(input); }, 25);" + "};"
                + "document.body.appendChild(input);" + "return input;";

        WebElement input = (WebElement) jse.executeScript(JS_DROP_FILE, target, offsetX, offsetY);
        input.sendKeys(filePath.getAbsoluteFile().toString());
        wait.until(ExpectedConditions.stalenessOf(input));
    }

    public boolean isDossierFound(String dossierName, String creationDate) throws ParseException {
        // JavascriptExecutor executor = (JavascriptExecutor)driver;
        // return (Boolean) executor.executeScript("return
        // document.evaluate(\"//div[@class='panel-title-wrapper
        // cursor-click-enable ng-scope']//span[text()='"+dossierName+"'] and
        // //dt[text()='Created
        // on']/following-sibling::dd[text()='"+creationDate+"']\", document,
        // null, XPathResult.BOOLEAN_TYPE, null).booleanValue");
        boolean isdossierFound = false;
        int listOfDossiers = driver.findElements(
                By.xpath("//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[contains(text(),'"
                        + dossierName + "')]"))
                .size();
        for (int dossierCount = 0; dossierCount < listOfDossiers; dossierCount++) {
            driver.findElements(By
                    .xpath("//div[contains(@class,'panel-title-wrapper cursor-click-enable ng-scope')]//span[contains(text(),'"
                            + dossierName + "')]"))
                    .get(dossierCount).click();
            waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
            WebElement dossierMetadataInfo_b = driver.findElement(
                    By.xpath("//span[contains(text(),'" + dossierName + "')]/../../../../../..//span[@title='Info']"));
            dossierMetadataInfo_b.click();
            String creationDateTimeActual = driver
                    .findElement(By
                            .xpath("//dl[@ng-if='dossierMetadata.dossierName']//dt[text()='Created on']/following-sibling::dd[1]"))
                    .getText();
            if (creationDateTimeActual.contains(creationDate)) {
                driver.findElement(By.xpath("//a[@ng-click='removeDocument()']")).click();
                isdossierFound = true;
                break;
            } else {
                driver.findElement(By.xpath("//a[@ng-click='removeDocument()']")).click();
            }
        }
        return isdossierFound;
    }

}
