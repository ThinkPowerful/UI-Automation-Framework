package com.concord.base.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.concord.globalmarkets.constants.SearchDocumentsPageObjects;

public class TopMenu 
{
	WebDriver driver;

	@FindBy(xpath=SearchDocumentsPageObjects.BUSINESS_CONTEXT_DROPDOWN)
	protected static WebElement businessContext;

	@FindBy(xpath=SearchDocumentsPageObjects.LANGUAGE_TYPE_DROPDOWN)
	protected WebElement languageType;

		public TopMenu(WebDriver driver)
		{
			this.driver=driver;
		}
		
	public void selectBusinessContext(String businessLine)
	{
		Select select = new Select(businessContext);
		select.selectByVisibleText(businessLine);
	}
	
	public void selectBusinessContextByValue(String businessLine)
	{
		Select select = new Select(businessContext);
		select.selectByValue(businessLine);
	}
	
	public void selectLanguage(String language)
	{
		Select select = new Select(languageType);
		select.selectByVisibleText(language);
	}
}
