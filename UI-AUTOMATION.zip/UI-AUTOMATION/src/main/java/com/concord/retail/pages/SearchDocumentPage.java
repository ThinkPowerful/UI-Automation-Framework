package com.concord.retail.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.retail.constants.SearchDocumentsPageObjects;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

import junit.framework.Assert;

public class SearchDocumentPage extends BasePage {

	public SearchDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		menu.selectBusinessContext("Retail");
		menu.selectLanguage("EN");
	}

	@FindBy(xpath = SearchDocumentsPageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;

	@FindBy(xpath = SearchDocumentsPageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_Ta;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_TYPEAHEAD)
	protected WebElement documentSource_Ta;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.SEARCH_BUTTON)
	protected WebElement search_b;

	@FindBy(xpath = SearchDocumentsPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;

	@FindBy(xpath = SearchDocumentsPageObjects.SORT_BUTTON)
	protected WebElement sort_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DATE_OPTION)
	protected WebElement date_o;

	@FindBy(xpath = SearchDocumentsPageObjects.SORT_DESCENDING_OPTION)
	protected WebElement sort_des;

	@FindBy(xpath = SearchDocumentsPageObjects.SORT_ASCENDING_OPTION)
	protected WebElement sort_asc;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_TABLE)
	protected WebElement doc_table;

	public void searchDocumentWithOnlyBCNumber(String BCNumber) {
		try {
			selectOptionByValue(customerAdminType_Dd, "2:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(BCNumber);
			search_b.click();
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void sortByDate(String sortOrder) {
		// driver.findElement(By.xpath("//a[text()=" +sortOrder+ "]")).click();
		if (sortOrder.equalsIgnoreCase("Descending")) {
			sort_b.click();
			sort_des.click();

		} 
		if (sortOrder.equalsIgnoreCase("Ascending")) {
			sort_b.click();
			sort_asc.click();

		}
	}

}
