package com.concord.retail.constants;

import com.concord.base.constants.BasePageObjects;

public class SearchDocumentsPageObjects extends BasePageObjects {

	public static final String SORT_BUTTON= "//button[@id='documentsFilterButtonId']";
	public static final String DATE_OPTION="//a[@class='ng-binding']";	
	public static final String SORT_ASCENDING_OPTION="//a[text()='Ascending']";
	public static final String SORT_DESCENDING_OPTION="//a[text()='Descending']";
	public static final String DOCUMENT_TABLE="//table[@class='variables-matrix table table-responsive table-hover']";

	
}
