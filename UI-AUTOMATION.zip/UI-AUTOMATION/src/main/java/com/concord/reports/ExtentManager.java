package com.concord.reports;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.concord.globalmarkets.constants.SearchDocumentsPageObjects;
import org.apache.log4j.Logger;

public class ExtentManager {

	static ExtentHtmlReporter htmlReporter;
	static ExtentReports extent;
	static Properties prop = new Properties();
	static Properties log4jProp = new Properties();
	static InputStream input = null;
	static InputStream log4JProperties = null;
	public static ExtentReports setup()
	{
		if (extent == null) 
		{
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
				System.setProperty("CURRENT_TIME", dateFormat.format(new Date()));
				System.setProperty("RELATIVE_PATH", System.getProperty("user.dir")+"\\ExtentReports");
				System.out.println(System.getProperty("user.dir")+"\\ExtentReports");
				input = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\resources\\config.properties");
				log4JProperties = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\resources\\log4j.properties");
				log4jProp.load(log4JProperties);
				log4jProp.setProperty("log", "RELATIVE_PATH");
				Logger log = Logger.getLogger(ExtentManager.class.getName());
				prop.load(input);
				prop.setProperty("ENVIRONMENT",System.getProperty("ENVIRONMENT"));
				prop.setProperty("URL",System.getProperty("APPLICATION_URL"));
				prop.setProperty("DOMAINTOSETCOOKIE",System.getProperty("DOMAIN_TO_SET_COOKIE"));
				prop.setProperty("USERNAME",System.getProperty("USERNAME"));
				prop.setProperty("PASSWORD",System.getProperty("PASSWORD"));
				prop.setProperty("RELEASETEAMBRANCH",System.getProperty("RELEASE_TEAM_BRANCH"));
				prop.store(new FileOutputStream(System.getProperty("user.dir")+"/src/main/resources/config.properties"), null);
				log.info("Environment: "+prop.getProperty("ENVIRONMENT"));
				log.info("Application URL: "+prop.getProperty("URL"));
				log.info("Domain URL: "+prop.getProperty("DOMAINTOSETCOOKIE"));
				log.info("Username: "+prop.getProperty("USERNAME"));
				log.info("Password: "+prop.getProperty("PASSWORD"));
				log.info("Release Team and Branch: "+prop.getProperty("RELEASETEAMBRANCH"));
			} catch (Exception e) {
				e.printStackTrace();
			}
			Date d=new Date();
			String fileName=d.toString().replace(":", "_").replace(" ", "_")+".html";
			extent = new ExtentReports();
			htmlReporter =  new ExtentHtmlReporter(SearchDocumentsPageObjects.REPORT_FILE_PATH+fileName);
			extent.attachReporter(htmlReporter);
			htmlReporter.config().setReportName("Regression Testing Executed in: "+prop.getProperty("Environment")+" - "+prop.getProperty("URL"));
			htmlReporter.config().setTheme(Theme.STANDARD);
		}
		return extent;
	}
}
