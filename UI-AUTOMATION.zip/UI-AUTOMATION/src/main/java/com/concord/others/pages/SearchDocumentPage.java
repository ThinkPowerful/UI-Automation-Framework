package com.concord.others.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.constants.BasePageObjects;
import com.concord.base.pages.BasePage;



public class SearchDocumentPage extends BasePage{
	
	@FindBy(xpath = BasePageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;

	@FindBy(xpath = BasePageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;

	@FindBy(xpath = BasePageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_Ta;

	@FindBy(xpath = BasePageObjects.DOCUMENT_SOURCE_TYPEAHEAD)
	protected WebElement documentSource_Ta;

	@FindBy(xpath = BasePageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_Tf;

	@FindBy(xpath = BasePageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;

	@FindBy(xpath = BasePageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;

	@FindBy(xpath = BasePageObjects.SEARCH_BUTTON)
	protected WebElement search_b;

	@FindBy(xpath = BasePageObjects.ZERO_DOCUMENTS_FOUND_MESSAGE)
	protected WebElement zeroDocumentsFound_m;

	@FindBy(xpath = BasePageObjects.CUSTOMER_INFO_BUTTON)
	protected WebElement customerInfo_b;

	@FindBy(xpath = BasePageObjects.DOCUMENT_TYPE_INFO_BUTTON)
	protected WebElement documentTypeInfo_b;

	@FindBy(xpath = BasePageObjects.DOCUMENT_SOURCE_INFO_BUTTON)
	protected WebElement documentSourceInfo_b;

	@FindBy(xpath = BasePageObjects.DOCUMENT_NAME_INFO_BUTTON)
	protected WebElement documentNameInfo_b;

	@FindBy(xpath = BasePageObjects.TO_INFO_BUTTON)
	protected WebElement toInfo_b;

	@FindBy(xpath = BasePageObjects.CUSTOMER_INFO_MESSAGE)
	protected WebElement customerInfo_m;

	@FindBy(xpath = BasePageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentTypeInfo_m;

	@FindBy(xpath = BasePageObjects.DOCUMENT_SOURCE_INFO_MESSAGE)
	protected WebElement documentSourceInfo_m;

	@FindBy(xpath = BasePageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentNameInfo_m;

	@FindBy(xpath = BasePageObjects.TO_INFO_MESSAGE)
	protected WebElement toInfo_m;

	@FindBy(xpath = BasePageObjects.CLIENT_NAME_TEXT)
	protected WebElement clientName_t;

	@FindBy(xpath = BasePageObjects.BC_CONTRACT_VALIDATION_MESSAGES)
	protected WebElement bcContractvalidationMessages_m;

	@FindBy(xpath = BasePageObjects.DATE_VALIDATION_MESSAGES)
	protected WebElement dateValidationMessages_m;

	@FindBy(xpath = BasePageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;

	@FindBy(xpath = BasePageObjects.CLOSE_BUTTON)
	protected WebElement close_b;

	@FindBy(xpath = BasePageObjects.VIEW_PDF_TOOLBAR)
	protected WebElement viewPDF_toolBar;

	@FindBy(xpath = BasePageObjects.OPTIONS_DROPDOWN)
	protected WebElement options_dd;

	@FindBy(xpath = BasePageObjects.VIEW_ONEBYONE_OPTION)
	protected WebElement view_o;

	@FindBy(xpath = BasePageObjects.DOWNLOAD_AS_ZIP_OPTION)
	protected WebElement download_o;
	
	@FindBy(xpath = BasePageObjects.COMBINED_VIEW_OPTION)
	protected WebElement combinedView_o;
	
	@FindBy(xpath = BasePageObjects.SEPERATE_TABS_VIEW_OPTION)
	protected WebElement seperateTabsView_o;

	@FindBy(xpath = BasePageObjects.SCROLL_TO_TOP_BUTTON)
	protected WebElement scroolToTop_b;

	@FindBy(xpath = BasePageObjects.LENS_BUTTON)
	protected WebElement lens_b;
	
	@FindBy(xpath = BasePageObjects.PAGE_SIZE_DROPDOWN)
	protected WebElement pageSize_Dd;
	
	public Set<String> allWindowHandles;
	
	public SearchDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		menu.selectBusinessContext("Others");
		menu.selectLanguage("EN");
	}
	
	public void searchDocumentWithAllAttributes(String identifierType,String identifierNumber,String documentType, String documentSource,String documentName, String fromDate,
			String toDate) {
			clear_b.click();
			if (identifierType.equalsIgnoreCase("BC Number")) identifierType = "2:customer";
			if (identifierType.equalsIgnoreCase("IBAS Number")) identifierType = "3:customer";
			if (identifierType.equalsIgnoreCase("FBN Customer ID")) identifierType = "9:customer";
			selectOptionByValue(customerAdminType_Dd, identifierType);
			identifier_Tf.sendKeys(identifierNumber);
			Actions action = new Actions(driver);
			action.click(documentSource_Ta).sendKeys(documentSource).sendKeys(Keys.ENTER).perform();
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
			wait = new WebDriverWait(driver, 5);
			wait.until(
					ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[contains(@id,'drm-scroll')]"))));
	}
	
	

}
