package com.concord.bethmanbank.constants;

import com.concord.base.constants.BasePageObjects;

public class SearchDocumentPageObjects extends BasePageObjects
{
	public static final String ADVANCE_SEARCH_BUTTON = "//p[@class='drm-btn-switch pull-right']";
	public static final String ADVISORY_DOCUMENT_TYPE_TEXTFIELD = "//label[text()='Advisory Document type']";
	public static final String DOCUMENT_Id_TEXTFIELD = "//label[text()='Document Id']";
	public static final String KONTO_ART_KURZ_TEXTFIELD = "//label[text()='Konto Art Kurz']";
	public static final String KONTO_ART_LANG_TEXTFIELD = "//label[text()='Konto Art Lang']";
	public static final String DOCUMENT_NAME_LANG_TEXTFIELD = "//label[text()='Documentname Lang']";
	public static final String DOCUMENT_NAME_KURZ_TEXTFIELD = "//label[text()='Documentname Kurz']";
	public static final String SORT_RELAVANCE_OPTION = "//button[@id='documentsFilterButtonId']/following-sibling::ul//a[contains(text(),'Relevance')]";
	public static final String FOUR_CHAR_VALIDATION_MESSAGE = "//p[@ng-message='advIdentifierLength']";
	
}
