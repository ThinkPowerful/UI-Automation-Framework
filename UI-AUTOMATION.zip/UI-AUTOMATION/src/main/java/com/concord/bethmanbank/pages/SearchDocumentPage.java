package com.concord.bethmanbank.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.concord.base.constants.BasePageObjects;
import com.concord.base.pages.BasePage;
import com.concord.bethmanbank.constants.SearchDocumentPageObjects;


public class SearchDocumentPage extends BasePage
{
	
	@FindBy(xpath=BasePageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;
	
	@FindBy(xpath=BasePageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;

	@FindBy(xpath=BasePageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_Ta;

	@FindBy(xpath=BasePageObjects.DOCUMENT_SOURCE_TYPEAHEAD)
	protected WebElement documentSource_Ta;

	@FindBy(xpath=BasePageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_Tf;
	
	@FindBy(xpath=BasePageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;
	
	@FindBy(xpath=BasePageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;
	
	@FindBy(xpath=BasePageObjects.SEARCH_BUTTON)
	protected WebElement search_b;

	@FindBy(xpath=BasePageObjects.ZERO_DOCUMENTS_FOUND_MESSAGE)
	protected WebElement zeroDocumentsFound_m;
	
	@FindBy(xpath=BasePageObjects.CUSTOMER_INFO_BUTTON)
	protected WebElement customerInfo_b;

	@FindBy(xpath=BasePageObjects.DOCUMENT_TYPE_INFO_BUTTON)
	protected WebElement documentTypeInfo_b;
	
	@FindBy(xpath=BasePageObjects.DOCUMENT_SOURCE_INFO_BUTTON)
	protected WebElement documentSourceInfo_b;
	
	@FindBy(xpath=BasePageObjects.DOCUMENT_NAME_INFO_BUTTON)
	protected WebElement documentNameInfo_b;
	
	@FindBy(xpath=BasePageObjects.TO_INFO_BUTTON)
	protected WebElement toInfo_b;
	
	@FindBy(xpath=BasePageObjects.CUSTOMER_INFO_MESSAGE)
	protected WebElement customerInfo_m;
	
	@FindBy(xpath=BasePageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentTypeInfo_m;
	
	@FindBy(xpath=BasePageObjects.DOCUMENT_SOURCE_INFO_MESSAGE)
	protected WebElement documentSourceInfo_m;
	
	@FindBy(xpath=BasePageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentNameInfo_m;
	
	@FindBy(xpath=BasePageObjects.TO_INFO_MESSAGE)
	protected WebElement toInfo_m;
	
	@FindBy(xpath=BasePageObjects.CLIENT_NAME_TEXT)
	protected WebElement clientName_t;
	
	@FindBy(xpath=BasePageObjects.BC_CONTRACT_VALIDATION_MESSAGES)
	protected WebElement bcContractvalidationMessages_m;
	
	@FindBy(xpath=BasePageObjects.DATE_VALIDATION_MESSAGES)
	protected WebElement dateValidationMessages_m;
	
	@FindBy(xpath=BasePageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;
	
	@FindBy(xpath=SearchDocumentPageObjects.ADVANCE_SEARCH_BUTTON)
	protected WebElement advanceSearch_b;
	
	@FindBy(xpath=SearchDocumentPageObjects.ADVISORY_DOCUMENT_TYPE_TEXTFIELD)
	protected WebElement advisoryDocumentType_Tf;
	
	@FindBy(xpath=SearchDocumentPageObjects.DOCUMENT_Id_TEXTFIELD)
	protected WebElement documentID_Tf;
	
	@FindBy(xpath=SearchDocumentPageObjects.KONTO_ART_KURZ_TEXTFIELD)
	protected WebElement kontoArtKurz_Tf;
	
	@FindBy(xpath=SearchDocumentPageObjects.KONTO_ART_LANG_TEXTFIELD)
	protected WebElement kontoArtLang_Tf;
	
	@FindBy(xpath=SearchDocumentPageObjects.DOCUMENT_NAME_LANG_TEXTFIELD)
	protected WebElement documentNameLang_Tf;
	
	@FindBy(xpath=SearchDocumentPageObjects.DOCUMENT_NAME_KURZ_TEXTFIELD)
	protected WebElement documentNameKurz_Tf;
	
	@FindBy(xpath=SearchDocumentPageObjects.SORT_BY_BUTTON)
	protected WebElement sortBy_b;
	
	@FindBy(xpath=SearchDocumentPageObjects.SORT_DATE_OPTION)
	protected WebElement sortByDate_o;
	
	@FindBy(xpath=SearchDocumentPageObjects.SORT_RELAVANCE_OPTION)
	protected WebElement sortByRelvance_o;
	
	@FindBy(xpath=SearchDocumentPageObjects.SORT_ASCENDING_OPTION)
	protected WebElement sortByAscending_o;
	
	@FindBy(xpath=SearchDocumentPageObjects.SORT_DESCENDING_OPTION)
	protected WebElement sortByDescending_o;
	
	@FindBy(xpath=SearchDocumentPageObjects.FOUR_CHAR_VALIDATION_MESSAGE)
	protected WebElement fourCharValidation_m;

	public SearchDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		launchConcordApplication();
		menu.selectBusinessContextByValue("string:13");
		menu.selectLanguage("EN");
	}
	
	public void SearchDocumentsWithOnlyCustomerNumber(String customerNumber, String fromDate, String toDate){		
			selectOptionByValue(customerAdminType_Dd, "11:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(customerNumber);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
		
	}

	public void SearchDocumentsWithOnlyAccountNumber(String accountNumber, String fromDate, String toDate)
	{
			selectOptionByValue(customerAdminType_Dd, "11:account");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(accountNumber);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
	}
	
	public void filterDocuments(String customerOrAccountOption, String identifierNumber, String documentType, 
			String documentSource, String documentName, String fromDate, String toDate)
	{
		clear_b.click();
		if(customerOrAccountOption=="Customer Number"){
			selectOptionByVisibleText(customerAdminType_Dd, "Customer Number");
		}
		else{
			selectOptionByVisibleText(customerAdminType_Dd, "Account Number");
		}
		identifier_Tf.sendKeys(identifierNumber);
		Actions action = new Actions(driver);
		action.click(documentType_Ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		action.click(documentSource_Ta).sendKeys(documentSource).sendKeys(Keys.ENTER).perform();
		documentName_Tf.sendKeys(documentName);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		search_b.click();
	}
	
	public void filterDocumentsWithAdvanceSearch(String customerOrAccountOption, String identifierNumber, String documentType, 
			String documentSource, String documentName, String fromDate, String toDate, String advisoryDocumentType, String documentID, String kontoArtKurz, String kontoArtLang,
			String documentNameLang, String documentNameKurz)
	{
		clear_b.click();
		if(customerOrAccountOption=="Customer Number"){
			selectOptionByVisibleText(customerAdminType_Dd, "Customer Number");
		}
		else{
			selectOptionByVisibleText(customerAdminType_Dd, "Account Number");
		}
		identifier_Tf.sendKeys(identifierNumber);
		Actions action = new Actions(driver);
		action.click(documentType_Ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		action.click(documentSource_Ta).sendKeys(documentSource).sendKeys(Keys.ENTER).perform();
		documentName_Tf.sendKeys(documentName);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		if(isElementPresent("//label[text()='Advisory Document type']")==false)
		{
		advanceSearch_b.click();
		}
		action.moveToElement(advisoryDocumentType_Tf);
		action.click();
		action.sendKeys(advisoryDocumentType).perform();
		action.moveToElement(documentID_Tf);
		action.click();
		action.sendKeys(documentID).perform();
		action.moveToElement(kontoArtKurz_Tf);
		action.click();
		action.sendKeys(kontoArtKurz).perform();
		action.moveToElement(kontoArtLang_Tf);
		action.click();
		action.sendKeys(kontoArtLang).perform();
		action.moveToElement(documentNameLang_Tf);
		action.click();
		action.sendKeys(documentNameLang).perform();
		action.moveToElement(documentNameKurz_Tf);
		action.click();
		action.sendKeys(documentNameKurz).perform();
		search_b.click();
	}
	
	public void sortDocumentsBasedOnCreationDate(String sortingOrder)
	{
		waitForElementToBeClickable(clear_b);
		sortBy_b.click();
		sortByDate_o.click();
		waitForElementToBeClickable(clear_b);
		switch (sortingOrder)
        {
        case "Ascending":
        	sortBy_b.click();
        	sortByAscending_o.click();
        	waitForElementToBeClickable(clear_b);
        	break;
    		
		case "Descending":
			sortBy_b.click();
			sortByDescending_o.click();
			waitForElementToBeClickable(clear_b);
			break;
        }
	}
	
	public String getValidationMessage()
	{
		return fourCharValidation_m.getText();
	}
	
	

}
