package com.concord.globalmarkets.constants;

public class SearchCustomerPageObjects {
	
	//GlobalMarkets_SearchCustomerPage
	public static final String NAME_RADIO_BUTTON ="//input[@value='name']";
	public static final String POSTAL_CODE_RADIO_BUTTON="//input[@value='postCode']";
	public static final String COC_RADIO_BUTTON="//input[@value='coc']";
	public static final String SURNAME_TEXTFIELD="//input[@id='surname']";
	public static final String INITIALS_TEXTFIELD="//input[@name='initials']";
	public static final String STREET_NAME_TEXTFIELD="//input[@name='streetName']";
	public static final String HOUSE_NUMBER_TEXTFIELD="//input[@name='houseNumber']";
	public static final String CITY_TEXTFIELD="//input[@name='city']";
	public static final String DOB_TEXTFIELD="//input[@name='dateOfBirth']";
	public static final String COUNTRY_TYPEAHEAD="//input[@name='country']";
	public static final String CLEAR_BUTTON="//button[@ng-click='clearForm(customerSearchForm)']";
	public static final String SEARCH_BUTTON="//button[@ng-click='customerSearch(customerSearchForm.$valid)']";
	public static final String POSTAL_CODE_TEXTFIELD="//input[@name='postalCode']";
	public static final String COC_TEXTFIELD="//input[@name='cocNumber']";
	public static final String CLOSE_BUTTON="//button[text()='Close']";
	public static final String RETURN_TO_SEARCH_SCREEN_BUTTON="//button[text()='Return to Search Screen']";
	public static final String SURNAME_VALIDATION_MESSAGE="//div[contains(@ng-messages,'surname')]//span[@class='ng-scope']";
	public static final String CITY_VALIDATION_MESSAGE="//div[contains(@ng-messages,'city')]//span[@class='ng-scope']";
	public static final String POSTAL_CODE_VALIDATION_MESSAGE="//div[contains(@ng-messages,'postal')]//span[@class='ng-scope']";
	public static final String COUNTRYL_CODE_VALIDATION_MESSAGE="//div[contains(@ng-messages,'country')]//span[@class='ng-scope']";
	public static final String COC_VALIDATION_MESSAGE="//div[contains(@ng-messages,'coc')]//span[@class='ng-scope']";
	public static final String DOB_VALIDATION_MESSAGE = "//div[contains(@ng-messages,'dateOfBirth')]//span[@class='ng-scope']";
	public static final String ZERO_MATCHES_FOUND_MESSAGE = "//label[text()='match(es) found']";
	
	
}
