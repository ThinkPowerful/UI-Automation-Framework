package com.concord.globalmarkets.pages;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;
import com.concord.globalmarkets.constants.ImportDocumentPageObjects;
import com.concord.globalmarkets.constants.UpdateDocumentPageObjects;

public class ImportDocumentPage extends BasePage {

	@FindBy(xpath = ImportDocumentPageObjects.IMPORTDOCUMENT_LABLE)
	protected WebElement importdocument_l;

	@FindBy(xpath = ImportDocumentPageObjects.IMPORT_DOCUMENT_BUTTON)
	protected WebElement import_Document_b;

	@FindBy(xpath = ImportDocumentPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_tf;

	@FindBy(xpath = ImportDocumentPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_ta;

	@FindBy(xpath = ImportDocumentPageObjects.BCNUMBER_TEXTFIELD)
	protected WebElement bcNumber_tf;

	@FindBy(xpath = ImportDocumentPageObjects.CONTRACTNUMBER_TEXTFIELD)
	protected WebElement contractNum_tf;

	@FindBy(xpath = ImportDocumentPageObjects.VALID_FROM_TEXTFIELD)
	protected WebElement validFrom_tf;

	@FindBy(xpath = ImportDocumentPageObjects.VALID_TO_TEXTFIELD)
	protected WebElement validTo_tf;

	@FindBy(xpath = ImportDocumentPageObjects.SCANNERID_TEXTFIELD)
	protected WebElement scannerID_tf;

	@FindBy(xpath = ImportDocumentPageObjects.ADD_MORE_INFORMATION_LINK)
	protected WebElement addMoreInfo_l;

	@FindBy(xpath = ImportDocumentPageObjects.REMOVE_BUTTON)
	protected WebElement remove_b;

	@FindBy(xpath = ImportDocumentPageObjects.SUBMIT_BUTTON)
	protected static WebElement submit_b;

	@FindBy(xpath = ImportDocumentPageObjects.ADD_DOCUMENT_BUTTON)
	protected WebElement addDocument_b;

	@FindBy(xpath = ImportDocumentPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected static WebElement returnToSearchScreen_b;

	@FindBy(xpath = ImportDocumentPageObjects.DROP_FILE_AREA)
	protected static WebElement dropFile_A;
	
	@FindBy(xpath = ImportDocumentPageObjects.DOCUMENT_TYPE_TYPEAHEAD_MULTIPLE)
	protected String documentType_tamulti;

	@FindBy(xpath = UpdateDocumentPageObjects.MANDATORY_VALIDATION_MESSAGE)
	protected WebElement mandatoryFieldValidation_m;
	
	@FindBy(xpath = ImportDocumentPageObjects.DATE_VALIDATION_MESSAGE)
	protected WebElement dateFieldValidation_m;

	@FindBy(xpath = ImportDocumentPageObjects.DOCUMENT_TYPE_TYPEAHEAD_MULTIPLE)
	protected static WebElement documentType_Multi;
	
	@FindBy(xpath = ImportDocumentPageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;
	
	public ImportDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		Thread.sleep(2000);
	}

	public void isAllTheElementsInImportDocumentsIsDisplayed(String documentPath) throws IOException {
		import_Document_b.click();
		Runtime.getRuntime().exec(System.getProperty("user.dir") + "\\AutoItScripts\\UploadDocument.exe" + " "
				+ System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + "Scanner.png");
	}

	public static void submitDossierAndDocuments() {
		submit_b.click();
	}

	public void importDocument(String documentName, String documentType) {
		DropFile(new File(System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
				dropFile_A, 0, 0);
		Actions action = new Actions(driver);
		action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		submit_b.click();
	}

	// Added for MultipleImportDocument
	
	public void importMultipleDocument(String documentName, String documentType) {
		DropFile(new File(System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
				dropFile_A, 0, 0);
		Actions action = new Actions(driver);
		action.click(documentType_Multi).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
	}

	public  static SearchDossierPage navigateToSearchDossierScreen()
			throws InterruptedException, AWTException, IOException {
		waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		returnToSearchScreen_b.click();
		return new SearchDossierPage(driver);
	}

	public boolean isMandatoryFieldValidationDisplayed(String documentName,String documentType) {
		try {
			DropFile(new File(
					System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
					dropFile_A, 0, 0);
			documentName_tf.clear();
			Actions action = new Actions(driver);
			action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
			submit_b.click();
			return mandatoryFieldValidation_m.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean isDateFieldValidationDisplayed(String documentName,String documentType) {
		try {
			DropFile(new File(
					System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
					dropFile_A, 0, 0);
			Actions action = new Actions(driver);
			action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
			action.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
			WebElement addInfo=driver.findElement(By.xpath("//a[contains(.,'Add more information')]"));
			action.moveToElement(addInfo).click().build().perform();
			driver.findElement(By.xpath("//*[@id=\"issueDate\"]")).sendKeys("abcd");
			driver.findElement(By.xpath("//*[@id=\"expirationDate\"]")).sendKeys("54654");
			driver.findElement(By.xpath("//*[@id=\"scannerId\"]")).sendKeys("12583");
			submit_b.click();
			action.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
			return dateFieldValidation_m.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}
	
	public SearchDossierPage cancelAndReturnToSearchScreen() throws InterruptedException, AWTException, IOException {
		cancel_b.click();
		return new SearchDossierPage(driver);
	}
}
