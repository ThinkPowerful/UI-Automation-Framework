package com.concord.globalmarkets.constants;

public class UpdateDossierPageObjects {

	public static final String BC_NUMBER_TEXTFIELD = "//input[@id='bcNumber']";
	public static final String CONTRACT_NUMBER_TEXTFIELD = "//input[@id='crcNumber']";
	public static final String LENS_ICON_BUTTON = "//span[@title='Search Customer']";
	public static final String RESET_BUTTON = "//button[text()='Reset']";
	public static final String VALIDATE_BUTTON = "//button[text()='Validate']";
	public static final String TYPE_PRODUCT_BUTTON = "(//label[contains(normalize-space(.),'Product')])[1]";
	public static final String TYPE_PROCESS_BUTTON = "//label[contains(normalize-space(.),'Process')]";
	public static final String PRODUCT_GROUP_DROPDOWN = "//input[@id='productName']";
	public static final String DESCRIPTION_TEXTFIELD = "//input[@id='description']";
	public static final String CANCEL_BUTTON = "//button[text()='Cancel']";
	public static final String SUBMIT_BUTTON = "//button[text()='Submit']";
	public static final String RETURN_TO_SEARCH_SCREEN_BUTTON = "//button[text()='Return to Search Screen']";

}
