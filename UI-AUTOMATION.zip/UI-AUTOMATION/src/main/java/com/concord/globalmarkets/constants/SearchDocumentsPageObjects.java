package com.concord.globalmarkets.constants;

public class SearchDocumentsPageObjects 
{
	//Reports
	public static final String REPORT_FILE_PATH = System.getProperty("user.dir")+"/ExtentReports/";
	
	//Top Menu
	public static final String BUSINESS_CONTEXT_DROPDOWN = "//select[@id='businessContext']";
	public static final String LANGUAGE_TYPE_DROPDOWN = "//select[@ng-model='header.langType']";

	//GlobalMarkets_SearchDocumentPage
	public static final String CUSTOMER_ADMIN_TYPE_DROPDOWN = "//select[@ng-model='searchObject.adminType']";
	public static final String IDENTIFIER_TEXTFIELD = "//input[@id='identifier']";
	public static final String DOCUMENT_TYPE_TYPEAHEAD = "//input[@ng-model='$select.search']";
	public static final String DOCUMENT_SOURCE_TYPEAHEAD = "(//input[@ng-model='searchObject.docSource'])[1]";
	public static final String DOCUMENT_NAME_TEXTFIELD = "(//input[@ng-model='searchObject.objectName'])[1]";
	public static final String FROM_DATE_TEXTFIELD = "//input[@id='fromDate']";
	public static final String TO_DATE_TEXTFIELD = "//input[@id='toDate']";
	public static final String SEARCH_BUTTON = "//button[text()='Search']";
	public static final String ZERO_DOCUMENTS_FOUND_MESSAGE = "//span[contains(text(),'document(s) found')]/..";
	public static final String CUSTOMER_INFO_BUTTON = "//button[@id='enableIText1']";
	public static final String DOCUMENT_TYPE_INFO_BUTTON = "//button[@id='enableIText2']";
	public static final String DOCUMENT_SOURCE_INFO_BUTTON = "//button[@id='enableIText3']";
	public static final String DOCUMENT_NAME_INFO_BUTTON = "//button[@id='enableIText5']";
	public static final String TO_INFO_BUTTON = "//button[@id='enableIText6']";
	public static final String CUSTOMER_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String DOCUMENT_TYPE_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String DOCUMENT_SOURCE_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String DOCUMENT_NAME_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String TO_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String CLIENT_NAME_TEXT = "//div[@id='customerName']/input";
	public static final String BC_CONTRACT_VALIDATION_MESSAGES = "//div[@id='identifierAdministration']//p/span";
	public static final String DATE_VALIDATION_MESSAGES = "//div[@id='datePicker']//span";
	public static final String CLEAR_BUTTON = "//button[text()='Clear']";
	public static final String VIEW_PDF_TOOLBAR = "//div[@id='toolbarViewerMiddle']";
	public static final String CLOSE_BUTTON = "//button[text()='Close']";
	public static final String SCROLL_TO_TOP_BUTTON = "//a[@ng-click='goTop()']";
	public static final String OPTIONS_DROPDOWN = "//button[@id='documentsActionButtonId']";
	public static final String VIEW_ONEBYONE_OPTION = "//a[text()='View one by one']";
	public static final String NEXT_BUTTON = "//button[text()='Next']";
	public static final String DOWNLOAD_AS_ZIP_OPTION = "//a[text()='Download as Zip']";
	public static final String LENS_BUTTON="//span[@title='Search Customer']";
	public static final String ADDITIONAL_IDENTIFICATION_DROPDOWN = "//select[@name='additionalAdminType']";
	public static final String ADDITIONAL_IDENTIFICATION_TEXTFIELD = "//input[@id='additionalIdentifier']";
	public static final String COMBINED_VIEW_OPTION = "//a[text()='Combined View (pdf)']";
	public static final String SEPERATE_TABS_VIEW_OPTION = "//a[text()='Separate tabs view']";
	public static final String PAGE_SIZE_DROPDOWN = "//button[@title='Page Size']";
}
