package com.concord.globalmarkets.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;
import com.concord.globalmarkets.constants.UpdateDossierPageObjects;

public class UpdateDossierPage extends BasePage
{
	@FindBy(xpath=UpdateDossierPageObjects.BC_NUMBER_TEXTFIELD)
	protected WebElement bcNumber_Tf;
	
	@FindBy(xpath=UpdateDossierPageObjects.CONTRACT_NUMBER_TEXTFIELD)
	protected WebElement contractNumber_Tf;
	
	@FindBy(xpath=UpdateDossierPageObjects.LENS_ICON_BUTTON)
	protected WebElement lens_icon_b;
	
	@FindBy(xpath=UpdateDossierPageObjects.RESET_BUTTON)
	protected WebElement reset_b;
	
	@FindBy(xpath=UpdateDossierPageObjects.VALIDATE_BUTTON)
	protected WebElement validate_b;
	
	@FindBy(xpath=UpdateDossierPageObjects.TYPE_PRODUCT_BUTTON)
	protected WebElement typeProduct_b;
	
	@FindBy(xpath=UpdateDossierPageObjects.TYPE_PROCESS_BUTTON)
	protected WebElement typeProcess_b;
	
	@FindBy(xpath=UpdateDossierPageObjects.PRODUCT_GROUP_DROPDOWN)
	protected WebElement productGroup_dd;
	
	@FindBy(xpath=UpdateDossierPageObjects.DESCRIPTION_TEXTFIELD)
	protected WebElement description_Tf;
	
	@FindBy(xpath=UpdateDossierPageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;
	
	@FindBy(xpath=UpdateDossierPageObjects.SUBMIT_BUTTON)
	protected WebElement submit_b;
	
	@FindBy(xpath=UpdateDossierPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected WebElement returnToSearchScreen_b;
	
	public UpdateDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public void updateDossierDescription(String description)
	{
		description_Tf.clear();
		description_Tf.sendKeys(description);
		submit_b.click();
	}
	
	public boolean isDossierUpdatedSuccessfully()
	{
		
		try{
		boolean updateStatusMessage = driver.findElement(By.xpath("//div[text()='Information about the dossier updated successfully']")).isDisplayed();
		return updateStatusMessage;
		}
		catch(Exception e){
			return false;
		}
	}
	
	public SearchDossierPage returnToSearchScreen() throws InterruptedException, AWTException, IOException
	{
		returnToSearchScreen_b.click();
		return new SearchDossierPage(driver);
	}
	
	public SearchDossierPage cancelAndReturnToSearchScreen() throws InterruptedException, AWTException, IOException
	{
		cancel_b.click();
		return new SearchDossierPage(driver);
	}
	
	public boolean isFieldsnonEditable()
	{
		try{
			boolean bcNumberNonEditable = bcNumber_Tf.getAttribute("disabled").equals("true");
			boolean contractNumberNonEditable = contractNumber_Tf.getAttribute("disabled").equals("true");
			boolean isFieldsNonEditable = bcNumberNonEditable && contractNumberNonEditable;
			return isFieldsNonEditable;
		}catch(Exception e){
			return false;
		}
	}
	

}
