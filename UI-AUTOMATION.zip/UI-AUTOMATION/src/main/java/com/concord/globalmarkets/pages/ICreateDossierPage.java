package com.concord.globalmarkets.pages;

public interface ICreateDossierPage 
{

}
