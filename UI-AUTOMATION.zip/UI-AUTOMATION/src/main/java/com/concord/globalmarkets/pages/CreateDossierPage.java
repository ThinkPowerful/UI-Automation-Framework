package com.concord.globalmarkets.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.globalmarkets.constants.CreateDossierPageObjects;

public class CreateDossierPage extends BasePage
{

	@FindBy(xpath=CreateDossierPageObjects.CREATEDOSSIER_LABLE)
	protected WebElement createDossier_l;
	
	@FindBy(xpath=CreateDossierPageObjects.BCNUMBER_TEXTFIELD)
	protected WebElement bcNumber_Tf;
	
	@FindBy(xpath=CreateDossierPageObjects.BC_NUMBER_VALIDATION_MESSAGE)
	protected WebElement bcNumber_Validation_m;
	
	@FindBy(xpath=CreateDossierPageObjects.CONTRACT_NUMBER_TEXTFIELD)
	protected WebElement contractNumber_Tf;
	
	@FindBy(xpath=CreateDossierPageObjects.CONTRACT_NUMBER_VALIDATION_MESSAGE)
	protected WebElement contractNumber_Validation_m;
	
	@FindBy(xpath=CreateDossierPageObjects.DOSSIER_IDENTIFICATION_VALIDATION_MESSAGE)
	protected WebElement identification_Validation_m;
	
	@FindBy(xpath=CreateDossierPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;
	
	@FindBy(xpath=CreateDossierPageObjects.VALIDATE_BUTTON)
	protected WebElement validate_b;
	
	@FindBy(xpath=CreateDossierPageObjects.TYPE_PROCESS_BUTTON)
	protected WebElement process_b;
	
	@FindBy(xpath=CreateDossierPageObjects.TYPE_PRODUCT_BUTTON)
	protected WebElement product_b;
	
	@FindBy(xpath=CreateDossierPageObjects.CLIENTTYPE_NATURAL_RADIOBUTTON)
	protected WebElement natural_Rb;
	
	@FindBy(xpath=CreateDossierPageObjects.CLIENTTYPE_LEGAL_RADIOBUTTON)
	protected WebElement legal_Rb;
	
	@FindBy(xpath=CreateDossierPageObjects.ACTION_TYPEAHEAD)
	protected WebElement action_Ta;
	
	@FindBy(xpath=CreateDossierPageObjects.DOSSIER_CONTEXT_VALIDATION_MESSAGE)
	protected WebElement context_Validation_m;
	
	@FindBy(xpath=CreateDossierPageObjects.PROCESSNAME_TYPEAHEAD)
	protected WebElement processName_Ta;
	
	@FindBy(xpath=CreateDossierPageObjects.DESCRIPTION_TEXTFIELD)
	protected WebElement description_Tf;
	
	@FindBy(xpath=CreateDossierPageObjects.PRODUCTGROUP_TYPEAHEAD)
	protected WebElement productGroup_Ta;
	
	@FindBy(xpath=CreateDossierPageObjects.LENS_BUTTON)
	protected WebElement lens_b;
	
	@FindBy(xpath=CreateDossierPageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;
	
	@FindBy(xpath=CreateDossierPageObjects.NEXT_BUTTON)
	protected static WebElement next_b;
	
	public CreateDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
		Thread.sleep(2000);
	} 
	
	public void enterBCNumber(String bcNumber)
	{
		clear_b.click();
		bcNumber_Tf.sendKeys(bcNumber);
		validate_b.click();
	}
	
	public void enterBCNumberContractNumberAndValidate(String bcNumber, String contractNumber)
	{
		clear_b.click();
		bcNumber_Tf.sendKeys(bcNumber);
		contractNumber_Tf.sendKeys(contractNumber);
		validate_b.click();
	}
	
	public void createProcessDossier(String bcNumber, String contractNumber, String processName, String description) throws InterruptedException, AWTException, IOException
	{
		clear_b.click();
		bcNumber_Tf.sendKeys(bcNumber);
		contractNumber_Tf.sendKeys(contractNumber);
		validate_b.click();
		waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		Thread.sleep(1000);
		Actions action = new Actions(driver);
		action.click(processName_Ta).sendKeys(processName).sendKeys(Keys.ENTER).perform();
		description_Tf.sendKeys(description);
	}
	
	public void createProductDossier(String bcNumber, String contractNumber, String productGroup, String description)
	{
		clear_b.click();
		bcNumber_Tf.sendKeys(bcNumber);
		contractNumber_Tf.sendKeys(contractNumber);
		validate_b.click();
		waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		product_b.click();
		Actions action = new Actions(driver);
		action.click(productGroup_Ta).sendKeys(productGroup).sendKeys(Keys.ENTER).perform();
		description_Tf.sendKeys(description);
	}
	
	public String getBCNumberValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(bcNumber_Validation_m));
		return bcNumber_Validation_m.getText();
	}
	
	public boolean isIdentificationValidationDisplayed()
	{
		try {
			identification_Validation_m.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}
		
	}
	
	public boolean isContextValidationDisplayed()
	{
		try {
			context_Validation_m.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}
		
	}
	public String getContractNumValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(contractNumber_Validation_m));
		return contractNumber_Validation_m.getText();
	}
	
	public static ImportDocumentPage navigateToImportDocumentPage() throws InterruptedException, AWTException, IOException
	{
		next_b.click();
		return new ImportDocumentPage(driver);
	}
	
}
