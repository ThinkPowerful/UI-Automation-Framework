package com.concord.globalmarkets.pages;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.globalmarkets.constants.SearchDocumentsPageObjects;
import com.concord.utility.DateUtil;

public class SearchDocumentPage extends BasePage implements ISearchDocumentPage {

	@FindBy(xpath = SearchDocumentsPageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;

	@FindBy(xpath = SearchDocumentsPageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.ADDITIONAL_IDENTIFICATION_DROPDOWN)
	protected WebElement additionalIdentification_dd;

	@FindBy(xpath = SearchDocumentsPageObjects.ADDITIONAL_IDENTIFICATION_TEXTFIELD)
	protected WebElement additionalIdentification_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_Ta;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_TYPEAHEAD)
	protected WebElement documentSource_Ta;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.SEARCH_BUTTON)
	protected WebElement search_b;

	@FindBy(xpath = SearchDocumentsPageObjects.ZERO_DOCUMENTS_FOUND_MESSAGE)
	protected WebElement zeroDocumentsFound_m;

	@FindBy(xpath = SearchDocumentsPageObjects.CUSTOMER_INFO_BUTTON)
	protected WebElement customerInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_TYPE_INFO_BUTTON)
	protected WebElement documentTypeInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_INFO_BUTTON)
	protected WebElement documentSourceInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_BUTTON)
	protected WebElement documentNameInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_INFO_BUTTON)
	protected WebElement toInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.CUSTOMER_INFO_MESSAGE)
	protected WebElement customerInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentTypeInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_INFO_MESSAGE)
	protected WebElement documentSourceInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentNameInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_INFO_MESSAGE)
	protected WebElement toInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.CLIENT_NAME_TEXT)
	protected WebElement clientName_t;

	@FindBy(xpath = SearchDocumentsPageObjects.BC_CONTRACT_VALIDATION_MESSAGES)
	protected WebElement bcContractvalidationMessages_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DATE_VALIDATION_MESSAGES)
	protected WebElement dateValidationMessages_m;

	@FindBy(xpath = SearchDocumentsPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;

	@FindBy(xpath = SearchDocumentsPageObjects.CLOSE_BUTTON)
	protected WebElement close_b;

	@FindBy(xpath = SearchDocumentsPageObjects.VIEW_PDF_TOOLBAR)
	protected WebElement viewPDF_toolBar;

	@FindBy(xpath = SearchDocumentsPageObjects.OPTIONS_DROPDOWN)
	protected WebElement options_dd;

	@FindBy(xpath = SearchDocumentsPageObjects.VIEW_ONEBYONE_OPTION)
	protected WebElement view_o;

	@FindBy(xpath = SearchDocumentsPageObjects.DOWNLOAD_AS_ZIP_OPTION)
	protected WebElement download_o;
	
	@FindBy(xpath = SearchDocumentsPageObjects.COMBINED_VIEW_OPTION)
	protected WebElement combinedView_o;
	
	@FindBy(xpath = SearchDocumentsPageObjects.SEPERATE_TABS_VIEW_OPTION)
	protected WebElement seperateTabsView_o;

	@FindBy(xpath = SearchDocumentsPageObjects.SCROLL_TO_TOP_BUTTON)
	protected WebElement scroolToTop_b;

	@FindBy(xpath = SearchDocumentsPageObjects.LENS_BUTTON)
	protected WebElement lens_b;
	
	@FindBy(xpath = SearchDocumentsPageObjects.PAGE_SIZE_DROPDOWN)
	protected WebElement pageSize_Dd;
	
	public Set<String> allWindowHandles;

	public SearchDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		menu.selectBusinessContext("Global Markets");
		menu.selectLanguage("EN");
	}

	public void searchDocumentWithOnlyBCNumber(String BCNumber) {
		try {
			selectOptionByValue(customerAdminType_Dd, "2:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(BCNumber);
			search_b.click();
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void searchDocumentWithOnlyContractNumber(String contractNumber) {
		try {
			selectOptionByValue(customerAdminType_Dd, "2:contract");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(contractNumber);
			search_b.click();
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void searchDocumentWithBcNumAndDates(String bcNumber, String fromDate, String toDate) {
		try {
			clear_b.click();
			selectOptionByValue(customerAdminType_Dd, "2:customer");
			identifier_Tf.sendKeys(bcNumber);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
			wait = new WebDriverWait(driver, 5);
			wait.until(
					ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[contains(@id,'drm-scroll')]"))));
		} catch (Exception e) {
			e.getMessage();
		}

	}

	public void searchDocumentWithBcNumDocTypeAndDates(String bcNumber, String documentType, String fromDate,
			String toDate) {
		try {
			clear_b.click();
			selectOptionByValue(customerAdminType_Dd, "2:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(bcNumber);
			Actions action = new Actions(driver);
			action.click(documentType_Ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
		} catch (Exception e) {
			e.getMessage();
		}

	}

	public void searchDocumentWithBcNumDocSourceAndDates(String bcNumber, String documentSource, String fromDate,
			String toDate) {
		try {
			clear_b.click();
			selectOptionByValue(customerAdminType_Dd, "2:customer");
			identifier_Tf.sendKeys(bcNumber);
			Actions action = new Actions(driver);
			action.click(documentSource_Ta).sendKeys(documentSource).sendKeys(Keys.ENTER).perform();
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
			wait = new WebDriverWait(driver, 5);
			wait.until(
					ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[contains(@id,'drm-scroll')]"))));
		} catch (Exception e) {
			e.getMessage();
		}

	}

	public void searchDocumentWithBCNumber(String BCNumber, String documentType, String documentSource,
			String documentName, String fromDate, String toDate) {
		try {
			selectOptionByValue(customerAdminType_Dd, "2:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(BCNumber);
			Actions action = new Actions(driver);
			action.click(documentType_Ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
			action.click(documentSource_Ta).sendKeys(documentSource).sendKeys(Keys.ENTER).perform();
			documentName_Tf.sendKeys(documentName);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void searchDocumentWithContractNumber(String contractNumber, String documentType, String documentSource,
			String documentName, String fromDate, String toDate) {
		try {
			selectOptionByValue(customerAdminType_Dd, "2:contract");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(contractNumber);
			Actions action = new Actions(driver);
			action.click(documentType_Ta).sendKeys("documentType").sendKeys(Keys.ENTER).perform();
			action.click(documentSource_Ta).sendKeys("documentSource").sendKeys(Keys.ENTER).perform();
			documentName_Tf.sendKeys(documentName);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.sendKeys(toDate);
			search_b.click();
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public boolean isZeroDocumentsFoundMessageDisplayed() {
		wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOf(zeroDocumentsFound_m));
		if (zeroDocumentsFound_m.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public String getValidationMessage() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(bcContractvalidationMessages_m));
		return bcContractvalidationMessages_m.getText();
	}

	public String getDateValidationMessage() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(dateValidationMessages_m));
		return dateValidationMessages_m.getText();
	}

	public boolean isClientNameDisplayed() throws TimeoutException {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(clientName_t));
		wait.until(ExpectedConditions.elementToBeClickable(clear_b));
		if (clientName_t.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public String getTextFromInfoButton(String infoMessageActual) {
		switch (infoMessageActual) {
		case "Customer":
			singleClickOnElement(customerInfo_b);
			return customerInfo_m.getText();

		case "Document Type":
			singleClickOnElement(documentTypeInfo_b);
			return documentTypeInfo_m.getText();

		case "Document Source":
			singleClickOnElement(documentSourceInfo_b);
			return documentSourceInfo_m.getText();

		case "Document Name":
			singleClickOnElement(documentNameInfo_b);
			return documentNameInfo_m.getText();

		case "To":
			singleClickOnElement(toInfo_b);
			return toInfo_m.getText();

		default:
			System.out.println("No Button Found - Invalid button");
			return "";
		}
	}

	public String getClientName() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(clientName_t));
		return clientName_t.getAttribute("value");
	}

	public void closeDocmentPopup() {
		driver.switchTo().defaultContent();
		close_b.click();
	}

	public void viewEarchiveDocumentBasedOnOriginalDocid(String originalDocID) {
		try {
			wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(clear_b));
			driver.findElement(By
					.xpath("//div[contains(@id,'drm-scroll')]//dt[text()='Original document Id']/following-sibling::dd[1][text()='"
							+ originalDocID + "']/../../../..//a[@ng-click='callViewDocument()']"))
					.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void viewBaseDocumentBasedOnDocumentName(String documentName) {
		try {
			wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(clear_b));
			driver.findElements(
					By.xpath("(//table[@class='variables-matrix table table-responsive table-hover']//td[1]//span[@title='"+ documentName+"'])[1]/../..//a[@ng-click='listenerCallbackDocumentPreview()']"))
					.get(0).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void changeThePageSize(String pageSize)
	{
		pageSize_Dd.click();
		driver.findElement(By.xpath("//ul[@class='dropdown-menu']//span[text()='"+pageSize+"']")).click();
	}

	public void selectMultipleBaseDocumentsBasedOnDocumentName(List<String> documentNames) {
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(clear_b));
			for (int i = 0; i < documentNames.size(); i++) {
				Actions actions = new Actions(driver);
				actions.moveToElement(driver.findElement(By
						.xpath("(//table[@class='variables-matrix table table-responsive table-hover']//td[1]//span[@title='"
						+ documentNames.get(i) + "'])[1]/..//a//span"))).click().perform();
			}
	}
	
	public List<String> isDocumentFilteredByOriginalDocType() {
		List<String> attributeValues = new ArrayList<String>();
		int numberofDocs = driver
				.findElements(By.xpath("//table[@class='variables-matrix table table-responsive table-hover']//a[@ng-click='listenerCallbackDocumentPreview()']")).size();
		for (int i = 0; i < numberofDocs; i++) {
			if (numberofDocs != 0) {
				driver.findElements(By.xpath("//table[@class='variables-matrix table table-responsive table-hover']//a[@ng-click='listenerCallbackDocumentPreview()']")).get(i).click();
				String originalDocTypeFromWebPage = driver.findElement(By.xpath("//dt[text()='Original document type']/following-sibling::dd[1]")).getText();
				attributeValues.add(originalDocTypeFromWebPage);
				driver.findElement(By.xpath("//button[text()='Close']")).click();
			} else {
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			}
		}
		return attributeValues;
	}

	public void viewMultipleDocument() {
			scroolToTop_b.click();
			singleClickOnElement(options_dd);
			singleClickOnElement(view_o);
	}

	public void viewNextDocument(String documentName) {
			singleClickOnElement(driver.findElement(By.xpath("//button[contains(text(),'"+documentName+"')]")));
	}

	public void downloadMultipleDocument() {
		scroolToTop_b.click();
		singleClickOnElement(options_dd);
		// Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\AutoItScripts\\Downloaddocument.exe");
		singleClickOnElement(download_o);
	}
	
	public void mergePdfDocuments()
	{
		scroolToTop_b.click();
		singleClickOnElement(options_dd);
		singleClickOnElement(combinedView_o);
	}
	
	public void viewDocumentsInSeperateTabs() {
		scroolToTop_b.click();
		singleClickOnElement(options_dd);
		singleClickOnElement(seperateTabsView_o);
		
	}

	public boolean isFileSuccessfullyDownloaded(String fileNameStartsWith, String fileNameEndsWith)
			throws InterruptedException {
		Thread.sleep(2000);
		File downloadedZipFile = new File(
				System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\DownloadedFiles\\");
		File[] listFiles = downloadedZipFile.listFiles();
		for (int i = 0; i < listFiles.length; i++) {
			if (listFiles[i].isFile()) {
				String fileName = listFiles[i].getName();
				if (fileName.startsWith(fileNameStartsWith) && fileName.endsWith(fileNameEndsWith)) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}
	
	public boolean isPdfMergedSuccessfully()
	{
		if(isElementPresent("//button[text()='Close']")){
			return true;
		}
		else{
			return false;
		}
	}
	
	public int getCountOfDocumentsViewedInSeperateTabs()
	{
		this.allWindowHandles = driver.getWindowHandles();
		ArrayList<String> tabs = new ArrayList<String>(allWindowHandles);
		return tabs.size();
	}

	public SearchCustomerPage navigateToSearchCustomerPage() throws InterruptedException, AWTException, IOException {
		try {
			lens_b.click();
			return new SearchCustomerPage(driver);
		} catch (Exception e) {
			e.printStackTrace();
			return new SearchCustomerPage(driver);
		}
	}

	public String getTextFromIdentifier() {
		return identifier_Tf.getAttribute("value");
	}

	public void searchDocumentWithBcNumberOriginalDocTypeAndDates(String bcNumber, String originalDocumentType,
			String fromDate, String toDate) {
		try {
			clear_b.click();
			selectOptionByValue(customerAdminType_Dd, "2:customer");
			identifier_Tf.sendKeys(bcNumber);
			documentName_Tf.sendKeys(originalDocumentType);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
			wait = new WebDriverWait(driver, 5);
			wait.until(
					ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[contains(@id,'drm-scroll')]"))));
		} catch (Exception e) {
			e.getMessage();
		}

	}

	public void searchDocumentWithBcNumberAdditionalIdentificationAndDates(String bcNumber,
			String additionalIdentificationKey, String additionalIdentificationValue, String fromDate, String toDate) {
		try {
			clear_b.click();
			selectOptionByValue(customerAdminType_Dd, "2:customer");
			identifier_Tf.sendKeys(bcNumber);
			selectOptionByVisibleText(additionalIdentification_dd, additionalIdentificationKey);
			additionalIdentification_Tf.sendKeys(additionalIdentificationValue);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
			wait = new WebDriverWait(driver, 5);
			wait.until(
					ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[contains(@id,'drm-scroll')]"))));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public boolean isDocumentFound(String documentName, String documentID) throws ParseException
	{
		 boolean isdocumentFound=false;
		 int listOfDocuments = driver.findElements(By.xpath("//dd[@title='"+documentName+"']")).size();
		 for(int documentCount=0;documentCount<listOfDocuments;documentCount++)
		 {
				driver.findElements(By.xpath("//dd[@title='"+documentName+"']/../../..//span[@title='View metadata']")).get(documentCount).click();
				 String documentIDActual = driver.findElement(By.xpath("//dt[text()='Document ID']/following-sibling::dd[1]")).getText();
				 if(documentIDActual.equals(documentID))
				 {
					 driver.findElement(By.xpath("//span[@title='Close']")).click();
					 isdocumentFound=true;
					 break;
				 }
				 else
				 {
					 driver.findElement(By.xpath("//span[@title='Close']")).click();
				 }
		 }
		 return isdocumentFound;
	}

	

}
