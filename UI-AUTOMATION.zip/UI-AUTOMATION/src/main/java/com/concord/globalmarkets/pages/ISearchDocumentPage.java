package com.concord.globalmarkets.pages;

public interface ISearchDocumentPage {
	
	public void searchDocumentWithBCNumber(String BCNumber,String documentType,String documentSource,String documentName,String fromDate,String toDate) throws InterruptedException;
	public void searchDocumentWithContractNumber(String contractNumber,String documentType,String documentSource,String documentName,String fromDate,String toDate);
}
