package com.concord.globalmarkets.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.globalmarkets.constants.SearchCustomerPageObjects;
import com.concord.globalmarkets.constants.SearchDocumentsPageObjects;

public class SearchCustomerPage extends BasePage
{
	
	@FindBy(xpath=SearchCustomerPageObjects.NAME_RADIO_BUTTON)
	protected WebElement name_Rb;
	
	@FindBy(xpath=SearchCustomerPageObjects.POSTAL_CODE_RADIO_BUTTON)
	protected WebElement postalCode_Rb;
	
	@FindBy(xpath=SearchCustomerPageObjects.COC_RADIO_BUTTON)
	protected WebElement coc_Rb;
	
	@FindBy(xpath=SearchCustomerPageObjects.SURNAME_TEXTFIELD)
	protected WebElement surname_Tf;
	
	@FindBy(xpath=SearchCustomerPageObjects.INITIALS_TEXTFIELD)
	protected WebElement initials_Tf;
	
	@FindBy(xpath=SearchCustomerPageObjects.STREET_NAME_TEXTFIELD)
	protected WebElement streetname_Tf;
	
	@FindBy(xpath=SearchCustomerPageObjects.HOUSE_NUMBER_TEXTFIELD)
	protected WebElement houseNumber_Tf;
	
	@FindBy(xpath=SearchCustomerPageObjects.CITY_TEXTFIELD)
	protected WebElement city_Tf;
	
	@FindBy(xpath=SearchCustomerPageObjects.DOB_TEXTFIELD)
	protected WebElement dob_Tf;
	
	@FindBy(xpath=SearchCustomerPageObjects.COUNTRY_TYPEAHEAD)
	protected WebElement country_Ta;
	
	@FindBy(xpath=SearchCustomerPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;

	@FindBy(xpath=SearchCustomerPageObjects.SEARCH_BUTTON)
	protected WebElement search_b;
	
	@FindBy(xpath=SearchCustomerPageObjects.POSTAL_CODE_TEXTFIELD)
	protected WebElement postalCode_Tf;
	
	@FindBy(xpath=SearchCustomerPageObjects.COC_TEXTFIELD)
	protected WebElement coc_Tf;
	
	@FindBy(xpath=SearchCustomerPageObjects.CLOSE_BUTTON)
	protected WebElement close_b;
	
	@FindBy(xpath=SearchCustomerPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected WebElement return_To_SearchField_b;
	
	@FindBy(xpath=SearchCustomerPageObjects.SURNAME_VALIDATION_MESSAGE)
	protected WebElement surnameValidationMessage_m;
	
	@FindBy(xpath=SearchCustomerPageObjects.CITY_VALIDATION_MESSAGE)
	protected WebElement cityValidationMessage_m;
	
	@FindBy(xpath=SearchCustomerPageObjects.POSTAL_CODE_VALIDATION_MESSAGE)
	protected WebElement postalCodeValdiationMessage_m;
	
	@FindBy(xpath=SearchCustomerPageObjects.COUNTRYL_CODE_VALIDATION_MESSAGE)
	protected WebElement countryValidationMessage_m;
	
	@FindBy(xpath=SearchCustomerPageObjects.COC_VALIDATION_MESSAGE)
	protected WebElement cocValidationMessage_m;
	
	@FindBy(xpath=SearchCustomerPageObjects.DOB_VALIDATION_MESSAGE)
	protected WebElement dobValidationMessage_m;
	
	@FindBy(xpath=SearchCustomerPageObjects.ZERO_MATCHES_FOUND_MESSAGE)
	protected WebElement zeroMatchesFound_m;
	
	public SearchCustomerPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public void searchCustomersByName(String surName, String initials, String streetName, String houseNumber, String city, String dateOfBirth) throws InterruptedException
	{
			clear_b.click();
			surname_Tf.sendKeys(surName);
			initials_Tf.sendKeys(initials);
			streetname_Tf.sendKeys(streetName);
			houseNumber_Tf.sendKeys(houseNumber);
			city_Tf.sendKeys(city);
			dob_Tf.sendKeys(dateOfBirth);
			search_b.click();
	}
	
	public void searchCustomersByPostalCode(String postalCode, String houseNumber, String country)
	{
			postalCode_Rb.click();
			clear_b.click();
			postalCode_Tf.sendKeys(postalCode);
			houseNumber_Tf.sendKeys(houseNumber);
			Actions action = new Actions(driver);
			action.click(country_Ta).sendKeys(country).sendKeys(Keys.ENTER).perform();
			search_b.click();
	}
	
	public void searchCustomersByCOCNumber(String cocNumber)
	{
			waitForElementToBeClickable(clear_b);
			coc_Rb.click();
			clear_b.click();
			coc_Tf.sendKeys(cocNumber);
			search_b.click();
	}
	
	public String getValidationMessage(String fieldName)
	{
		
		switch (fieldName)
        {
        case "Surname":
        	wait= new WebDriverWait(driver, 10);
    		wait.until(ExpectedConditions.visibilityOf(surnameValidationMessage_m));
    		return surnameValidationMessage_m.getText();
    		
		case "City":
			wait= new WebDriverWait(driver, 10);
    		wait.until(ExpectedConditions.visibilityOf(cityValidationMessage_m));
    		return cityValidationMessage_m.getText();

        case "Postal code":
        	wait= new WebDriverWait(driver, 10);
    		wait.until(ExpectedConditions.visibilityOf(postalCodeValdiationMessage_m));
    		return postalCodeValdiationMessage_m.getText();

        case "Country":
        	wait= new WebDriverWait(driver, 10);
    		wait.until(ExpectedConditions.visibilityOf(countryValidationMessage_m));
    		return countryValidationMessage_m.getText();

        case "COC Number":
        	wait= new WebDriverWait(driver, 10);
    		wait.until(ExpectedConditions.visibilityOf(cocValidationMessage_m));
    		return cocValidationMessage_m.getText();
    		
        case "Date of Birth":
        	wait= new WebDriverWait(driver, 10);
    		wait.until(ExpectedConditions.visibilityOf(dobValidationMessage_m));
    		return dobValidationMessage_m.getText();

        default :
            System.out.println("No Validation Message Found.");
            return "No Validation Message Found.";
        }
		
	}
	
	public List<String> getAllValuesFromaAttributeInSearchCustomerResults(String attributeName)
	{
		List<String> attributeValues= new ArrayList<String>();
		int rowCountOfAlerts=driver.findElements(By.xpath("//div[@class='panel-body']//dt[contains(text(),'"+attributeName+"')]/following-sibling::dd[1]")).size();
			for(int rowIndex=0;rowIndex<rowCountOfAlerts;rowIndex++)
			{
				String attributeValue=driver.findElements(By.xpath("//div[@class='panel-body']//dt[contains(text(),'"+attributeName+"')]/following-sibling::dd[1]")).get(rowIndex).getText();
				attributeValues.add(attributeValue);
			}
		return attributeValues;
	}
	
	public void selectCustomerByName(String customerName)
	{
		driver.findElement(By.xpath("//div[@class='panel-body']//dt[contains(text(),'Name')]/following-sibling::dd[1][text()='"+customerName+"']/../../..//input[@type='radio']")).click();
		return_To_SearchField_b.click();
	}
	
	public boolean isZeroMatchesFoundMessageDisplayed()
	{
		waitForVisiblityOfElement(zeroMatchesFound_m);
		if(zeroMatchesFound_m.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	

}
