package com.concord.globalmarkets.constants;

public class CreateDossierPageObjects {
	
	public static final String CREATEDOSSIER_LABLE = "//h2[text()='Create dossier']";
	public static final String BCNUMBER_TEXTFIELD = "//input[@id='bcNumber']";
	public static final String CONTRACT_NUMBER_TEXTFIELD = "//input[@id='crcNumber']";
	public static final String CLEAR_BUTTON = "//button[text()='Clear']";
	public static final String VALIDATE_BUTTON = "//button[text()='Validate']";
	public static final String TYPE_PROCESS_BUTTON = "(//input[@id='processOrProduct'])[1]";
	public static final String TYPE_PRODUCT_BUTTON = "(//input[@id='processOrProduct'])[2]";
	public static final String CLIENTTYPE_NATURAL_RADIOBUTTON = "//input[@value='natural']";
	public static final String CLIENTTYPE_LEGAL_RADIOBUTTON= "//input[@value='legal']";
	public static final String ACTION_TYPEAHEAD = "//input[@id='actionContextId']";
	public static final String PROCESSNAME_TYPEAHEAD = "(//input[@id='processName'])[1]";
	public static final String DESCRIPTION_TEXTFIELD = "//input[@id='description']";
	public static final String PRODUCTGROUP_TYPEAHEAD = "(//input[@id='productName'])[1]";
	public static final String CANCEL_BUTTON = "//button[text()='Cancel']";
	public static final String NEXT_BUTTON = "//button[text()='Next']";
	public static final String LENS_BUTTON="//span[@title='Search Customer']";
	public static final String DOSSIER_IDENTIFICATION_VALIDATION_MESSAGE="//form[@name='dossierIdentificationForm']//p[text()='Please provide sufficient information to proceed']";
	public static final String BC_NUMBER_VALIDATION_MESSAGE="//input[@id='bcNumber']/../../div[@id='identifier']//p//span";
	public static final String CONTRACT_NUMBER_VALIDATION_MESSAGE="//input[@id='crcNumber']/../../div[@id='identifier']//p//span";
	public static final String DOSSIER_CONTEXT_VALIDATION_MESSAGE="//form[@name='dossierContextForm']//p[text()='Please provide sufficient information to proceed']";
}
