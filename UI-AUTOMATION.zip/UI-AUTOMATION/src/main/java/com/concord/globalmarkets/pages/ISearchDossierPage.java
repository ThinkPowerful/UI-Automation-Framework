package com.concord.globalmarkets.pages;

public interface ISearchDossierPage {
	
	public void searchDossierWithBCNumber(String BCNumber,String dossierName,String fromDate,String toDate) throws InterruptedException;
	public void searchDossierWithContractNumber(String contractNumber,String dossierName,String fromDate,String toDate) throws InterruptedException;


}
