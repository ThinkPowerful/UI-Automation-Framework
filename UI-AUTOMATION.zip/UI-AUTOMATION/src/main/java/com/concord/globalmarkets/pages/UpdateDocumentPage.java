package com.concord.globalmarkets.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.globalmarkets.constants.UpdateDocumentPageObjects;

public class UpdateDocumentPage extends BasePage
{
	
	@FindBy(xpath=UpdateDocumentPageObjects.EDIT_DOCUMENT_TITLE)
	protected WebElement editDocument_t;
	
	@FindBy(xpath=UpdateDocumentPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_tf;
	
	@FindBy(xpath=UpdateDocumentPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_ta;
	
	@FindBy(xpath=UpdateDocumentPageObjects.BC_NUMBER_TEXTFIELD)
	protected WebElement bcNumber_tf;
	
	@FindBy(xpath=UpdateDocumentPageObjects.CONTRACT_NUMBER_TEXTFIELD)
	protected WebElement contractNumber_tf;
	
	@FindBy(xpath=UpdateDocumentPageObjects.VALID_FROM_TEXTFIELD)
	protected WebElement validFrom_tf;
	
	@FindBy(xpath=UpdateDocumentPageObjects.VALID_TO_TEXTFIELD)
	protected WebElement validTo_tf;
	
	@FindBy(xpath=UpdateDocumentPageObjects.SCANNER_ID_TEXTFIELD)
	protected WebElement scannerID_tf;
	
	@FindBy(xpath=UpdateDocumentPageObjects.CANCEL_BUTTOM)
	protected WebElement cancel_b;
	
	@FindBy(xpath=UpdateDocumentPageObjects.SUBMIT_BUTTOM)
	protected WebElement submit_b;
	
	@FindBy(xpath=UpdateDocumentPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected WebElement returnToSearchScreen_b;
	
	@FindBy(xpath=UpdateDocumentPageObjects.FROM_DATE_VALIDATION_MESSAGE)
	protected WebElement fromDateValidation_m;
	
	@FindBy(xpath=UpdateDocumentPageObjects.TO_DATE_VALIDATION_MESSAGE)
	protected WebElement toDateValidation_m;
	
	@FindBy(xpath=UpdateDocumentPageObjects.MANDATORY_VALIDATION_MESSAGE)
	protected WebElement mandatoryValidation_m;
	
	
	public UpdateDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public void updateAllEditablefields(String documentName, String documentType , 
			String validFrom, String validTo, String scannerID) throws InterruptedException{
		documentName_tf.clear();
		documentName_tf.sendKeys(documentName);
		//Actions action = new Actions(driver);
		//action.click(documentType_ta).sendKeys(Keys.chord(Keys.CONTROL, "a")).sendKeys(Keys.BACK_SPACE).perform();
		//Thread.sleep(1000);
		//action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		validFrom_tf.clear();
		validFrom_tf.sendKeys(validFrom);
		validTo_tf.clear();
		validTo_tf.sendKeys(validTo);
		scannerID_tf.clear();
		scannerID_tf.sendKeys(scannerID);
		submit_b.click();
	}
	
	public boolean isDocumentUpdatedSuccessfully()
	{
		try{
		boolean updateStatusMessage = driver.findElement(By.xpath("//p[text()='Information about the document updated successfully']")).isDisplayed();
		return updateStatusMessage;
		}
		catch(Exception e){
			return false;
		}
	}
	
	public boolean areFieldsnonEditable()
	{
		try{
			boolean bcNumberNonEditable = bcNumber_tf.getAttribute("disabled").equals("true");
			boolean contractNumberNonEditable = contractNumber_tf.getAttribute("disabled").equals("true");
			boolean isFieldsNonEditable = bcNumberNonEditable && contractNumberNonEditable;
			return isFieldsNonEditable;
		}catch(Exception e){
			return false;
		}
	}
	
	public String getFromDateValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(fromDateValidation_m));
		return fromDateValidation_m.getText();
	}
	
	public String getToDateValidationMessage()
	{
		wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(toDateValidation_m));
		return toDateValidation_m.getText();
	}
	
	public boolean isMandatoryFieldValidationDisplayed()
	{
		try{
		documentName_tf.clear();
		Actions action = new Actions(driver);
		action.click(documentType_ta).sendKeys(Keys.chord(Keys.CONTROL, "a")).sendKeys(Keys.BACK_SPACE).perform();
		submit_b.click();
		return mandatoryValidation_m.isDisplayed();
		}catch(Exception e){
			return false;
		}
	}
	
	public SearchDossierPage returnToSearchScreen() throws InterruptedException, AWTException, IOException
	{
		returnToSearchScreen_b.click();
		return new SearchDossierPage(driver);
	}
	
	public SearchDossierPage cancelAndReturnToSearchScreen() throws InterruptedException, AWTException, IOException
	{
		cancel_b.click();
		return new SearchDossierPage(driver);
	}
}
