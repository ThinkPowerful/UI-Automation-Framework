package com.concord.ctv.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;
import com.concord.ctv.constants.SearchDossierPageObjects;
//import com.concord.globalmarkets.constants.ImportDocumentPageObjects;
//import com.concord.globalmarkets.constants.SearchDossierPageObjects;
import com.concord.utility.DateUtil;

public class SearchDossierPage extends BasePage
{

	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_TAB)
	protected WebElement dossier_tab;

	@FindBy(xpath=SearchDossierPageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;

	@FindBy(xpath=SearchDossierPageObjects.IDENTIFIER_TEXTFIELD)
	protected static WebElement identifier_Tf;

	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_NAME_TEXTFIELD)
	protected WebElement dossierName_Tf;

	@FindBy(xpath=SearchDossierPageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;

	@FindBy(xpath=SearchDossierPageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;

	@FindBy(xpath=SearchDossierPageObjects.SEARCH_BUTTON)
	protected static WebElement search_b;

	@FindBy(xpath=SearchDossierPageObjects.ZERO_DOSSIER_FOUND_MESSAGE)
	protected WebElement zeroDossierFound_m;

	@FindBy(xpath=SearchDossierPageObjects.CUSTOMER_INFO_BUTTON)
	protected WebElement customerInfo_b;

	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_NAME_INFO_BUTTON)
	protected WebElement dossierNameInfo_b;

	@FindBy(xpath=SearchDossierPageObjects.TO_INFO_BUTTON)
	protected WebElement toInfo_b;

	@FindBy(xpath=SearchDossierPageObjects.DATE_VALIDATION_MESSAGES)
	protected WebElement dateValidationMessages_m;

	@FindBy(xpath=SearchDossierPageObjects.CLEAR_BUTTON)
	protected static WebElement clear_b;

	@FindBy(xpath=SearchDossierPageObjects.CLOSE_BUTTON)
	protected WebElement close_b;

	@FindBy(xpath=SearchDossierPageObjects.VIEW_BUTTON)
	protected WebElement view_b;

	@FindBy(xpath=SearchDossierPageObjects.NEXT_BUTTON)
	protected WebElement next_b;

	@FindBy(xpath=SearchDossierPageObjects.SEARCH_VIEW_BUTTON)
	protected static WebElement searchView_b;

	@FindBy(xpath=SearchDossierPageObjects.SCROLL_TOP_BUTTON)
	protected WebElement scroolTop_b;

	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_METADATA_INFO_BUTTON)
	protected WebElement dossierMetadataInfo_b;

	@FindBy(xpath=SearchDossierPageObjects.ACTIONS_DROPDOWN)
	protected static List<WebElement> actions_dd;

	@FindBy(xpath=SearchDossierPageObjects.IMPORT_OPTION)
	protected List<WebElement> import_o;

	@FindBy(xpath=SearchDossierPageObjects.EDIT_OPTION)
	protected static List<WebElement> edit_o;

	@FindBy(xpath=SearchDossierPageObjects.CLOSE_OPTION)
	protected List<WebElement> close_o;

	@FindBy(xpath = SearchDossierPageObjects.SELECT_ALL_BUTTON)
	protected static WebElement selectAll_b;

	@FindBy(xpath = SearchDossierPageObjects.DESELECT_ALL_BUTTON)
	protected static WebElement deSelectAll_b;

	@FindBy(xpath = SearchDossierPageObjects.NUMBER_OF_DOCUMENTS_LABEL)
	protected static WebElement numberOfDocuments_lb;

	@FindBy(xpath = SearchDossierPageObjects.SELECTED_CHECKBOXES)
	protected static WebElement selected_cb;

	@FindBy(xpath = SearchDossierPageObjects.DOCUMENT_PREVIEW_TITLE_LABEL)
	protected static WebElement documentPreviewTitle_lb;

	@FindBy(xpath = SearchDossierPageObjects.DOCUMENT_PREVIEW_CLOSE_BUTTON)
	protected static WebElement documentPreviewClose_b;

	@FindBy(xpath=SearchDossierPageObjects.CUSTOMER_INFO_MESSAGE)
	protected WebElement customerInfo_m;

	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_NAME_INFO_MESSAGE)
	protected WebElement dossierNameInfo_m;

	@FindBy(xpath=SearchDossierPageObjects.TO_INFO_MESSAGE)
	protected WebElement toInfo_m;

	static int openedDossier;

	public SearchDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
		dossier_tab.click();
		Thread.sleep(2000);
	}

	public static void searchDossierWithCTVNumber(String CTVNumber)
			throws InterruptedException {

		clear_b.click();
		identifier_Tf.sendKeys(CTVNumber);
		search_b.click();
	}

	public List<String> getAllDossiersFromSearchResults()
	{
		List<String> dossierNames= new ArrayList<String>();
		int dossierCounts=driver.findElements(By.xpath("//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[@class='ng-binding']")).size();
		for(int dossierCount=0;dossierCount<dossierCounts;dossierCount++)
		{
			String dossierName=driver.findElements(By.xpath("//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[@class='ng-binding']")).get(dossierCount).getText();
			dossierNames.add(dossierName);
		}
		return dossierNames;
	}

	public boolean isDossierFound(String dossierName, String creationDate) throws ParseException
	{
		boolean isdossierFound=false;
		int listOfDossiers = driver.findElements(By.xpath("//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[contains(text(),'"+dossierName+"')]")).size();
		for(int dossierCount=0;dossierCount<listOfDossiers;dossierCount++)
		{
			driver.findElements(By.xpath("//div[contains(@class,'panel-title-wrapper cursor-click-enable ng-scope')]//span[contains(text(),'"+dossierName+"')]")).get(dossierCount).click();
			waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
			scrollToTop(dossierCount+1);
			dossierMetadataInfo_b.click();
			String creationDateTimeActual = driver.findElement(By.xpath("//dl[@ng-if='dossierMetadata.dossierName']//dt[text()='Created on']/following-sibling::dd[1]")).getText();
			String creationDateTimeForJenkins=DateUtil.oneHourBefore(creationDate);
			if(creationDateTimeActual.equals(creationDate) || creationDateTimeActual.equals(creationDateTimeForJenkins))
			{
				driver.findElement(By.xpath("//span[@title='Close']")).click();
				isdossierFound=true;
				openedDossier = dossierCount;
				break;
			}
			else
			{
				driver.findElement(By.xpath("//span[@title='Close']")).click();
			}
		}
		return isdossierFound;
	}

	public List<String> getAllDocumentIdByDocumentName(String documentName)
	{
		List<String> documentIdees= new ArrayList<String>();
		int documentsCount=driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+documentName+"']/../../../..//span[@title='View metadata']")).size();
		for(int documentCount=0;documentCount<documentsCount;documentCount++)
		{
			driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+documentName+"']/../../../..//span[@title='View metadata']")).get(documentCount).click();
			String documentId=driver.findElement(By.xpath("//dl[@class='custom-dl-metadata ng-scope']//dt[text()='Document ID']/following-sibling::dd[1]")).getText();
			documentIdees.add(documentId);
			searchView_b.click();
		}
		return documentIdees;
	}

	public void scrollToTop()
	{
		try
		{
			scroolTop_b.isDisplayed();
			singleClickOnElement(scroolTop_b);
		}
		catch(Exception e)
		{
			System.out.println("Not Displayed " +e);
		}
	}

	public void scrollToTop(int dossierIndex)
	{
		try
		{
			driver.findElement(By.xpath("(//span[text()='Scroll top'])["+dossierIndex+"]")).isDisplayed();
			singleClickOnElement(driver.findElement(By.xpath("(//span[text()='Scroll top'])["+dossierIndex+"]")));
		}
		catch(Exception e)
		{
			System.out.println("Not Displayed " +e);
		}
	}

	public void viewAllMetadataForADocument(String documentName, int documentIndex)
	{
		driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+documentName+"']/../../../..//span[@title='View metadata']")).get(documentIndex).click();
	}

	public String getTextFromInfoButton(String infoMessageActual)
	{
		switch (infoMessageActual)
		{
		case "CTV Customer":
			singleClickOnElement(customerInfo_b);
			return customerInfo_m.getText();

		case "Dossier Name":
			singleClickOnElement(dossierNameInfo_b);
			return dossierNameInfo_m.getText();

		case "To":
			singleClickOnElement(toInfo_b);
			return toInfo_m.getText();

		default :
			System.out.println("No Button Found - Invalid button");
			return "";
		}
	}

	public void searchDocumentInsideDossier(String documentName)
	{
		int searchDocumentFieldCount = driver.findElements(By.xpath("//input[@placeholder='Search a document']")).size();
		for(int i=0;i<searchDocumentFieldCount;i++)
		{
			try {
				if(driver.findElements(By.xpath("//input[@placeholder='Search a document']")).get(i).isDisplayed())
				{
					driver.findElements(By.xpath("//input[@placeholder='Search a document']")).get(i).sendKeys(documentName);
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void previewDocumentInsideDossier(String expectedDocumentName)
	{
		int documents = driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+expectedDocumentName+"']/../../../..//a[@ng-click='callDocumentView()']")).size();
		if(documents>0){
			driver.findElements(By.xpath("//dt[text()='Name']/following-sibling::dd[1][normalize-space(text()) = '"+expectedDocumentName+"']/../../../..//a[@ng-click='callDocumentView()']")).get(0).click();
		}else{
			throw new NoSuchElementException();
		}
	}

	public static void navigateToCreateDossierPage() throws InterruptedException, AWTException, IOException
	{
		searchView_b.click();
	}

}
