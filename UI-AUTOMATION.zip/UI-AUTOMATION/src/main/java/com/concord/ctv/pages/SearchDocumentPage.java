package com.concord.ctv.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.ctv.constants.SearchDocumentsPageObjects;
//import com.concord.globalmarkets.pages.ImportDocumentPage;
import com.concord.globalmarkets.pages.ImportDocumentPage;

public  class SearchDocumentPage extends BasePage  {


	@FindBy(xpath = SearchDocumentsPageObjects.IDENTIFICATION_DROPDOWN_CTV)
	protected WebElement identification_dropdown_ctv;

	@FindBy(xpath = SearchDocumentsPageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_Ta;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_TYPEAHEAD)
	protected WebElement documentSource_Ta;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.SEARCH_BUTTON)
	protected WebElement search_b;

	@FindBy(xpath = SearchDocumentsPageObjects.ZERO_DOCUMENTS_FOUND_MESSAGE)
	protected WebElement zeroDocumentsFound_m;


	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_TYPE_INFO_BUTTON)
	protected WebElement documentTypeInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_INFO_BUTTON)
	protected WebElement documentSourceInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_BUTTON)
	protected WebElement documentNameInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_INFO_BUTTON)
	protected WebElement toInfo_b;


	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentTypeInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_INFO_MESSAGE)
	protected WebElement documentSourceInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentNameInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_INFO_MESSAGE)
	protected WebElement toInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.CTV_NUMBER_VALIDATION_MESSAGES)
	protected WebElement ctvnumbervalidationMessages_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DATE_VALIDATION_MESSAGES)
	protected WebElement dateValidationMessages_m;

	@FindBy(xpath = SearchDocumentsPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;

	@FindBy(xpath = SearchDocumentsPageObjects.CLOSE_BUTTON)
	protected WebElement close_b;

	@FindBy(xpath = SearchDocumentsPageObjects.VIEW_PDF_TOOLBAR)
	protected WebElement viewPDF_toolBar;

	@FindBy(xpath = SearchDocumentsPageObjects.OPTIONS_DROPDOWN)
	protected WebElement options_dd;

	@FindBy(xpath = SearchDocumentsPageObjects.VIEW_ONEBYONE_OPTION)
	protected WebElement view_o;

	@FindBy(xpath = SearchDocumentsPageObjects.DOWNLOAD_AS_ZIP_OPTION)
	protected WebElement download_o;

	@FindBy(xpath = SearchDocumentsPageObjects.SCROLL_TO_TOP_BUTTON)
	protected WebElement scroolToTop_b;

	@FindBy(xpath = SearchDocumentsPageObjects.NEXT_BUTTON)
	protected WebElement next_b;

	@FindBy(xpath = SearchDocumentsPageObjects.LENS_BUTTON)
	protected WebElement lens_b;

	@FindBy(xpath=SearchDocumentsPageObjects.SORT_BY_BUTTON)
	protected WebElement sortBy_b;

	@FindBy(xpath=SearchDocumentsPageObjects.SORT_DATE_OPTION)
	protected WebElement sortByDate_o;

	/**@FindBy(xpath=SearchDocumentsPageObjects.SORT_RELAVANCE_OPTION)
	protected WebElement sortByRelvance_o;**/

	@FindBy(xpath=SearchDocumentsPageObjects.SORT_ASCENDING_OPTION)
	protected WebElement sortByAscending_o;

	@FindBy(xpath=SearchDocumentsPageObjects.SORT_DESCENDING_OPTION)
	protected WebElement sortByDescending_o;

	@FindBy(xpath=SearchDocumentsPageObjects.IMPORT_DOCUMENT_BUTTON)
	protected static WebElement importDocument_b;
	
	@FindBy(xpath=SearchDocumentsPageObjects.DOSSIER_SELECT)
	protected static WebElement dossierSelect_b;
	
	@FindBy(xpath=SearchDocumentsPageObjects.ACTION_BUTTON)
	protected static WebElement action_b;
	
	@FindBy(xpath=SearchDocumentsPageObjects.IMPORT_BUTTON)
	protected static WebElement import_b;
	
	@FindBy(xpath=SearchDocumentsPageObjects.IMPORT_ICON)
	protected static WebElement import_i;
	
	public SearchDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException
	{
		super(driver);
		PageFactory.initElements(driver, this);
		menu.selectBusinessContext("CTV");
		menu.selectLanguage("EN");

	}

	public void searchDocumentWithCtvNumber(String ctvnumber, String fromDate, String toDate) {
		try {
			clear_b.click();
			selectOptionByValue(identification_dropdown_ctv, "16:customer");
			identifier_Tf.sendKeys(ctvnumber);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
			wait = new WebDriverWait(driver, 5);
			wait.until(
					ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//div[contains(@id,'drm-scroll')]"))));
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void sortDocumentsBasedOnCreationDate(String sortingOrder)
	{
		waitForElementToBeClickable(clear_b);
		sortBy_b.click();
		sortByDate_o.click();
		waitForElementToBeClickable(clear_b);
		switch (sortingOrder)
		{
		case "Ascending":
			sortBy_b.click();
			sortByAscending_o.click();
			waitForElementToBeClickable(clear_b);
			break;

		case "Descending":
			sortBy_b.click();
			sortByDescending_o.click();
			waitForElementToBeClickable(clear_b);
			break;
		}
	}


	public void searchDocumentWithOnlyCtvNumber(String ctvnumber) 
	{ 
		try {
			selectOptionByValue(identification_dropdown_ctv, "16:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(ctvnumber);
			search_b.click(); } 
		catch (Exception e)
		{ e.getMessage(); } }



	public String getDateValidationMessage() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(dateValidationMessages_m));
		return dateValidationMessages_m.getText();
	}

	public String getValidationMessage() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(ctvnumbervalidationMessages_m));
		System.out.println(ctvnumbervalidationMessages_m.getText());
		return ctvnumbervalidationMessages_m.getText();
	}



	public void searchDocumentWithCtvNumberDates(String ctvnumber, String documentType, String documentSource,
			String documentName, String fromDate, String toDate) {
		try {
			selectOptionByValue(identification_dropdown_ctv, "16:customer");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(ctvnumber);
			Actions action = new Actions(driver);
			action.click(documentType_Ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
			action.click(documentSource_Ta).sendKeys(documentSource).sendKeys(Keys.ENTER).perform();
			documentName_Tf.sendKeys(documentName);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
		} catch (Exception e) {
			e.getMessage();
		}

	}

	public static ImportDocumentPage navigateToCreateDocumentPageOfCtv() throws InterruptedException, AWTException, IOException {
		importDocument_b.click();
		return new ImportDocumentPage(driver);

	}
	public void closeDocmentPopup() {
		driver.switchTo().defaultContent();
		close_b.click();
	}
	
	public static ImportDocumentPage navigateToSearchDossierScreen() throws InterruptedException, AWTException, IOException {
		importDocument_b.click();
		return new ImportDocumentPage(driver);
		
	}
	public void navigateToCreateDossierPageForCtv() throws InterruptedException, AWTException, IOException {
		dossierSelect_b.click();
		action_b.click();
		import_b.click();
		import_i.click();
		Thread.sleep(2000);
		
	}

}


