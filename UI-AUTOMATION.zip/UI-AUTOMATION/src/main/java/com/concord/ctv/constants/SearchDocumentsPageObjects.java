package com.concord.ctv.constants;

public class SearchDocumentsPageObjects {

	public static final String IDENTIFICATION_DROPDOWN_CTV = "//select[@ng-model='searchObject.adminType']";
	public static final String IDENTIFIER_TEXTFIELD = "//input[@id='identifier']";
	public static final String DOCUMENT_TYPE_TYPEAHEAD = "//input[@ng-model='$select.search']";
	public static final String DOCUMENT_SOURCE_TYPEAHEAD = "(//input[@ng-model='searchObject.docSource'])[1]";
	public static final String DOCUMENT_NAME_TEXTFIELD = "(//input[@ng-model='searchObject.objectName'])";
	public static final String FROM_DATE_TEXTFIELD = "//input[@id='fromDate']";
	public static final String TO_DATE_TEXTFIELD = "//input[@id='toDate']";
	public static final String SEARCH_BUTTON = "//button[@class='btn btn-primary ng-scope']";
	public static final String CLEAR_BUTTON = "//button[text()='Clear']";
	public static final String ZERO_DOCUMENTS_FOUND_MESSAGE = "//span[contains(text(),'document(s) found')]";
	public static final String CTV_INFO_BUTTON = "//button[@id='enableIText1']";
	public static final String DOCUMENT_TYPE_INFO_BUTTON = "//button[@id='enableIText2']";
	public static final String DOCUMENT_SOURCE_INFO_BUTTON = "//button[@id='enableIText3']";
	public static final String DOCUMENT_NAME_INFO_BUTTON = "//button[@id='enableIText5']";
	public static final String TO_INFO_BUTTON = "//button[@id='enableIText6']";
	public static final String CTV_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String DOCUMENT_TYPE_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String DOCUMENT_SOURCE_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String DOCUMENT_NAME_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String TO_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
	public static final String CTV_NUMBER_VALIDATION_MESSAGES = "//div[@id='identifierAdministration']//p/span";
	public static final String DATE_VALIDATION_MESSAGES = "//div[@id='datePicker']//span";
	public static final String VIEW_PDF_TOOLBAR = "//div[@id='toolbarViewerMiddle']";
	public static final String CLOSE_BUTTON = "//button[text()='Close']";
	public static final String SCROLL_TO_TOP_BUTTON = "//a[@ng-click='goTop()']";
	public static final String OPTIONS_DROPDOWN = "//button[@id='documentsActionButtonId']";
	public static final String VIEW_ONEBYONE_OPTION = "//a[text()='View one by one']";
	public static final String NEXT_BUTTON = "//button[text()='Next']";
	public static final String DOWNLOAD_AS_ZIP_OPTION = "//a[text()='Download as Zip']";
	public static final String LENS_BUTTON="//span[@title='Search Customer']";
	public static final String SORT_BY_BUTTON = "//button[@id='documentsFilterButtonId']";
	public static final String SORT_DATE_OPTION = "//button[@id='documentsFilterButtonId']/following-sibling::ul//a[contains(text(),'Date')]";
	public static final String SORT_ASCENDING_OPTION = "//button[@id='documentsFilterButtonId']/following-sibling::ul//a[contains(text(),'Ascending')]";
	public static final String SORT_DESCENDING_OPTION = "//button[@id='documentsFilterButtonId']/following-sibling::ul//a[contains(text(),'Descending')]";
	public static final String IMPORT_DOCUMENT_BUTTON = "//span[@title='Import ']";
	public static final String DOSSIER_SELECT ="//span[contains(text(),'New_WDB_87654321_05122019')]";
	public static final String ACTION_BUTTON ="//span[contains(text(),'Actions')]";
	public static final String IMPORT_BUTTON ="//span[contains(text(),'Import')]";
	public static final String IMPORT_ICON ="//span[@class='pull-right drmicon drmicon-md drmicon-upload2 ng-scope']";
}
