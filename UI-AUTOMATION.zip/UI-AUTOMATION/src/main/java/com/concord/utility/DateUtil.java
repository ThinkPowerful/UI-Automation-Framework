package com.concord.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class DateUtil 
{
	
	public static Date date1;
	public static Date date2;
	
	public static Date getCurrentdate() throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		String currentDate=dateFormat.format(date);
		return dateFormat.parse(currentDate);
	}
	
	public static Date getCurrentdateInddMMyyyy() throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
		Date date = new Date();
		String currentDate=dateFormat.format(date);
		return dateFormat.parse(currentDate);
	}
	
	public static String getCurrentdateInddMMyyyyWithHyphen() throws ParseException
	{
		String pattern = "dd-MM-yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		return date;
	}
	
	public static Date getCurrentDateMinusOneDay() throws ParseException
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String currentDateMinusOne = dateFormat.format(cal.getTime());
		return dateFormat.parse(currentDateMinusOne);
	}
	
	public static Date getCurrentDateMinusTwoDays() throws ParseException
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -2);
		String currentDateMinusTwo=dateFormat.format(cal.getTime());
		return dateFormat.parse(currentDateMinusTwo);
	}
	
	public static Date getCurrentDateMinusFourDays() throws ParseException
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -4);
		String currentDateMinusFour = dateFormat.format(cal.getTime());
		return dateFormat.parse(currentDateMinusFour);
	}
	
	public static String convertDateToString(Date date)
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		return dateFormat.format(date);
	}
	
	public static String convertDateToStringInddMMyyyy(Date date)
	{
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
		return dateFormat.format(date);
	}
	
	public static Date convertStringToDate(String date) throws ParseException
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		return dateFormat.parse(date);
	}
	
	public static boolean compareDatesDescending(String date1, String date2) throws ParseException
	{
		SimpleDateFormat format=new SimpleDateFormat("dd-MM-yyyy");
		Date dateOne=format.parse(date1);
		Date dateTwo=format.parse(date2);
		if(dateOne.compareTo(dateTwo)==0 || dateOne.compareTo(dateTwo)==-1)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public static boolean compareDatesAscending(String date1, String date2) throws ParseException
	{
		SimpleDateFormat format=new SimpleDateFormat("dd-MM-yyyy");
		Date dateOne=format.parse(date1);
		Date dateTwo=format.parse(date2);
		if(dateOne.compareTo(dateTwo)==0 || dateOne.compareTo(dateTwo)==-1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public static String oneHourBefore(String dateTime) throws ParseException
	{
		String time = dateTime.substring(11, 16);
		SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm");
		dateFormat.getCalendar().add(Calendar.HOUR, -1);
	    Date date = dateFormat.parse(time);
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    calendar.add(Calendar.HOUR, -1);
	    String oneHourBeforeTime = calendar.getTime().toString().substring(11, 16);
	    String oneHourBeforeDateTime=dateTime.substring(0, 11)+oneHourBeforeTime;
	    return oneHourBeforeDateTime;
		
	}
	
	public static String twoHourBefore(String dateTime) throws ParseException
	{
		String time = dateTime.substring(11, 16);
		SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm");
		dateFormat.getCalendar().add(Calendar.HOUR, -2);
	    Date date = dateFormat.parse(time);
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    calendar.add(Calendar.HOUR, -2);
	    String twoHourBeforeTime = calendar.getTime().toString().substring(11, 16);
	    String twoHourBeforeDateTime=dateTime.substring(0, 11)+twoHourBeforeTime;
	    return twoHourBeforeDateTime;
		
	}
	

}
