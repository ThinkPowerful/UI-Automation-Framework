package com.concord.cib.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;
import com.concord.cib.constants.CreateDossierPageObjects;
import com.concord.globalmarkets.pages.ImportDocumentPage;



public class CreateDossierPage extends BasePage
{
	@FindBy(xpath=CreateDossierPageObjects.CREATEDOSSIER_LABLE)
	protected WebElement createDossier_l;
	
	@FindBy(xpath=CreateDossierPageObjects.BCNUMBER_TEXTFIELD)
	protected WebElement bcNumber_Tf;
	
	@FindBy(xpath=CreateDossierPageObjects.CONTRACT_NUMBER_TEXTFIELD)
	protected WebElement contractNumber_Tf;
	
	@FindBy(xpath=CreateDossierPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;
	
	@FindBy(xpath=CreateDossierPageObjects.VALIDATE_BUTTON)
	protected WebElement validate_b;
	
	@FindBy(xpath=CreateDossierPageObjects.TYPE_PROCESS_BUTTON)
	protected WebElement process_b;
	
	@FindBy(xpath=CreateDossierPageObjects.TYPE_PRODUCT_BUTTON)
	protected WebElement product_b;
	
	@FindBy(xpath=CreateDossierPageObjects.CLIENTTYPE_NATURAL_RADIOBUTTON)
	protected WebElement natural_Rb;
	
	@FindBy(xpath=CreateDossierPageObjects.CLIENTTYPE_LEGAL_RADIOBUTTON)
	protected WebElement legal_Rb;
	
	@FindBy(xpath=CreateDossierPageObjects.ACTION_TYPEAHEAD)
	protected WebElement action_Ta;
	
	@FindBy(xpath=CreateDossierPageObjects.DOSSIER_CONTEXT_VALIDATION_MESSAGE)
	protected WebElement context_Validation_m;
	
	@FindBy(xpath=CreateDossierPageObjects.PROCESSNAME_TYPEAHEAD)
	protected WebElement processName_Ta;
	
	@FindBy(xpath=CreateDossierPageObjects.DESCRIPTION_TEXTFIELD)
	protected WebElement description_Tf;
	
	@FindBy(xpath=CreateDossierPageObjects.PRODUCTGROUP_TYPEAHEAD)
	protected WebElement productGroup_Ta;
	
	@FindBy(xpath=CreateDossierPageObjects.LENS_BUTTON)
	protected WebElement lens_b;
	
	@FindBy(xpath=CreateDossierPageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;
	
	@FindBy(xpath=CreateDossierPageObjects.NEXT_BUTTON)
	protected static WebElement next_b;
	
	@FindBy(xpath=CreateDossierPageObjects.PROTECTED_CHECKBOX)
	protected static WebElement protected_cb;
	
	@FindBy(xpath=CreateDossierPageObjects.ADD_MEMBERS_ICON)
	protected static WebElement add_members_i;
	
	@FindBy(xpath=CreateDossierPageObjects.MEMBERS_SEARCH_TEXTFELD)
	protected static WebElement members_search_tf;
	
	@FindBy(xpath=CreateDossierPageObjects.ADD_MEMBER_BUTTON)
	protected static WebElement add_member_b;
	
	@FindBy(xpath=CreateDossierPageObjects.CLOSE_BUTTON)
	protected static WebElement close_b;
	
	public CreateDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
		Thread.sleep(2000);
	}
	
	public void enterBCNumber(String bcNumber)
	{
		clear_b.click();
		bcNumber_Tf.sendKeys(bcNumber);
		validate_b.click();
	}
	
	public void enterBCNumberContractNumberAndValidate(String bcNumber, String contractNumber)
	{
		clear_b.click();
		bcNumber_Tf.sendKeys(bcNumber);
		contractNumber_Tf.sendKeys(contractNumber);
		validate_b.click();
	}
	
	public void createProtectedProductDossierAndAddContributers(String bcNumber, String contractNumber, String productGroup, String description, String contributor) throws InterruptedException
	{
		clear_b.click();
		bcNumber_Tf.sendKeys(bcNumber);
		contractNumber_Tf.sendKeys(contractNumber);
		validate_b.click();
		//waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		action.moveToElement(product_b).click().perform();
		action.click(productGroup_Ta).sendKeys(productGroup).sendKeys(Keys.ENTER).perform();
		description_Tf.sendKeys(description);
		action.moveToElement(protected_cb).click().perform();
		add_members_i.click();
		Thread.sleep(2000);
		members_search_tf.sendKeys(contributor);
		Thread.sleep(2000);
		action.sendKeys(Keys.ENTER).perform();
		add_member_b.click();
		close_b.click();
	}
	
	public static ImportDocumentPage navigateToImportDocumentPage() throws InterruptedException, AWTException, IOException
	{
		next_b.click();
		return new ImportDocumentPage(driver);
	}

}
