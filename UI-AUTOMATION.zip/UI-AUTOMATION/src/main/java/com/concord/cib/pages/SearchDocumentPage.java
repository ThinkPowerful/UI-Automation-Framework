package com.concord.cib.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;

public class SearchDocumentPage extends BasePage{

	public SearchDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		menu.selectBusinessContextByValue("string:25");
		menu.selectLanguage("EN");
	}
	
}
