package com.concord.cib.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;
import com.concord.cib.constants.ImportDocumentPageObjects;
import com.concord.cib.constants.SearchDossierPageObjects;
import com.concord.globalmarkets.pages.CreateDossierPage;
import com.concord.utility.DateUtil;

public class SearchDossierPage extends BasePage{
	
	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_TAB)
	protected WebElement dossier_tab;
	
	@FindBy(xpath=SearchDossierPageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;
	
	@FindBy(xpath=SearchDossierPageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;
	
	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_NAME_TEXTFIELD)
	protected WebElement dossierName_Tf;

	@FindBy(xpath=SearchDossierPageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;
	
	@FindBy(xpath=SearchDossierPageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;
	
	@FindBy(xpath=SearchDossierPageObjects.SEARCH_BUTTON)
	protected WebElement search_b;
	
	@FindBy(xpath=SearchDossierPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;
	
	@FindBy(xpath=SearchDossierPageObjects.SCROLL_TOP_BUTTON)
	protected WebElement scroolTop_b;
	
	@FindBy(xpath=SearchDossierPageObjects.DOSSIER_METADATA_INFO_BUTTON)
	protected WebElement dossierMetadataInfo_b;
	
	@FindBy(xpath=SearchDossierPageObjects.CREATE_DOSSIER_BUTTON)
	protected static WebElement createDossier_b;
	
	@FindBy(xpath=SearchDossierPageObjects.ACTIONS_DROPDOWN)
	protected static List<WebElement> actions_dd;
	
	@FindBy(xpath=SearchDossierPageObjects.IMPORT_OPTION)
	protected List<WebElement> import_o;
	
	@FindBy(xpath=SearchDossierPageObjects.EDIT_OPTION)
	protected static List<WebElement> edit_o;
	
	@FindBy(xpath=SearchDossierPageObjects.CLOSE_OPTION)
	protected List<WebElement> close_o;
	
	@FindBy(xpath=SearchDossierPageObjects.MEMBERS_OPTION)
	protected List<WebElement> members_o;
	
	@FindBy(xpath=SearchDossierPageObjects.OWNER_OPTION)
	protected List<WebElement> owner_o;
	
	@FindBy(xpath = ImportDocumentPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected static WebElement returnToSearchScreen_b;
	
	@FindBy(xpath=SearchDossierPageObjects.CLOSE_BUTTON)
	protected WebElement close_b;
	
	static int openedDossier;
	
	public SearchDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
		dossier_tab.click();
		Thread.sleep(2000);
	}
	
	public void searchDossierWithBCNumber(String BCNumber, String dossierName)
			throws InterruptedException {
		
		clear_b.click();
		selectOptionByValue(customerAdminType_Dd, "2:customer");
		identifier_Tf.sendKeys(BCNumber);
		dossierName_Tf.sendKeys(dossierName);
		search_b.click();
	}

	public void searchDossierWithBCNumber(String BCNumber, String dossierName, String fromDate, String toDate)
			throws InterruptedException {
		
		clear_b.click();
		selectOptionByValue(customerAdminType_Dd, "2:customer");
		identifier_Tf.sendKeys(BCNumber);
		dossierName_Tf.sendKeys(dossierName);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		search_b.click();
	}
	
	public void scrollToTop(int dossierIndex)
	{
		try
		{
		driver.findElement(By.xpath("(//span[text()='Scroll top'])["+dossierIndex+"]")).isDisplayed();
		singleClickOnElement(driver.findElement(By.xpath("(//span[text()='Scroll top'])["+dossierIndex+"]")));
		}
		catch(Exception e)
		{
			System.out.println("Not Displayed " +e);
		}
	}
	

	public boolean isDossierFound(String dossierName, String creationDate) throws ParseException
	{
		//JavascriptExecutor executor = (JavascriptExecutor)driver;
		//return (Boolean) executor.executeScript("return document.evaluate(\"//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[text()='"+dossierName+"'] and //dt[text()='Created on']/following-sibling::dd[text()='"+creationDate+"']\", document, null, XPathResult.BOOLEAN_TYPE, null).booleanValue");
		 boolean isdossierFound=false;
		 int listOfDossiers = driver.findElements(By.xpath("//div[@class='panel-title-wrapper cursor-click-enable ng-scope']//span[contains(text(),'"+dossierName+"')]")).size();
		 for(int dossierCount=0;dossierCount<listOfDossiers;dossierCount++)
		 {
				driver.findElements(By.xpath("//div[contains(@class,'panel-title-wrapper cursor-click-enable ng-scope')]//span[contains(text(),'"+dossierName+"')]")).get(dossierCount).click();
				 waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
				 scrollToTop(dossierCount+1);
				 dossierMetadataInfo_b.click();
				 String creationDateTimeActual = driver.findElement(By.xpath("//dl[@ng-if='dossierMetadata.dossierName']//dt[text()='Created on']/following-sibling::dd[1]")).getText();
				 if(creationDateTimeActual.contains(creationDate))
				 {
					 driver.findElement(By.xpath("//span[@title='Close']")).click();
					 isdossierFound=true;
					 openedDossier = dossierCount;
					 break;
				 }
				 else
				 {
					 driver.findElement(By.xpath("//span[@title='Close']")).click();
				 }
		 }
		 return isdossierFound;
	}
	
	public void viewMembersOfDossier()
	{
		this.action = new Actions(driver);
		action.moveToElement(actions_dd.get(0)).click().perform();
		action.moveToElement(members_o.get(0)).click().perform();
	}
	
	public void closePopup()
	{
		close_b.click();
	}
	
	public static CreateDossierPage navigateToCreateDossierPage() throws InterruptedException, AWTException, IOException
	{
		createDossier_b.click();
		return new CreateDossierPage(driver);
	}

}
