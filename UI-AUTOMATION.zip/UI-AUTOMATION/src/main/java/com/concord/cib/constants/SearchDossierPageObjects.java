package com.concord.cib.constants;

public class SearchDossierPageObjects {
	
	//GlobalMarkets_SearchDossierPage
			public static final String DOSSIER_TAB="//button[@href='/gdc/web/client/dossiers']";
			public static final String CUSTOMER_ADMIN_TYPE_DROPDOWN = "//select[@ng-model='searchObject.adminType']";
			public static final String IDENTIFIER_TEXTFIELD = "//input[@id='identifier']";
			public static final String DOSSIER_NAME_TEXTFIELD = "(//input[@ng-model='searchObject.dossierName'])[1]";
			public static final String FROM_DATE_TEXTFIELD = "//input[@id='fromDate']";
			public static final String TO_DATE_TEXTFIELD = "//input[@id='toDate']";
			public static final String SEARCH_BUTTON = "//button[text()='Search']";
			public static final String ZERO_DOSSIER_FOUND_MESSAGE = "//span[text()='dossier(s) found']/..";
			public static final String CUSTOMER_INFO_BUTTON = "//button[@id='enableIText16']";
			public static final String DOSSIER_NAME_INFO_BUTTON = "//button[@id='enableIText4']";
			public static final String TO_INFO_BUTTON = "//button[@id='enableIText6']";
			public static final String CUSTOMER_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
			public static final String DOSSIER_NAME_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
			public static final String TO_INFO_MESSAGE = "//p[@class='itext-word-wrap ng-scope']";
			public static final String CLIENT_NAME_TEXT = "//div[@id='customerName']/input";
			public static final String BC_CONTRACT_VALIDATION_MESSAGES = "//div[@id='identifierAdministration']//p/span";
			public static final String DATE_VALIDATION_MESSAGES = "//div[@id='datePicker']//span";
			public static final String CLEAR_BUTTON = "//button[text()='Clear']";
			public static final String VIEW_PDF_TOOLBAR = "//div[@id='toolbarViewerMiddle']";
			public static final String CLOSE_BUTTON = "//button[text()='Close']";
			public static final String VIEW_BUTTON = "//button[text()='View']";
			public static final String NEXT_BUTTON = "//button[text()='Next']";
			public static final String DOWNLOAD_BUTTON = "//button[text()='Download']";
			public static final String LENS_BUTTON="//span[@title='Search Customer']";
			public static final String SEARCH_VIEW_BUTTON = "//span[@title='Search view']";
			public static final String SCROLL_TOP_BUTTON = "(//span[text()='Scroll top'])[4]";
			public static final String CREATE_DOSSIER_BUTTON = "//span[@title='Create dossier']";
			public static final String DOSSIER_METADATA_INFO_BUTTON = "//div[@aria-expanded='true']//button[@ng-click='listenerCallbackViewDossierMetadata()']";
			public static final String ACTIONS_DROPDOWN ="//button[@id='actionsInDossier']";
			public static final String IMPORT_OPTION ="//span[contains(text(),'Import')]";
			public static final String EDIT_OPTION = "//span[text()='Edit']";
			public static final String CLOSE_OPTION ="//li[@ng-click='listenerCallbackOpenModal()']";
			public static final String YES_POPUP_BUTTON = "//button[text()[normalize-space() ='Yes']]";
			public static final String NO_POPUP_BUTTON = "//button[text()='No']";
			public static final String VALID_FROM_METADATA_LABEL = "//dt[text()='Valid from']";
			public static final String VALID_FROM_METADATA_VALUE = "//dt[text()='Valid from']/following-sibling::dd";
			public static final String VALID_TO_METADATA_LABEL = "//dt[text()='Valid to']";
			public static final String VALID_TO_METADATA_VALUE = "//dt[text()='Valid from']/following-sibling::dd";
			public static final String IMPORT_BUTTON = "//*[@id=\"main\"]/ui-view/ui-view/ui-view/div/div/div[2]/div/div[1]/a/span";
			public static final String SELECT_ALL_BUTTON = "//button[text()='Select All']";
			public static final String UNSELECTED_CHECKBOXES = "//div[@class='container-fluid']//span[@class='drmicon drmicon-sm drmicon-checkbox-unchecked']";
			public static final String SELECTED_CHECKBOXES = "//div[@class='container-fluid']//span[@class='drmicon drmicon-sm drmicon-checkbox-checked']";
			public static final String UPDATE_STATUS_BUTTON = "//span[contains(text(),'Update Status')]";
			public static final String DESELECT_ALL_BUTTON = "//button[text()='Deselect All']";
			public static final String NUMBER_OF_DOCUMENTS_LABEL = "//span[@class='pull-right ng-binding']";
			public static final String DOCUMENTS_NAME = "//dd[@class='dossier-description-overflow ng-binding']";
			public static final String DOCUMENT_PREVIEW_WARNING_LABEL = "//div[@class='alert alert-warning ng-scope']";
			public static final String DOCUMENT_PREVIEW_NEXT_BUTTON = "//button[text()='Next']";
			public static final String DOCUMENT_PREVIEW_CLOSE_BUTTON = "//button[text()='Close']";
			public static final String DOCUMENT_PREVIEW_TITLE_LABEL = "//div[@class='drm-align-middle']//h4[@class='modal-title ng-binding']";
			public static final String IDENTIFY_CHECKBOX_BY_DOCUMENTNAME = "//*[@title='DocumentName']/ancestor::div[2]//span[@class='drmicon drmicon-sm drmicon-checkbox-unchecked']";
			public static final String CHECKED_OK_LABEL = "//span[@class='dropdown open']//span[@class='ng-scope'][contains(text(),'Checked Ok')]";
			public static final String CHECKED_NOTOK_LABEL = "//span[@class='dropdown open']//span[@class='ng-scope'][contains(text(),'Checked Not Ok')]";
			public static final String ARCHIVED_LABEL = "//span[@class='dropdown open']//span[@class='ng-scope'][contains(text(),'Archived')]";
			public static final String UPDATE_SUCCESS_IMAGE = "//div[@class='panel-body']//span[@ng-if='file.successStatus']";
			public static final String UPDATE_SUCCESS_DOCUMENT_NAME = "//div[@class='col-sm-4 col-xxs-4 ng-binding' and text()='DocumentName']";
			public static final String UPDATE_SUCCESS_MESSAGE = "//span[@ng-if='file.successStatus' and text()='Document status changed successfully']";
			public static final String RETURN_TO_SEARCH_SCREEN_BUTTON = "//button[contains(text(),'Return to Search Screen')]";
			public static final String MEMBERS_OPTION = "//span[contains(text(),'Members')]";
			public static final String OWNER_OPTION = "//span[contains(text(),'Owner')]";

}
