package com.concord.cib.constants;

public class ImportDocumentPageObjects {
	
	public static final String DOCUMENT_NAME_TEXTFIELD = "//input[@id='fileName']";
	public static final String DOCUMENT_TYPE_TYPEAHEAD = "(//input[@id='documentType'])[1]";
	public static final String BCNUMBER_TEXTFIELD = "(//input[@id='bcNumber'])[1]";
	public static final String CONTRACTNUMBER_TEXTFIELD = "//input[@id='crcNumber']";
	public static final String VALID_FROM_TEXTFIELD = "//input[@id='issueDate']";
	public static final String VALID_TO_TEXTFIELD = "//input[@id='expirationDate']";
	public static final String SCANNERID_TEXTFIELD = "//input[@id='scannerId']";
	public static final String ADD_MORE_INFORMATION_LINK = "//span[text()='Add more information']";
	public static final String REMOVE_BUTTON = "//span[@title='Delete']";
	public static final String IMPORTDOCUMENT_LABLE = "//h2[text()='Import document']";
	public static final String IMPORT_DOCUMENT_BUTTON = "//span[@title='Import document']";
	public static final String SUBMIT_BUTTON = "//button[text()='Submit']";
	public static final String CANCEL_BUTTON = "//button[text()='Cancel']";
	public static final String ADD_DOCUMENT_BUTTON = "//button[contains(text(),'Add Document')]";
	public static final String RETURN_TO_SEARCH_SCREEN_BUTTON = "//button[contains(text(),'Return to Search Screen')]";
	public static final String DROP_FILE_AREA = "//span[text()='Drop files here']/..//div[@role='tablist']";
	// added as part of import Multiple Document
	public static final String DOCUMENT_TYPE_TYPEAHEAD_MULTIPLE = 
			"(//div[@class='col-sm-8 drm-ui-select-wizard ng-scope']//input[@class='form-control ng-pristine ng-untouched ng-scope ng-valid-editable ng-empty ng-invalid ng-invalid-required font-resize'])[1]";
	public static final String DATE_VALIDATION_MESSAGE = "//span[text()='This is an invalid date, please type dd-mm-yyyy (in digits)']";

}
