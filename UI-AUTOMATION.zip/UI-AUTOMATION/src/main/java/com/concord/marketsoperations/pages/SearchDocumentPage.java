package com.concord.marketsoperations.pages;

import java.awt.AWTException;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.concord.base.pages.BasePage;
import com.concord.globalmarkets.pages.ImportDocumentPage;
import com.concord.marketsoperations.constants.SearchDocumentPageObjects;

public class SearchDocumentPage extends BasePage {
	
	@FindBy(xpath=SearchDocumentPageObjects.IMPORT_DOCUMENT_BUTTON)
	protected static WebElement importDocument_b;

	public SearchDocumentPage(WebDriver driver) throws IOException, InterruptedException, AWTException {
		super(driver);
		PageFactory.initElements(driver, this);
		launchConcordApplication();
		menu.selectBusinessContext("Markets Operations");
		menu.selectLanguage("EN");
	}
	
	public static ImportDocumentPage navigateToCreateDocumentPageOfMarkets() throws InterruptedException, AWTException, IOException {
		importDocument_b.click();
		return new ImportDocumentPage(driver);
		
	}
}
