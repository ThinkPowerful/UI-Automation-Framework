package com.concord.marketsoperations.constants;

public class ImportDocumentPageObjects {
	public static final String PRODUCT_NAME = "//*[@id=\"productName\"]";
	public static final String NEXT_BUTTON = "//button[text()='Next']";
	public static final String SUBMIT_BUTTON = "//button[text()='Submit']";
	public static final String DROP_FILE_AREA = "//span[text()='Drop files here']/..//div[@role='tablist']";
	public static final String DOCUMENT_TYPE_TYPEAHEAD = "(//input[@id='documentType'])[1]";
	public static final String MUREX_NUMBERS = "//*[@id=\"murexNumber\"]";
	public static final String RETURN_TO_SEARCH_SCREEN_BUTTON = "//button[contains(text(),'Return to Search Screen')]";
	public static final String MANDATORY_VALIDATION_MESSAGE = "//span[text()='Please provide sufficient information about all documents and proceed']";
	public static final String CANCEL_BUTTON = "//button[text()='Cancel']";
}
