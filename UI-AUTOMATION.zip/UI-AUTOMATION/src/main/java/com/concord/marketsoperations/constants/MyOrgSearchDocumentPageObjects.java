package com.concord.marketsoperations.constants;

import com.concord.base.constants.BasePageObjects;

public class MyOrgSearchDocumentPageObjects extends BasePageObjects {

	public static final String MY_ORGANIZATION_TAB = "//a[text()='My Organization']";
	public static final String SEARCH_FOR_DROPDOWN="//select[@name='scopeInfo']";
	
}
