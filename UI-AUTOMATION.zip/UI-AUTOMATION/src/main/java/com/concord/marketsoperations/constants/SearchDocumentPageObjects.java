package com.concord.marketsoperations.constants;

public class SearchDocumentPageObjects {

	public static final String IMPORT_DOCUMENT_BUTTON = "//span[@title='Import ']";

}
