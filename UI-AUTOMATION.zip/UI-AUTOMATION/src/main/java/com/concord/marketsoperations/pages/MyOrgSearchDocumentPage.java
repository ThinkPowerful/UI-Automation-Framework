package com.concord.marketsoperations.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.concord.base.pages.BasePage;
import com.concord.marketsoperations.constants.MyOrgSearchDocumentPageObjects;

public class MyOrgSearchDocumentPage extends BasePage {
	

	@FindBy(xpath=MyOrgSearchDocumentPageObjects.MY_ORGANIZATION_TAB)
	protected static WebElement myOrganizationTab;
	
	@FindBy(xpath=MyOrgSearchDocumentPageObjects.SEARCH_FOR_DROPDOWN)
	protected static WebElement searchFor_Dd;
	
	@FindBy(xpath=MyOrgSearchDocumentPageObjects.FROM_DATE_TEXTFIELD)
	protected static WebElement fromDate_Tf;
	
	@FindBy(xpath=MyOrgSearchDocumentPageObjects.TO_DATE_TEXTFIELD)
	protected static WebElement toDate_Tf;
	
	@FindBy(xpath=MyOrgSearchDocumentPageObjects.SEARCH_BUTTON)
	protected static WebElement search_B;

	public MyOrgSearchDocumentPage(WebDriver driver) throws IOException, InterruptedException, AWTException {
		super(driver);
		PageFactory.initElements(driver, this);
		launchConcordApplication();
		menu.selectBusinessContext("Markets Operations");
		menu.selectLanguage("EN");
		myOrganizationTab.click();
	}
	
	public void searchForDocumentsWithDates(String documentScope, String fromDate, String toDate)
	{
		Select select = new Select(searchFor_Dd);
		select.selectByVisibleText(documentScope);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		search_B.click();
	}

}
