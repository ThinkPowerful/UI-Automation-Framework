package com.concord.marketsoperations.pages;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;
import com.concord.marketsoperations.constants.ImportDocumentPageObjects;

public class ImportDocumentPage extends BasePage {

	@FindBy(xpath = ImportDocumentPageObjects.PRODUCT_NAME)
	protected WebElement product_name;

	@FindBy(xpath = ImportDocumentPageObjects.NEXT_BUTTON)
	protected WebElement next_b;

	@FindBy(xpath = ImportDocumentPageObjects.SUBMIT_BUTTON)
	protected static WebElement submit_b;

	@FindBy(xpath = ImportDocumentPageObjects.DROP_FILE_AREA)
	protected static WebElement dropFile_A;

	@FindBy(xpath = ImportDocumentPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_ta;

	@FindBy(xpath = ImportDocumentPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected static WebElement returnToSearchScreen_b;

	@FindBy(xpath = ImportDocumentPageObjects.MANDATORY_VALIDATION_MESSAGE)
	protected WebElement mandatoryFieldValidation_m;

	@FindBy(xpath = ImportDocumentPageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;
	
	@FindBy(xpath = ImportDocumentPageObjects.MUREX_NUMBERS)
	protected WebElement murex_number;
	
	@FindBys(@FindBy(xpath = ImportDocumentPageObjects.MUREX_NUMBERS))
	protected List<WebElement> murex_numbers;
	
	public ImportDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void importDocumentForMarketsOperations(String documentName, String documentType, String productName, String murexNumber) {
		Actions action = new Actions(driver);
		action.click(product_name).sendKeys(productName).sendKeys(Keys.ENTER).perform();
		next_b.click();
		DropFile(new File(System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
				dropFile_A, 0, 0);
		action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		action.click(murex_number).sendKeys(murexNumber).sendKeys(Keys.ENTER).perform();
		submit_b.click();
	}

	public static SearchDocumentPage navigateToSearchDocumentScreen()
			throws InterruptedException, AWTException, IOException {
		waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		returnToSearchScreen_b.click();
		return new SearchDocumentPage(driver);
	}

	public boolean isMandatoryFieldValidationDisplayed(String documentName, String documentType, String productName) {
		try {
			Actions action = new Actions(driver);
			action.click(product_name).sendKeys(productName).sendKeys(Keys.ENTER).perform();
			next_b.click();
			DropFile(new File(
					System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
					dropFile_A, 0, 0);
			action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
			submit_b.click();
			return mandatoryFieldValidation_m.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public void importMultipleDocument(String documentName, String documentType, String murexNumber) {
		DropFile(new File(System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
				dropFile_A, 0, 0);
		WebElement documentType_tA=driver.findElement(By.xpath("(//span[contains(text(),'"+documentName+"')]/../../../../../..//input[@id='documentType'])[1]"));
		Actions action = new Actions(driver);
		action.click(documentType_tA).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		action.click(murex_numbers.get(murex_numbers.size() - 1)).sendKeys(murexNumber).sendKeys(Keys.ENTER).perform();
	}

	public void addProductName(String productName) {
		Actions action = new Actions(driver);
		action.click(product_name).sendKeys(productName).sendKeys(Keys.ENTER).perform();
		next_b.click();
	}

	public void submitDossierAndDocuments() {
		submit_b.click();
	}
	
	public SearchDocumentPage cancelAndReturnToSearchDocumentScreen() throws InterruptedException, AWTException, IOException {
		cancel_b.click();
		return new SearchDocumentPage(driver);
	}
}
