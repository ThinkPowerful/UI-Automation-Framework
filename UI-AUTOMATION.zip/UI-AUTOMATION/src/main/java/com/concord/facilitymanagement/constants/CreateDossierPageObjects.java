package com.concord.facilitymanagement.constants;

import com.concord.base.constants.BasePageObjects;

public class CreateDossierPageObjects extends BasePageObjects{
	
	public static final String PROJECTCODE_TEXTFIELD = "//input[@id='projectCode']";
	public static final String PROPERTYREFERENCE_TEXTFIELD = "//input[@id='buildingId']";
	public static final String BONUMBER_TEXTFIELD = "//input[@id='boNumber']";
	

}
