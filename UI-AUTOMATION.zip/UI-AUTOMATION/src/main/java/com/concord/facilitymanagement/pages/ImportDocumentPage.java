package com.concord.facilitymanagement.pages;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.constants.BasePageObjects;
import com.concord.base.pages.BasePage;
import com.concord.facilitymanagement.constants.ImportDocumentPageObjects;
import com.concord.facilitymanagement.pages.SearchDossierPage;

public class ImportDocumentPage extends BasePage{
	
	@FindBy(xpath = BasePageObjects.IMPORTDOCUMENT_LABLE)
	protected WebElement importdocument_l;

	@FindBy(xpath = BasePageObjects.IMPORT_DOCUMENT_BUTTON)
	protected WebElement import_Document_b;

	@FindBy(xpath = ImportDocumentPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_tf;

	@FindBy(xpath = ImportDocumentPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_ta;

	@FindBy(xpath = ImportDocumentPageObjects.PROPERTY_REFERENCE_TEXTFIELD)
	protected WebElement propertyRef_tf;

	@FindBy(xpath = ImportDocumentPageObjects.PROJECT_CODE_TEXTFIELD)
	protected WebElement projectCode_tf;
	
	@FindBy(xpath = ImportDocumentPageObjects.BO_NUMBER_TEXTFIELD)
	protected WebElement boNumber_tf;

	@FindBy(xpath = BasePageObjects.VALID_FROM_TEXTFIELD)
	protected WebElement validFrom_tf;

	@FindBy(xpath = BasePageObjects.VALID_TO_TEXTFIELD)
	protected WebElement validTo_tf;

	@FindBy(xpath = BasePageObjects.SCANNERID_TEXTFIELD)
	protected WebElement scannerID_tf;

	@FindBy(xpath = BasePageObjects.ADD_MORE_INFORMATION_LINK)
	protected WebElement addMoreInfo_l;

	@FindBy(xpath = BasePageObjects.REMOVE_BUTTON)
	protected WebElement remove_b;

	@FindBy(xpath = ImportDocumentPageObjects.SUBMIT_BUTTON)
	protected static WebElement submit_b;

	@FindBy(xpath = BasePageObjects.ADD_DOCUMENT_BUTTON)
	protected WebElement addDocument_b;

	@FindBy(xpath = BasePageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected static WebElement returnToSearchScreen_b;

	@FindBy(xpath = BasePageObjects.DROP_FILE_AREA)
	protected static WebElement dropFile_A;
	
	@FindBy(xpath = BasePageObjects.DOCUMENT_TYPE_TYPEAHEAD_MULTIPLE)
	protected String documentType_tamulti;

	@FindBy(xpath = BasePageObjects.DATE_VALIDATION_MESSAGE)
	protected WebElement dateFieldValidation_m;

	@FindBy(xpath = BasePageObjects.DOCUMENT_TYPE_TYPEAHEAD_MULTIPLE)
	protected static WebElement documentType_Multi;
	
	@FindBy(xpath = BasePageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;
	
	public ImportDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		Thread.sleep(2000);
	}

	public static void submitDossierAndDocuments() {
			submit_b.click();
	}

	public void importDocument(String documentName, String documentType) {
		DropFile(new File(System.getProperty("user.dir") + "\\ExtentReports\\Snapshots\\UploadFiles\\" + documentName),
				dropFile_A, 0, 0);
		Actions action = new Actions(driver);
		action.click(documentType_ta).sendKeys(documentType).sendKeys(Keys.ENTER).perform();
		submit_b.click();
	}
	
	public static SearchDossierPage navigateToSearchDossierScreen()
			throws InterruptedException, AWTException, IOException {
		waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		returnToSearchScreen_b.click();
		return new SearchDossierPage(driver);
	}
	

}
