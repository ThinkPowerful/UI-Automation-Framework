package com.concord.facilitymanagement.constants;

import com.concord.base.constants.BasePageObjects;

public class SearchDocumentsPageObjects extends BasePageObjects{

}
