package com.concord.facilitymanagement.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.concord.base.pages.BasePage;
import com.concord.facilitymanagement.constants.SearchDocumentsPageObjects;

public class SearchDocumentPage extends BasePage{
	
	@FindBy(xpath = SearchDocumentsPageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;

	@FindBy(xpath = SearchDocumentsPageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_TYPE_TYPEAHEAD)
	protected WebElement documentType_Ta;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_TYPEAHEAD)
	protected WebElement documentSource_Ta;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_TEXTFIELD)
	protected WebElement documentName_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;

	@FindBy(xpath = SearchDocumentsPageObjects.SEARCH_BUTTON)
	protected WebElement search_b;

	@FindBy(xpath = SearchDocumentsPageObjects.ZERO_DOCUMENTS_FOUND_MESSAGE)
	protected WebElement zeroDocumentsFound_m;

	@FindBy(xpath = SearchDocumentsPageObjects.CUSTOMER_INFO_BUTTON)
	protected WebElement customerInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_TYPE_INFO_BUTTON)
	protected WebElement documentTypeInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_INFO_BUTTON)
	protected WebElement documentSourceInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_BUTTON)
	protected WebElement documentNameInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_INFO_BUTTON)
	protected WebElement toInfo_b;

	@FindBy(xpath = SearchDocumentsPageObjects.CUSTOMER_INFO_MESSAGE)
	protected WebElement customerInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentTypeInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_SOURCE_INFO_MESSAGE)
	protected WebElement documentSourceInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DOCUMENT_NAME_INFO_MESSAGE)
	protected WebElement documentNameInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.TO_INFO_MESSAGE)
	protected WebElement toInfo_m;

	@FindBy(xpath = SearchDocumentsPageObjects.DATE_VALIDATION_MESSAGES)
	protected WebElement dateValidationMessages_m;

	@FindBy(xpath = SearchDocumentsPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;

	@FindBy(xpath = SearchDocumentsPageObjects.CLOSE_BUTTON)
	protected WebElement close_b;

	@FindBy(xpath = SearchDocumentsPageObjects.VIEW_PDF_TOOLBAR)
	protected WebElement viewPDF_toolBar;

	@FindBy(xpath = SearchDocumentsPageObjects.OPTIONS_DROPDOWN)
	protected WebElement options_dd;

	@FindBy(xpath = SearchDocumentsPageObjects.VIEW_ONEBYONE_OPTION)
	protected WebElement view_o;

	@FindBy(xpath = SearchDocumentsPageObjects.DOWNLOAD_AS_ZIP_OPTION)
	protected WebElement download_o;
	
	@FindBy(xpath = SearchDocumentsPageObjects.COMBINED_VIEW_OPTION)
	protected WebElement combinedView_o;
	
	@FindBy(xpath = SearchDocumentsPageObjects.SEPERATE_TABS_VIEW_OPTION)
	protected WebElement seperateTabsView_o;

	@FindBy(xpath = SearchDocumentsPageObjects.SCROLL_TO_TOP_BUTTON)
	protected WebElement scroolToTop_b;

	@FindBy(xpath = SearchDocumentsPageObjects.LENS_BUTTON)
	protected WebElement lens_b;
	
	@FindBy(xpath = SearchDocumentsPageObjects.PAGE_SIZE_DROPDOWN)
	protected WebElement pageSize_Dd;
	
	public Set<String> allWindowHandles;

	public SearchDocumentPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		businessLine="Facility Management";
		menu.selectBusinessContext("Facility Management");
		menu.selectLanguage("EN");
	}

	public void searchDocumentWithProjectCode(String projectCode, String fromDate, String toDate) {
			selectOptionByValue(customerAdminType_Dd, "1:project");
			identifier_Tf.clear();
			identifier_Tf.sendKeys(projectCode);
			fromDate_Tf.clear();
			fromDate_Tf.sendKeys(fromDate);
			toDate_Tf.clear();
			toDate_Tf.sendKeys(toDate);
			search_b.click();
			search_b.click();
	}
	
	public void searchDocumentWithPropertyReference(String propertyReference, String fromDate, String toDate) {
		selectOptionByValue(customerAdminType_Dd, "1:building");
		identifier_Tf.clear();
		identifier_Tf.sendKeys(propertyReference);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		search_b.click();
	}
	public void searchDocumentWithBONumber(String BONumber, String fromDate, String toDate) {
		selectOptionByValue(customerAdminType_Dd, "1:department");
		identifier_Tf.clear();
		identifier_Tf.sendKeys(BONumber);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		search_b.click();
	}
	
	
	

}
