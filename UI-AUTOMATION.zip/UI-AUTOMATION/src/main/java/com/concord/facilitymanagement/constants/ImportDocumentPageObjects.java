package com.concord.facilitymanagement.constants;

import com.concord.base.constants.BasePageObjects;

public class ImportDocumentPageObjects extends BasePageObjects{
	
	public static final String DOCUMENT_NAME_TEXTFIELD = "//input[@id='fileName']";
	public static final String DOCUMENT_TYPE_TYPEAHEAD = "(//input[@id='documentType'])[1]";
	public static final String PROPERTY_REFERENCE_TEXTFIELD = "(//input[@id='buildingId'])[1]";
	public static final String PROJECT_CODE_TEXTFIELD = "(//input[@id='projectCode'])[1]";
	public static final String BO_NUMBER_TEXTFIELD = "(//input[@id='boNumber'])[1]";
	public static final String SUBMIT_BUTTON = "//button[text()='Submit']";
	

}
