package com.concord.facilitymanagement.constants;

import com.concord.base.constants.BasePageObjects;

public class SearchDossierPageObjects extends BasePageObjects{
	
	public static final String DOSSIER_TAB="//button[@href='/gdc/web/building/dossiers']";

}
