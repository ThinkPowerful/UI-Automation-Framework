package com.concord.facilitymanagement.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.constants.BasePageObjects;
import com.concord.base.pages.BasePage;
import com.concord.facilitymanagement.constants.CreateDossierPageObjects;
import com.concord.facilitymanagement.pages.ImportDocumentPage;

public class CreateDossierPage extends BasePage{
	
	@FindBy(xpath=BasePageObjects.CREATEDOSSIER_LABLE)
	protected WebElement createDossier_l;
	
	@FindBy(xpath=CreateDossierPageObjects.PROJECTCODE_TEXTFIELD)
	protected WebElement projectcode_Tf;
	
	@FindBy(xpath=CreateDossierPageObjects.PROPERTYREFERENCE_TEXTFIELD)
	protected WebElement propertyReference_Tf;
	
	@FindBy(xpath=CreateDossierPageObjects.BONUMBER_TEXTFIELD)
	protected WebElement boNumber_Tf;
	
	@FindBy(xpath=BasePageObjects.DOSSIER_IDENTIFICATION_VALIDATION_MESSAGE)
	protected WebElement identification_Validation_m;
	
	@FindBy(xpath=BasePageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;
	
	@FindBy(xpath=BasePageObjects.VALIDATE_BUTTON)
	protected WebElement validate_b;
	
	@FindBy(xpath=BasePageObjects.DOSSIER_CONTEXT_VALIDATION_MESSAGE)
	protected WebElement context_Validation_m;
	
	@FindBy(xpath=BasePageObjects.PROCESSNAME_TYPEAHEAD)
	protected WebElement processName_Ta;
	
	@FindBy(xpath=BasePageObjects.DESCRIPTION_TEXTFIELD)
	protected WebElement description_Tf;
	
	@FindBy(xpath=BasePageObjects.LENS_BUTTON)
	protected WebElement lens_b;
	
	@FindBy(xpath=BasePageObjects.CANCEL_BUTTON)
	protected WebElement cancel_b;
	
	@FindBy(xpath=BasePageObjects.NEXT_BUTTON)
	protected static WebElement next_b;
	
	public CreateDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException 
	{
		super(driver);
		PageFactory.initElements(driver, this);
		Thread.sleep(2000);
	} 
	
	public void createProcessDossier(String ProjectCode, String PropRef, String BONumber, String processName, 
			String description) throws InterruptedException
	{
		clear_b.click();
		projectcode_Tf.sendKeys(ProjectCode);
		propertyReference_Tf.sendKeys(PropRef);
		boNumber_Tf.sendKeys(BONumber);
		validate_b.click();
		waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
		Thread.sleep(1000);
		Actions action = new Actions(driver);
		action.click(processName_Ta).sendKeys(processName).sendKeys(Keys.ENTER).perform();
		description_Tf.sendKeys(description);
	}
	
	public static ImportDocumentPage navigateToImportDocumentPage() throws InterruptedException, AWTException, IOException
	{
		next_b.click();
		return new ImportDocumentPage(driver);
	}

}
