package com.concord.facilitymanagement.pages;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.concord.base.pages.BasePage;
import com.concord.facilitymanagement.constants.SearchDossierPageObjects;
import com.concord.globalmarkets.pages.CreateDossierPage;

public class SearchDossierPage extends BasePage {

	@FindBy(xpath = SearchDossierPageObjects.DOSSIER_TAB)
	protected WebElement dossier_tab;

	@FindBy(xpath = SearchDossierPageObjects.CUSTOMER_ADMIN_TYPE_DROPDOWN)
	protected WebElement customerAdminType_Dd;

	@FindBy(xpath = SearchDossierPageObjects.IDENTIFIER_TEXTFIELD)
	protected WebElement identifier_Tf;

	@FindBy(xpath = SearchDossierPageObjects.DOSSIER_NAME_TEXTFIELD)
	protected WebElement dossierName_Tf;

	@FindBy(xpath = SearchDossierPageObjects.FROM_DATE_TEXTFIELD)
	protected WebElement fromDate_Tf;

	@FindBy(xpath = SearchDossierPageObjects.TO_DATE_TEXTFIELD)
	protected WebElement toDate_Tf;

	@FindBy(xpath = SearchDossierPageObjects.SEARCH_BUTTON)
	protected WebElement search_b;

	@FindBy(xpath = SearchDossierPageObjects.ZERO_DOSSIER_FOUND_MESSAGE)
	protected WebElement zeroDossierFound_m;

	@FindBy(xpath = SearchDossierPageObjects.CUSTOMER_INFO_BUTTON)
	protected WebElement customerInfo_b;

	@FindBy(xpath = SearchDossierPageObjects.DOSSIER_NAME_INFO_BUTTON)
	protected WebElement dossierNameInfo_b;

	@FindBy(xpath = SearchDossierPageObjects.TO_INFO_BUTTON)
	protected WebElement toInfo_b;

	@FindBy(xpath = SearchDossierPageObjects.CUSTOMER_INFO_MESSAGE)
	protected WebElement customerInfo_m;

	@FindBy(xpath = SearchDossierPageObjects.DOSSIER_NAME_INFO_MESSAGE)
	protected WebElement dossierNameInfo_m;

	@FindBy(xpath = SearchDossierPageObjects.TO_INFO_MESSAGE)
	protected WebElement toInfo_m;

	@FindBy(xpath = SearchDossierPageObjects.CLIENT_NAME_TEXT)
	protected WebElement clientName_t;

	@FindBy(xpath = SearchDossierPageObjects.BC_CONTRACT_VALIDATION_MESSAGES)
	protected WebElement bcContractvalidationMessages_m;

	@FindBy(xpath = SearchDossierPageObjects.DATE_VALIDATION_MESSAGES)
	protected WebElement dateValidationMessages_m;

	@FindBy(xpath = SearchDossierPageObjects.CLEAR_BUTTON)
	protected WebElement clear_b;

	@FindBy(xpath = SearchDossierPageObjects.CLOSE_BUTTON)
	protected WebElement close_b;

	@FindBy(xpath = SearchDossierPageObjects.VIEW_PDF_TOOLBAR)
	protected WebElement viewPDF_toolBar;

	@FindBy(xpath = SearchDossierPageObjects.VIEW_BUTTON)
	protected WebElement view_b;

	@FindBy(xpath = SearchDossierPageObjects.DOWNLOAD_BUTTON)
	protected WebElement download_b;

	@FindBy(xpath = SearchDossierPageObjects.NEXT_BUTTON)
	protected WebElement next_b;

	@FindBy(xpath = SearchDossierPageObjects.LENS_BUTTON)
	protected WebElement lens_b;

	@FindBy(xpath = SearchDossierPageObjects.CREATE_DOSSIER_BUTTON)
	protected static WebElement createDossier_b;

	@FindBy(xpath = SearchDossierPageObjects.SEARCH_VIEW_BUTTON)
	protected WebElement searchView_b;

	@FindBy(xpath = SearchDossierPageObjects.SCROLL_TOP_BUTTON)
	protected WebElement scroolTop_b;

	@FindBy(xpath = SearchDossierPageObjects.ACTIONS_DROPDOWN)
	protected static List<WebElement> actions_dd;

	@FindBy(xpath = SearchDossierPageObjects.IMPORT_OPTION)
	protected List<WebElement> import_o;

	@FindBy(xpath = SearchDossierPageObjects.EDIT_OPTION)
	protected static List<WebElement> edit_o;

	@FindBy(xpath = SearchDossierPageObjects.CLOSE_OPTION)
	protected List<WebElement> close_o;

	@FindBy(xpath = SearchDossierPageObjects.YES_POPUP_BUTTON)
	protected WebElement yes_popup_b;

	@FindBy(xpath = SearchDossierPageObjects.NO_POPUP_BUTTON)
	protected WebElement no_popup_b;

	@FindBy(xpath = SearchDossierPageObjects.VALID_FROM_METADATA_LABEL)
	protected WebElement validFromMetadata_l;

	@FindBy(xpath = SearchDossierPageObjects.VALID_FROM_METADATA_VALUE)
	protected WebElement validFromMetadata_v;

	@FindBy(xpath = SearchDossierPageObjects.VALID_TO_METADATA_LABEL)
	protected WebElement validToMetadata_l;

	@FindBy(xpath = SearchDossierPageObjects.STATUS_METADATA_VALUE)
	protected WebElement statusMetadata_v;

	@FindBy(xpath = SearchDossierPageObjects.DOCUMENT_TYPE_METADATA_VALUE)
	protected WebElement DocumentTypeMetadata_v;

	@FindBy(xpath = SearchDossierPageObjects.VALID_TO_METADATA_VALUE)
	protected WebElement validToMetadata_v;

	@FindBy(xpath = SearchDossierPageObjects.SELECT_ALL_BUTTON)
	protected static WebElement selectAll_b;

	@FindBy(xpath = SearchDossierPageObjects.DESELECT_ALL_BUTTON)
	protected static WebElement deSelectAll_b;

	@FindBy(xpath = SearchDossierPageObjects.NUMBER_OF_DOCUMENTS_LABEL)
	protected static WebElement numberOfDocuments_lb;

	@FindBy(xpath = SearchDossierPageObjects.SELECTED_CHECKBOXES)
	protected static WebElement selected_cb;

	@FindBy(xpath = SearchDossierPageObjects.DOCUMENT_PREVIEW_TITLE_LABEL)
	protected static WebElement documentPreviewTitle_lb;

	@FindBy(xpath = SearchDossierPageObjects.DOCUMENT_PREVIEW_CLOSE_BUTTON)
	protected static WebElement documentPreviewClose_b;

	@FindBy(xpath = SearchDossierPageObjects.UPDATE_STATUS_BUTTON)
	protected static WebElement updateStatus_b;

	@FindBy(xpath = SearchDossierPageObjects.UPDATE_SUCCESS_IMAGE)
	protected static WebElement updateSuccess_img;

	@FindBy(xpath = SearchDossierPageObjects.UPDATE_SUCCESS_MESSAGE)
	protected static WebElement updateSuccess_lb;

	@FindBy(xpath = SearchDossierPageObjects.RETURN_TO_SEARCH_SCREEN_BUTTON)
	protected static WebElement returnToSearchScreen_b;

	@FindBy(xpath = SearchDossierPageObjects.COMMENTS_TEXTAREA)
	protected static WebElement comments_ta;

	@FindBy(xpath = SearchDossierPageObjects.ADD_BUTTON)
	protected static WebElement add_b;

	@FindBy(xpath = SearchDossierPageObjects.CLOSE_METADATA_FORM_ICON)
	protected static WebElement close_metadata_form_i;

	static int openedDossier;

	public SearchDossierPage(WebDriver driver) throws InterruptedException, AWTException, IOException {
		super(driver);
		PageFactory.initElements(driver, this);
		dossier_tab.click();
		Thread.sleep(2000);
	}

	public void searchDocumentWithProjectCode(String projectCode, String dossierName,
			String fromDate, String toDate) {
		clear_b.click();
		selectOptionByValue(customerAdminType_Dd, "1:project");
		identifier_Tf.sendKeys(projectCode);
		dossierName_Tf.sendKeys(dossierName);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		search_b.click();
	}

	public void searchDocumentWithPropertyReference(String propertyReference, String dossierName,
			String fromDate, String toDate) {
		clear_b.click();
		selectOptionByValue(customerAdminType_Dd, "1:building");
		identifier_Tf.sendKeys(propertyReference);
		dossierName_Tf.sendKeys(dossierName);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		search_b.click();
	}

	public void searchDocumentWithBONumber(String BONumber, String dossierName, String fromDate, String toDate) {
		clear_b.click();
		selectOptionByValue(customerAdminType_Dd, "1:department");
		identifier_Tf.sendKeys(BONumber);
		dossierName_Tf.sendKeys(dossierName);
		fromDate_Tf.clear();
		fromDate_Tf.sendKeys(fromDate);
		toDate_Tf.clear();
		toDate_Tf.sendKeys(toDate);
		search_b.click();
	}
	
	public static CreateDossierPage navigateToCreateDossierPage() throws InterruptedException, AWTException, IOException
	{
		createDossier_b.click();
		return new CreateDossierPage(driver);
	}

}
