package com.concord.internationaldesk.updatedocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.internationaldesk.pages.SearchDocumentsPage;
import com.concord.internationaldesk.pages.SearchDossierPage;
import com.concord.internationaldesk.pages.UpdateDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyReqFieldValidationsTest extends BaseTest{

	SearchDocumentsPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	UpdateDocumentPage updateDocumentPage;

	String sheetName="EDP_ReqFieldValidationsTest";

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("IDReqFieldValidationsTest",authorName.get("IDReqFieldValidationsTest"),moduleName.get("IDReqFieldValidationsTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentsPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
			this.updateDocumentPage= new UpdateDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}


	@Test(dataProvider="getData")
	public void verifySearchDosWithContNumTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			searchDossierPage.searchDossierWith24CustomerId(data.get("T24 Customer Number"));
			Thread.sleep(5000);
			if(searchDossierPage.isDossierFound(data.get("Dossier Name"),data.get("Dossier Creation Date")))
			{
				SearchDossierPage.navigateToUpdateDocumentPage(data.get("Document Name"));				
				if(updateDocumentPage.isMandatoryFieldValidationDisplayed())
				{
					String resultPath = updateDocumentPage.takeScreenshot();
					test.get(0).pass("Document Type is mandatory as expected").addScreenCaptureFromPath(resultPath);
					updateDocumentPage.cancelAndReturnToSearchScreen();
					Assert.assertTrue(true);
				}
				else
				{
					String resultPath = updateDocumentPage.takeScreenshot();
					test.get(0).fail("Mandatory validation not displayed").addScreenCaptureFromPath(resultPath);
					updateDocumentPage.cancelAndReturnToSearchScreen();
					Assert.fail("Document not updated successfully ");
				}
			}
			else
			{
				String resultPath = updateDocumentPage.takeScreenshot();
				test.get(0).skip("Dossier not found in the search results").addScreenCaptureFromPath(resultPath);
				Assert.fail("Dossier not found in the search results");
			}

		} 
		catch (Exception e) 
		{
			String resultPath =updateDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			Assert.fail("Skipping the test due to an exception: "+e.getMessage());
		}
	}

	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\International_Desk_Test_Data.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}
}
