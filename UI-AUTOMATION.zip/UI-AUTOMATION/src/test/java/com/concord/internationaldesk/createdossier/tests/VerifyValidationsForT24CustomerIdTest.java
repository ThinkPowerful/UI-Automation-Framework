package com.concord.internationaldesk.createdossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.internationaldesk.pages.SearchDocumentsPage;
import com.concord.internationaldesk.pages.CreateDossierPage;
import com.concord.internationaldesk.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyValidationsForT24CustomerIdTest extends BaseTest {
	SearchDocumentsPage searchDocumentPage;
	 SearchDossierPage searchDossierPage;
	 CreateDossierPage createDossierPage;

	String sheetName="CD_T24CustomerIdValidationTest";

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("ValidationsForT24CustomerIdTest",authorName.get("ValidationsForT24CustomerIdTest"),moduleName.get("ValidationsForT24CustomerIdTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentsPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
			this.createDossierPage = new CreateDossierPage(driver);
		SearchDossierPage.navigateToCreateDossierPage();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider="getData")
	public void ValidationForCustomerIdTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			createDossierPage.selectingCreateDossierTypeOther();
			createDossierPage.enterCustomerIdAndValidate(data.get("T24 Customer ID"));
			if(createDossierPage.isIdentificationValidationDisplayedForOthersCustomerId() && createDossierPage.getCustomerIdValidationMessage().equals(data.get("Expected Validation Message")))
			{
				String resultPath = createDossierPage.takeScreenshot();
				test.get(0).pass("Validation Message is as expected: "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
			}
			else
			{
				String resultPath = createDossierPage.takeScreenshot();
				test.get(0).fail("Validation message is not as expected: "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
			}
		} 
		catch(NoSuchElementException e)
		{
			String resultPath = createDossierPage.takeScreenshot();
			test.get(0).fail("No Validation exist "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
		}
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}

	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\International_Desk_Test_Data.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

	
}
