package com.concord.internationaldesk.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.internationaldesk.pages.SearchDocumentsPage;
import com.concord.internationaldesk.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyValidationForT24CustomerIdTest extends BaseTest {

	String sheetName = "SDP_T24CustomerIdValidationTest";
	SearchDocumentsPage searchDocumentPage;
	SearchDossierPage searchDossierPage;

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException {
		try {
			init("ValidationForT24CustomerIdTest", authorName.get("ValidationForT24CustomerIdTest"), moduleName.get("ValidationForT24CustomerIdTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentsPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifySearchDosWithCustomerIdTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {

		try {
			searchDossierPage.searchDossierWith24CustomerId(data.get("T24 Customer ID"));
			boolean isT24MandatoryValidationDisplayed = searchDossierPage.isElementPresent("//p[@class='help-block ng-scope']");
			if (isT24MandatoryValidationDisplayed) {
				String mandatoryValidationMessageForT24CustomerId = searchDossierPage
						.getMandatoryValidationMessageForT24CustomerId();
				if (mandatoryValidationMessageForT24CustomerId.equals(data.get("Expected Data"))) {
					String resultPath = searchDossierPage.takeScreenshot();
					test.get(0)
					.pass("Validation message for T24 customer id is as expected: " + data.get("Expected Data"))
					.addScreenCaptureFromPath(resultPath);
					Assert.assertEquals(mandatoryValidationMessageForT24CustomerId, data.get("Expected Data"));
				} else {
					String resultPath = searchDossierPage.takeScreenshot();
					test.get(0).fail(
							"Validation message for T24 customer id is NOT as expected: " + data.get("Expected Data"))
					.addScreenCaptureFromPath(resultPath);
					Assert.fail(
							"Validation message for T24 customer id is NOT as expected: " + data.get("Expected Data"));
				}

			} else {
				String resultPath = searchDossierPage.takeScreenshot();
				test.get(0).fail("Validation Not displayed: " + data.get("Expected Data"))
				.addScreenCaptureFromPath(resultPath);
				Assert.fail("Validation not displayed: " + data.get("Expected Data"));
			}
		} catch (Exception e) {
			String resultPath = searchDossierPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: " + e.getMessage())
			.addScreenCaptureFromPath(resultPath);
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(
				new Xls_Reader(System.getProperty("user.dir") + "\\ExcelFiles\\International_Desk_Test_Data.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {
		//driver.quit();
	}

}
