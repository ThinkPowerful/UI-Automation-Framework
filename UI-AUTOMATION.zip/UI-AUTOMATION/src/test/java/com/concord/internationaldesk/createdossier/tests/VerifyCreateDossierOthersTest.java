package com.concord.internationaldesk.createdossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.internationaldesk.pages.SearchDocumentsPage;
import com.concord.internationaldesk.pages.CreateDossierPage;
import com.concord.internationaldesk.pages.ImportDocumentPage;
import com.concord.internationaldesk.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyCreateDossierOthersTest extends BaseTest {
	CreateDossierPage createDossierPage;
	SearchDossierPage searchDossierPage;
	SearchDocumentsPage searchDocumentsPage; 
	String sheetName="CD_CreateDossierOthersTest";

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("CreateDossierOthersTest",authorName.get("CreateDossierOthersTest"),moduleName.get("CreateDossierOthersTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentsPage = new SearchDocumentsPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
			this.createDossierPage = new CreateDossierPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider="getData")
	public void verifyCreateDossierTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{  
		SearchDossierPage.navigateToCreateDossierPage();

		if(createDossierPage.selectingCreateDossierTypeOther()) {
			if(data.get("Type").equals("Client")) {
				try {
					createDossierPage.processDossierForOthers(data.get("T24 Account Id"),data.get("T24 Contract Id"),data.get("Country"),data.get("Process Name"),data.get("Client Name"),data.get("T24 Customer Id"));
					CreateDossierPage.navigateToImportDocumentPage();
					if(BasePage.isElementPresent("//span[text()='Dossier created']")) {
						String resultPath = createDossierPage.takeScreenshot();
						test.get(0).pass("Create dossier is working as expected: "+data.
								get("Client Name")).addScreenCaptureFromPath(resultPath); }


					else { String resultPath = createDossierPage.takeScreenshot();
					test.get(0).fail("Create dossier is not working as expected: "+data.
							get("Client Name")).addScreenCaptureFromPath(resultPath); }

				}
				catch(Exception e)
				{
					String resultPath =createDossierPage.takeScreenshot();
					test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
				}
				finally {
					ImportDocumentPage.navigateToSearchDossierScreen();
				}
			}

			if(data.get("Type").equals("Product")) {
				try {

					createDossierPage.productDossierForOthers(data.get("T24 Account Id"),data.get("T24 Customer Id"), data.get("T24 Contract Id"),data.get("Country"),data.get("Action"), data.get("Product Group"),data.get("Client Name"));
					CreateDossierPage.navigateToImportDocumentPage();
					if(BasePage.isElementPresent("//span[text()='Dossier created']"))
					{
						String resultPath = createDossierPage.takeScreenshot();
						test.get(0).pass("Create dossier is working as expected: "+data.get("Client Name")).addScreenCaptureFromPath(resultPath); 
					} else { 
						String resultPath = createDossierPage.takeScreenshot();
						test.get(0).fail("Create dossier is not working as expected: "+data.get("Client Name")).addScreenCaptureFromPath(resultPath); 
					} 
				} 
				catch(Exception e) 
				{ 
					String resultPath =createDossierPage.takeScreenshot();
				    test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).
				    addScreenCaptureFromPath(resultPath);
				}
				finally {
					ImportDocumentPage.navigateToSearchDossierScreen();
				}
			}
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\International_Desk_Test_Data.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

}