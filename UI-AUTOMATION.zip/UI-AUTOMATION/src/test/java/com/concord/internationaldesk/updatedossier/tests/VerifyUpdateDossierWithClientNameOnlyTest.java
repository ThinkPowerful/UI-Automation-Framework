//package com.concord.internationaldesk.updatedossier.tests;
//
//import java.awt.AWTException;
//import java.io.IOException;
//import java.util.Hashtable;
//
//import org.openqa.selenium.By;
//import org.testng.Assert;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;
//
//import com.concord.base.test.BaseTest;
//import com.concord.ctv.pages.SearchDocumentPage;
//import com.concord.internationaldesk.pages.SearchDossierPage;
//import com.concord.internationaldesk.pages.UpdateDossierPage;
//import com.concord.utility.DataUtil;
//import com.concord.utility.Xls_Reader;
//
//public class VerifyUpdateDossierWithClientNameOnlyTest extends BaseTest {
//
//	SearchDocumentPage searchDocumentPage;
//	SearchDossierPage searchDossierPage;
//	UpdateDossierPage updateDossierPage;
//	String sheetName = "UDP_UpdateDossierTestForClient";
//
//
//	@BeforeClass
//	public void launchApplication() throws InterruptedException, AWTException, IOException {
//
//		try {
//			init("IDUpdateDossierTestForClient", authorName.get("IDUpdateDossierTestForClient"),
//					moduleName.get("IDUpdateDossierTestForClient"));
//			openBrowser("Chrome");
//			this.searchDocumentPage = new SearchDocumentPage(driver);
//			this.searchDossierPage = new SearchDossierPage(driver);
//			this.updateDossierPage = new UpdateDossierPage(driver);
//		} catch (Exception e) {
//			test.get(0).skip("@BeforeClass configuration failed");
//		}
//	}
//	@Test(dataProvider = "getData")
//	public void verifyUpdateDossierWithClientname(Hashtable<String, String> data) throws IOException {
//
//		try {
//			searchDossierPage.searchDossierWithClientNameOnly(data.get("Client Name"));
//			searchDocumentPage.waitForInVisiblityOfElement(
//					driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
//
//			if(searchDossierPage.isDossierFoundForUpdateDossier(data.get("Dossier Name"),data.get("Dossier Creation Date"))) {
//
//
//				if(updateDossierPage.CheckdossierForClientOnboarding()) {
//
//					SearchDossierPage.navigateToUpdateDossierPage().updateDossierWithT24Number(data.get("T24 Number"));
//					// SearchDossierPage.navigateToUpdateDossierPage().UpdateDossierDescriptionforOthers(data.get("Dossier Description"));
//				}
//				else {
//
//				}
//
//
//				if (updateDossierPage.isDossierUpdatedSuccessfully()) {
//
//					String resultPath = updateDossierPage.takeScreenshot();
//
//					test.get(0).pass(
//							"Dossier updated successfully with the description For dossier Created with Client name only: " + data.get("Client Name"))
//					.addScreenCaptureFromPath(resultPath);
//					updateDossierPage.returnToSearchScreen();
//					Assert.assertTrue(true);
//					searchDossierPage.searchDossierWithClientNameOnly(data.get("Client Name"));
//
//					String t24customeridfrompage =updateDossierPage.ValidatingCustIdinDocumentInfo();
//					String T24idfromSheet=data.get("T24 Number");
//					if (t24customeridfrompage.equals(T24idfromSheet)) {
//
//						String resultsPath = updateDossierPage.takeScreenshot();
//
//						test.get(0).pass(
//								"Document in Dossier is updated with T24customer id:" + data.get("T24 Number"))
//						.addScreenCaptureFromPath(resultsPath);
//						Assert.assertTrue(true);
//
//					}
//
//				} else {
//					String resultPath = searchDocumentPage.takeScreenshot();
//
//					test.get(0).fail("Dossier not updated successfully").addScreenCaptureFromPath(resultPath);
//					updateDossierPage.cancelAndReturnToSearchScreen();
//					updateDossierPage.waitForInVisiblityOfElement(driver.findElement(
//							By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
//					Assert.fail("Dossier not updated successfully ");
//				}
//
//
//			}else {
//				String resultPath = searchDossierPage.takeScreenshot();
//
//				test.get(0).skip("Dossier not found in the search results").addScreenCaptureFromPath(resultPath);
//				Assert.fail("Dossier not found in the search results");
//			}
//		} catch (Exception e) {
//			String resultPath = searchDocumentPage.takeScreenshot();
//
//			test.get(0).skip("Skipping the test due to an exception: " + e.getMessage())
//			.addScreenCaptureFromPath(resultPath);
//		}
//	}
//
//
//
//
//	@DataProvider(name = "getData")
//	public Object[][] getData() {
//		return DataUtil.loadDataIntoHashTable(
//				new Xls_Reader(System.getProperty("user.dir") + "\\ExcelFiles\\International_Desk_Test_Data.xlsx"),
//				sheetName);
//	}
//
//	@AfterClass(alwaysRun = true)
//	public void tearDown() throws IOException {
//		driver.quit();
//	}
//}
//
