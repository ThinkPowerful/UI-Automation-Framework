package com.concord.internationaldesk.updatedossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.internationaldesk.pages.SearchDocumentsPage;
import com.concord.internationaldesk.pages.ImportDocumentPage;
import com.concord.internationaldesk.pages.CreateDossierPage;
import com.concord.internationaldesk.pages.SearchDossierPage;
import com.concord.internationaldesk.pages.UpdateDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.DateUtil;
import com.concord.utility.Xls_Reader;

public class VerifyUpdateDossierTest extends BaseTest {

	SearchDocumentsPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	UpdateDossierPage updateDossierPage;
	CreateDossierPage createDossierPage;
	ImportDocumentPage importDocumentPage;
	String sheetName = "UDP_UpdateDossierTest";

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException {
		try {
			init("IDUpdateDossierTest", authorName.get("IDUpdateDossierTest"),
					moduleName.get("IDUpdateDossierTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentsPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
			this.createDossierPage = new CreateDossierPage(driver);
			this.updateDossierPage = new UpdateDossierPage(driver);
			this.importDocumentPage = new ImportDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifySearchDosWithContNumTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {
			SearchDossierPage.navigateToCreateDossierPage();
			createDossierPage.selectingCreateDossierTypeCAP();
			createDossierPage.createDossierForCapProcess(data.get("Create-Client Name"), data.get("Create-Country"));
			importDocumentPage.importDocument(data.get("Import-Document Name"),data.get("Import-Document Type"));
			ImportDocumentPage.navigateToSearchDossierScreen();
			searchDossierPage.searchDossierWithClientName(data.get("Search-Client Name"));
			//searchDocumentPage.waitForElementToBeClickable(searchDossierPage.search_b);
			Thread.sleep(2000);
			String dateInddmmyyyy = DateUtil.convertDateToStringInddMMyyyy(DateUtil.getCurrentdateInddMMyyyy());
			if(searchDossierPage.isDossierFound(data.get("Dossier Name")+"_"+dateInddmmyyyy,DateUtil.getCurrentdateInddMMyyyyWithHyphen()))
			{
				SearchDossierPage.navigateToUpdateDossierPage().updateDossierWithT24Number(data.get("UpdateDossier-T24CustomerID"));
				String resultPath = searchDossierPage.takeScreenshot();
				test.get(0).info("Dossier T24 Customer ID updated with: "+data.get("UpdateDossier-T24CustomerID")).addScreenCaptureFromPath(resultPath);
				UpdateDossierPage.returnToSearchScreen();
				searchDossierPage.searchDossierWithClientName(data.get("Search-Client Name"));
				searchDossierPage.expandFirstDossierInTheList(data.get("Dossier Name"));
				searchDossierPage.viewAllMetadataForADocument(data.get("Document Name"), 0);
				try {
					if(searchDossierPage.getDocumentMetadataT24CustomerID().equals(data.get("Document Metadata-T24CustomerID")))
					{
						resultPath = searchDossierPage.takeScreenshot();
						test.get(0).pass("Document T24 Customer ID updated with: "+data.get("UpdateDossier-T24CustomerID")).addScreenCaptureFromPath(resultPath);
						Assert.assertEquals(searchDossierPage.getDocumentMetadataT24CustomerID(), data.get("Document Metadata-T24CustomerID"));
					}
					else
					{
						resultPath = searchDossierPage.takeScreenshot();
						test.get(0).fail("Document T24 Customer ID updated with: "+data.get("UpdateDossier-T24CustomerID")).addScreenCaptureFromPath(resultPath);
						Assert.fail("Document T24 Customer ID updated with: "+data.get("UpdateDossier-T24CustomerID"));
					}
				} catch (Exception e) {
							resultPath = searchDossierPage.takeScreenshot();
							test.get(0).fail("Unable to find the metadata T24Customer ID for document: "+data.get("UpdateDossier-T24CustomerID")).addScreenCaptureFromPath(resultPath);
							Assert.fail("Unable to find the metadata T24Customer ID for document: "+data.get("UpdateDossier-T24CustomerID"));
				}
				
			}
			else
			{
				String resultPath = searchDossierPage.takeScreenshot();
				test.get(0).fail("Dossier not found in the search results").addScreenCaptureFromPath(resultPath);
				Assert.fail("Dossier not found in the search results");
			}
			
		} catch (Exception e) {
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: " + e.getMessage())
			.addScreenCaptureFromPath(resultPath);
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(
				new Xls_Reader(System.getProperty("user.dir") + "\\ExcelFiles\\International_Desk_Test_Data.xlsx"),
				sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {
		//driver.quit();
	}

}
