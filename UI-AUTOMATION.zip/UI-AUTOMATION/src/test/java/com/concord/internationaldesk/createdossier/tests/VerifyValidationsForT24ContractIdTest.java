package com.concord.internationaldesk.createdossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.internationaldesk.pages.SearchDocumentsPage;
import com.concord.internationaldesk.pages.CreateDossierPage;
import com.concord.internationaldesk.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyValidationsForT24ContractIdTest extends BaseTest {

	SearchDocumentsPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	CreateDossierPage createDossierPage;

	String sheetName="CD_T24ContractIdValidationTest";

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("ValidationsForT24ContractIdTest",authorName.get("ValidationsForT24ContractIdTest"),moduleName.get("ValidationsForT24ContractIdTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentsPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
			this.createDossierPage = new CreateDossierPage(driver);
			SearchDossierPage.navigateToCreateDossierPage();
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider="getData")
	public void ValidationForContractIdTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		createDossierPage.selectingCreateDossierTypeOther();

		try {
			createDossierPage.enterCustomerNumberContractNumberAndValidate(data.get("T24 Customer Id"),data.get("T24 Contract Id"));
			if(createDossierPage.isIdentificationValidationDisplayedForOthersAccountId() &&
					createDossierPage.getContractIdValidationMessage().equals(data.get("Expected Validation Message")))
			{
				String resultPath = createDossierPage.takeScreenshot();
				test.get(0).pass("Validation Message is as expected: "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
			}
			else
			{
				String resultPath = createDossierPage.takeScreenshot();
				test.get(0).fail("Validation message is not as expected: "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
				Assert.fail();
			}
		} 
		catch(NoSuchElementException e)
		{
			String resultPath = createDossierPage.takeScreenshot();
			test.get(0).fail("No Validation exist "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
			Assert.fail();

		}
		catch (Exception e) 
		{
			String resultPath =createDossierPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			throw new SkipException("Skipping the test due to an exception: "+e.getMessage());

		}
	}

	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\International_Desk_Test_Data.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

	
}