package com.concord.facilitymanagement.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.facilitymanagement.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.DateUtil;
import com.concord.utility.Xls_Reader;

public class VerifySearchDocumentWithBONumberTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="FMSearchDocWithBONumberTest";

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("FMSearchDocWithBONumberTest",authorName.get("FMSearchDocWithBONumberTest"),moduleName.get("FMSearchDocWithBONumberTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}

	}


	@Test(dataProvider="getData")
	public void verifySearchDocumentWithBONumberTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{

		try {

			searchDocumentPage.searchDocumentWithBONumber(data.get("BO Number"), DateUtil.getCurrentdateInddMMyyyyWithHyphen(), DateUtil.getCurrentdateInddMMyyyyWithHyphen());
			boolean documentFound = searchDocumentPage.isDocumentPresentInSearchResults(data.get("Expected Document Name"));
			if(documentFound){
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass("Expected document found in the search results: "+data.get("Expected Document Name")).addScreenCaptureFromPath(resultPath);
				Assert.assertTrue(documentFound);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("Expected document not found in the search results: "+data.get("Expected Document Name")).addScreenCaptureFromPath(resultPath);
				Assert.fail("Expected document not found in the search results: "+data.get("Expected Document Name"));
			}
		} catch (Exception e) {
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}


	}

	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		System.out.println("sheetName"+sheetName);
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\Facility_Management_Test_Data.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}
	

	

}
