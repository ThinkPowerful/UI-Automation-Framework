package com.concord.facilitymanagement.searchdossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.facilitymanagement.pages.SearchDocumentPage;
import com.concord.facilitymanagement.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.DateUtil;
import com.concord.utility.Xls_Reader;

public class VerifySearchDossierWithBONumberTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	String sheetName="FMSearchDossierWithBONumberTest";
	
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("FMSearchDossierWithBONumberTest",authorName.get("FMSearchDossierWithBONumberTest"),moduleName.get("FMSearchDossierWithBONumberTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed: "+e);
			}
		}
		
		
		@Test(dataProvider="getData")//,  dependsOnGroups = { "createDosierFacilityManagement" })
		public void verifySearchDossierWithBCNumTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDossierPage.searchDocumentWithBONumber(data.get("BO Number"), data.get("Dossier Name"), DateUtil.getCurrentdateInddMMyyyyWithHyphen(), DateUtil.getCurrentdateInddMMyyyyWithHyphen());
				searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierFound(data.get("Expected Dossier"),DateUtil.getCurrentdateInddMMyyyyWithHyphen()))
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("Expected Dossier found in the search result: "+data.get("Expected Dossier")).addScreenCaptureFromPath(resultPath);
					Assert.assertTrue(true);
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Expected Dossier not found in the search result: "+data.get("Expected Dossier")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected Dossier not found in the search result ");
				}
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\Facility_Management_Test_Data.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
