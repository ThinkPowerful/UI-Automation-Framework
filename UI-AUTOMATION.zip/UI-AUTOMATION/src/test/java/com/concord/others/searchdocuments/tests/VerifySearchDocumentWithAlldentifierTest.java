package com.concord.others.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.others.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySearchDocumentWithAlldentifierTest extends BaseTest{

	SearchDocumentPage searchDocumentPage;
	String sheetName="SearchDocumentWithAlldentifier";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("OSearchDocumentWithAlldentifierTest",authorName.get("OSearchDocumentWithAlldentifierTest"),moduleName.get("OSearchDocumentWithAlldentifierTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifySearchDocumentWithAlldentifierTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDocumentPage.searchDocumentWithAllAttributes(data.get("Identifier Type"), data.get("Identifier Number"), data.get("Document Type"), 
						data.get("Document Source"),data.get("Document Name"), data.get("From Date"), data.get("To Date"));
				boolean documentFound = searchDocumentPage.isDocumentPresentInSearchResults(data.get("Expected Document Name"), data.get("Expected Document ID"));
				if(documentFound){
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("Expected document found in the search results: "+data.get("Expected Document Name")).addScreenCaptureFromPath(resultPath);
					Assert.assertTrue(documentFound);
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Expected document not found in the search results: "+data.get("Expected Document Name")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected document not found in the search results: "+data.get("Expected Document Name"));
				}
			} catch (Exception e) {
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\Others_Test_Data.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}
	
}
