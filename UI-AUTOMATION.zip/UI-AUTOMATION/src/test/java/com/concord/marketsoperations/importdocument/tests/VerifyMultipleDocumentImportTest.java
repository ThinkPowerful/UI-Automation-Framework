package com.concord.marketsoperations.importdocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.marketsoperations.constants.ImportDocumentPageObjects;
import com.concord.marketsoperations.pages.ImportDocumentPage;
import com.concord.marketsoperations.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

import junit.framework.Assert;

public class VerifyMultipleDocumentImportTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	ImportDocumentPage importDocumentPage;
	String sheetName = "MO_MultipleDocumentImport";
	int docCount = 0;
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException {
		try {
			init("MOMultipleDocumentImportTest", authorName.get("MOMultipleDocumentImportTest"),
					moduleName.get("MOMultipleDocumentImportTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
			this.importDocumentPage = new ImportDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed: "+e);
		}
	}
	
	@Test(dataProvider = "getData")
	public void verifyMultipleDocumentImportTest(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {
			for (String key : data.keySet()) {
				if (key.toLowerCase().startsWith("document name")) {
					docCount = docCount + 1;
				}
			}
			SearchDocumentPage.navigateToCreateDocumentPageOfMarkets();
			importDocumentPage.addProductName(data.get("Product Group"));
			if (docCount != 0) {
				for (int i = 1; i <= docCount; i++) {
					importDocumentPage.importMultipleDocument(data.get("Document Name " + i),
							data.get("Document Type " + i),data.get("Murex Number " + i));
				}
			}else {
				String resultPath = importDocumentPage.takeScreenshot();
				test.get(0).fail("Please provide atleast one document as input in the Input Sheet: "+sheetName)
						.addScreenCaptureFromPath(resultPath);
			}
			importDocumentPage.submitDossierAndDocuments();
			if (importDocumentPage
					.isElementPresent("//span[contains(text(),'Document imported successfully')]")) {
				String resultPath = importDocumentPage.takeScreenshot();
				test.get(0).pass("Import Document is working as expected, verify the screenshot ")
						.addScreenCaptureFromPath(resultPath);
				Assert.assertTrue(true);
			} else {
				String resultPath = importDocumentPage.takeScreenshot();
				test.get(0).fail("Import Document is not working as expected: " + data.get("Document Name"))
						.addScreenCaptureFromPath(resultPath);
			}
			ImportDocumentPage.navigateToSearchDocumentScreen();
		} catch (Exception e) {
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: " + e.getMessage())
					.addScreenCaptureFromPath(resultPath);
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(
				new Xls_Reader(System.getProperty("user.dir") + "\\ExcelFiles\\Markets_Operations_Test_Data.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {
		//driver.quit();
	}
}
