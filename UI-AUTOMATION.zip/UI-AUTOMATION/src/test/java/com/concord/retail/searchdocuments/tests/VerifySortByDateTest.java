package com.concord.retail.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.stream.Collectors;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.retail.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySortByDateTest extends BaseTest {

	SearchDocumentPage searchDocumentPage;
	String sheetName = "SortDataByDate";

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException {
		try {
			init("RSortByDateTest", authorName.get("RSortByDateTest"), moduleName.get("RSortByDateTest"));
			if (driver == null) {
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	public void verifySortByDateTest(Hashtable<String, String> data) throws Exception {
		searchDocumentPage.searchDocumentWithOnlyBCNumber(data.get("BC Number"));
		try {
			String resultPath = searchDocumentPage.takeScreenshot();
			
			if (data.get("Sort Order").equalsIgnoreCase("Descending")) {
				searchDocumentPage.sortByDate("Descending");
				List<WebElement> dateColumnDesc = driver.findElements(By.xpath("//tr/td[3]"));
				List<String> originalDescendingList = dateColumnDesc.stream().map(s -> s.getText()).collect(Collectors.toList());
				List<String> sortedDescendingList = originalDescendingList.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());

				if (originalDescendingList.equals(sortedDescendingList)) {
					test.get(0).pass("Verified - Document sorted in descending order ").addScreenCaptureFromPath(resultPath);
					Assert.assertEquals(sortedDescendingList, originalDescendingList);
				} else {
					test.get(0).fail("Document not sorted in descending order ").addScreenCaptureFromPath(resultPath);
					Assert.fail();
				}
			}
			if (data.get("Sort Order").equalsIgnoreCase("Ascending")) {
				searchDocumentPage.sortByDate("Ascending");
				List<WebElement> dateColumnAsc = driver.findElements(By.xpath("//tr/td[3]"));
				List<String> originalAscendingList = dateColumnAsc.stream().map(s -> s.getText()).collect(Collectors.toList());
				List<String> sortedAscendingList = originalAscendingList.stream().sorted().collect(Collectors.toList());

				if (originalAscendingList.equals(sortedAscendingList)) {
					test.get(0).pass("Verified - Document sorted in ascending order ").addScreenCaptureFromPath(resultPath);
					Assert.assertEquals(sortedAscendingList, originalAscendingList);
				} else {
					test.get(0).fail("Document not sorted in ascending order ").addScreenCaptureFromPath(resultPath);
					Assert.fail();
				}
			}
		} catch (Exception e) {
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: " + e.getMessage()).addScreenCaptureFromPath(resultPath);
			Assert.fail("Skipping the test due to an exception: " + e.getMessage());
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(
				new Xls_Reader(System.getProperty("user.dir") + "\\ExcelFiles\\Retail_Test_Data.xlsx"), sheetName);
}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {
		// driver.quit();
	}
}
