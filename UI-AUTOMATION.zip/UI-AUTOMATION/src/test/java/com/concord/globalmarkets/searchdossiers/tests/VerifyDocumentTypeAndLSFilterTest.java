package com.concord.globalmarkets.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyDocumentTypeAndLSFilterTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	String sheetName="SDP_DocumentTypeAndLSFilterTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("DocumentTypeAndLSFilterTest",authorName.get("DocumentTypeAndLSFilterTest"),moduleName.get("DocumentTypeAndLSFilterTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyDocumentTypeAndLSFilterTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), data.get("From Date"), data.get("To Date"));
				SearchDocumentPage.waitForInVisiblityOfAllElements(driver.findElements(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierFound(data.get("Dossier Name"),data.get("Dossier Creation Time")))
				{
					searchDossierPage.filterByBothDocTypeAndLS(data.get("Dossier Name"), data.get("Life Cycle Status"),data.get("Document Type"));
					searchDossierPage.viewAllMetadataForADocument(data.get("Document Name"), 0);
					String documentFiltered=searchDossierPage.getDocumentFilteredCountInADossier(data.get("Dossier Name"));
					if(documentFiltered.contains(data.get("Filtered Documents Expected")))
					{
						String documentTypeActual = searchDossierPage.getDocumentMetadataDocumentType().trim();
						String lifeCycleActual = searchDossierPage.getDocumentMetadataStatus().trim();
						if(documentTypeActual.equalsIgnoreCase(data.get("Document Type Expected")) && lifeCycleActual.equalsIgnoreCase(data.get("Life Cycle Status Expected")))
						{
							String resultPath = searchDocumentPage.takeScreenshot();
							test.get(0).pass("Document is filtered successfully based on lifecycle status and document type: "+data.get("Life Cycle Status Expected") +","+data.get("Document Type Expected")).addScreenCaptureFromPath(resultPath);
							Assert.assertTrue(true);
						}
						else
						{
							String resultPath = searchDocumentPage.takeScreenshot();
							test.get(0).fail("Document is not filtered based on lifecycle status and document type: "+data.get("Life Cycle Status Expected")+","+data.get("Document Type Expected")).addScreenCaptureFromPath(resultPath);
							Assert.fail("Document is not filtered based on lifecycle status and document type: "+data.get("Life Cycle Status Expected")+","+data.get("Document Type Expected"));
						}
						searchDossierPage.closeMetaDataForm();
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).skip("Documents filtered not matching with expected filter, Expected filter is "+data.get("Filtered Documents Expected")).addScreenCaptureFromPath(resultPath);
						Assert.fail("Documents filtered not matching with expected filter, Expected filter is "+data.get("Filtered Documents Expected"));
					}
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).skip("Expected dossier not found in the search results").addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected dossier not found in the search results");
				}
			}
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
