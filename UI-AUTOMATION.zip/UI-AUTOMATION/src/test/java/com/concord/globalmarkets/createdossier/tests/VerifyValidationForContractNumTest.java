package com.concord.globalmarkets.createdossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.CreateDossierPage;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyValidationForContractNumTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	CreateDossierPage createDossierPage;
	
	String sheetName="CDP_ValidationForContNumTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("ValidationForContNumTest",authorName.get("ValidationForContNumTest"),moduleName.get("ValidationForContNumTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
				this.createDossierPage = new CreateDossierPage(driver);
				SearchDossierPage.navigateToCreateDossierPage();
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed: "+e);
			}
		}
		
		@Test(dataProvider="getData")
		public void validationForContractNumTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				createDossierPage.enterBCNumberContractNumberAndValidate(data.get("BC Number"),data.get("Contract Number"));
				if(createDossierPage.isIdentificationValidationDisplayed() && createDossierPage.getContractNumValidationMessage().equals(data.get("Expected Validation Message")))
				{
					String resultPath = createDossierPage.takeScreenshot();
					test.get(0).pass("Validation Message is as expected: "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
				}
				else
				{
					String resultPath = createDossierPage.takeScreenshot();
					test.get(0).fail("Validation message is not as expected: "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
				}
			} 
			catch(NoSuchElementException e)
			{
				String resultPath = createDossierPage.takeScreenshot();
				test.get(0).fail("No Validation exist: "+data.get("Expected Validation Message")).addScreenCaptureFromPath(resultPath);
			}
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}


}
