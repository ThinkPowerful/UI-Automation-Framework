package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;

public class VerifyDocumentTypeFilterTest extends BaseTest
{
	
SearchDocumentPage searchDocumentPage;
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("DocumentTypeFilterTest",authorName.get("DocumentTypeFilterTest"),moduleName.get("DocumentTypeFilterTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test
	public void verifyDocumentTypeFilterTest() throws InterruptedException, AWTException, IOException
	{
		searchDocumentPage.searchDocumentWithBcNumDocTypeAndDates("1694", "Business analysis document", "12-12-2011", "24-05-2020");
		try 
		{
			List<String> documentTypes = searchDocumentPage.getAllDocumentTypeValuesFromSearchResults();
			for(int i=0; i<documentTypes.size();i++)
			{
				if(documentTypes.get(i).trim().equals("Business analysis document"))
				{
					test.get(0).pass("Document type filter is working as expected: "+"Business analysis document");
					Assert.assertEquals(documentTypes.get(i).trim(), "Business analysis document");
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Document type filter is not working as expected: "+"Business analysis document").addScreenCaptureFromPath(resultPath);
					Assert.fail("Document type filter is not working as expected: "+"Business analysis document");
				}
			}
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).info("Document type filter screenshot attached").addScreenCaptureFromPath(resultPath);
		} 
		catch (TimeoutException e)
		{
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).fail("Timeout exception occured, please re-look").addScreenCaptureFromPath(resultPath);
			Assert.fail("Timeout exception occured, please re-look");
		}
		
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

}
