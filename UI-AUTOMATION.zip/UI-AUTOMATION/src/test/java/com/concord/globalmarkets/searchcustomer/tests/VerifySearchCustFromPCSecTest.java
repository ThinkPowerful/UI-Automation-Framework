package com.concord.globalmarkets.searchcustomer.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchCustomerPage;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySearchCustFromPCSecTest extends BaseTest
{
	
	SearchDocumentPage searchDocumentPage;
	SearchCustomerPage searchCustomerPage;
	String sheetName="SCP_SearchCustFromPCSecTest";
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try 
		{
			init("SearchCustFromPCSecTest",authorName.get("SearchCustFromPCSecTest"),moduleName.get("SearchCustFromPCSecTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
			this.searchCustomerPage = new SearchCustomerPage(driver);
		} 
		catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifySearchCustFromPCSecTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			searchDocumentPage.navigateToSearchCustomerPage().searchCustomersByPostalCode(data.get("Postal code"), data.get("House Number"),data.get("Country"));
			List<String> customerName = searchCustomerPage.getAllValuesFromaAttributeInSearchCustomerResults("Name");
			List<String> address = searchCustomerPage.getAllValuesFromaAttributeInSearchCustomerResults("Address");	
			List<String> dateOfBirth = searchCustomerPage.getAllValuesFromaAttributeInSearchCustomerResults("Date of Birth");
			if(customerName.size()==0)
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("There are no matching results found or service is unavailable").addScreenCaptureFromPath(resultPath);
			}
			else
			{
				for(int i=0; i<customerName.size();i++)
					{
						if(customerName.get(i).equals(data.get("Expected Customer Name")) && address.get(i).equals(data.get("Expected Address")) && dateOfBirth.get(i).equals(data.get("Expected DOB")))
						{
							test.get(0).pass("All the filters are working as expected: "+data.get("Expected Customer Name")+" , "+data.get("Expected Address")+" , "+data.get("Expected DOB"));
							Assert.assertEquals(customerName.get(i), data.get("Expected Customer Name"));
							Assert.assertEquals(address.get(i), data.get("Expected Address"));
							Assert.assertEquals(dateOfBirth.get(i), data.get("Expected DOB"));
							if(i==0)
							{
								String resultPath = searchDocumentPage.takeScreenshot();
								test.get(0).info("Results filtered with all the attributes in search results as expected").addScreenCaptureFromPath(resultPath);
							}
						}
						else
						{
							String resultPath = searchDocumentPage.takeScreenshot();
							test.get(0).fail("Filters are not working as expected: "+data.get("Expected Customer Name")+" , "+data.get("Expected Address")+" , "+data.get("Expected DOB")).addScreenCaptureFromPath(resultPath);
							if(i<customerName.size())
							{
							Assert.fail("Filters are not working as expected: "+data.get("Expected Customer Name")+" , "+data.get("Expected Address")+" , "+data.get("Expected DOB"));
							}
						}
					}
			}
		} 
			catch (TimeoutException e)
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("Timeout exception occured, please re-look").addScreenCaptureFromPath(resultPath);
				Assert.fail("Timeout exception occured, please re-look");
			}
			
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
	
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

}
