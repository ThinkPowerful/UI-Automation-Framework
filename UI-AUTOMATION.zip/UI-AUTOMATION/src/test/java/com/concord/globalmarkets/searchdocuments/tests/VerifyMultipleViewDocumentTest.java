package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyMultipleViewDocumentTest extends BaseTest
{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="VerifyMultipleViewDocumentTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("MultipleViewDocumentTest",authorName.get("MultipleViewDocumentTest"),moduleName.get("MultipleViewDocumentTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyMultipleViewDocumentTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDocumentPage.searchDocumentWithBcNumAndDates(data.get("BC Number"), data.get("From Date"), data.get("To Date"));
				String documentsToMerge = data.get("DocumentNames");
				List<String> documentsNames = Arrays.asList(documentsToMerge.split(","));
				searchDocumentPage.selectMultipleBaseDocumentsBasedOnDocumentName(documentsNames);
				searchDocumentPage.viewMultipleDocument();
				for(int i=0;i<documentsNames.size();i++)
				{
					searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("//div[@class='spinner']")));
					boolean isDocumentTitleMatches = driver.findElement(By.xpath("//h4[@id='modalTitle']")).getText().equals(documentsNames.get(i));
					boolean imageFileViewBlock = searchDocumentPage.isElementPresent("//img[@id='imgFileViewBlock']");
					if(isDocumentTitleMatches == true && imageFileViewBlock == true)
					{
						test.get(0).log(Status.INFO, "Passed: "+documentsNames.get(i));
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).pass("View Multiple document is working as expected").addScreenCaptureFromPath(resultPath);
						Assert.assertEquals((isDocumentTitleMatches), true);
					}
					else
					{
						test.get(0).log(Status.INFO, "Failed: "+documentsNames.get(i));
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).fail("View Multiple document is not working as expected").addScreenCaptureFromPath(resultPath);
						Assert.fail("View Multiple document is not working as expected");
					}
						if(i!=documentsNames.size()-1)
						{
							searchDocumentPage.viewNextDocument(documentsNames.get(i+1));
						}
				}
			}
				
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}


}
