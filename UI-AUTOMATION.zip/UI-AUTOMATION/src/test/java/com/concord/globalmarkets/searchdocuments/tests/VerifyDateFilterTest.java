
package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;

public class VerifyDateFilterTest extends BaseTest
{
SearchDocumentPage searchDocumentPage;
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("DateFilterTest",authorName.get("DateFilterTest"),moduleName.get("DateFilterTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test
	public void verifyDateFilterTest() throws InterruptedException, AWTException, IOException
	{
		searchDocumentPage.searchDocumentWithBcNumAndDates("1724", "16-05-2013", "16-05-2013");
		try 
		{
			List<String> createdOnValues = searchDocumentPage.getDateValuesFromSearchResults();
			if(createdOnValues.size()==0)
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).skip("Created On values from the search results is empty, check the test scripts").addScreenCaptureFromPath(resultPath);
				Assert.fail("Created On values from the search results is empty, check the test scripts");
			}
			for(int i=0; i<createdOnValues.size();i++)
			{
				if(createdOnValues.get(i).equals("16-05-2013"))
				{
					test.get(0).pass("Date filter is working as expected: 16-05-2013, Actual: "+createdOnValues.get(i));
					Assert.assertEquals(createdOnValues.get(i), "16-05-2013");
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Date filter is not working as expected: 16-05-2013, Actual: "+createdOnValues.get(i)).addScreenCaptureFromPath(resultPath);
					Assert.fail("Date filter is not working as expected: 16-05-2013, Actual: "+createdOnValues.get(i));
				}
			}
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).info("Date filter screenshot attached").addScreenCaptureFromPath(resultPath);
		} 
		catch (TimeoutException e)
		{
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).fail("Timeout exception occured, please re-look").addScreenCaptureFromPath(resultPath);
			Assert.fail("Timeout exception occured, please re-look");
		}
		
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

}
