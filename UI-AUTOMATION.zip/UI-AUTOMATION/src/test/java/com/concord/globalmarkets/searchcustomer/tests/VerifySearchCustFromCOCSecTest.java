package com.concord.globalmarkets.searchcustomer.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchCustomerPage;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySearchCustFromCOCSecTest extends BaseTest
{
	
	SearchDocumentPage searchDocumentPage;
	SearchCustomerPage searchCustomerPage;
	String sheetName="SCP_SearchCustFromCOCSecTest";
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("SearchCustFromCOCSecTest",authorName.get("SearchCustFromCOCSecTest"),moduleName.get("SearchCustFromCOCSecTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
			this.searchCustomerPage = new SearchCustomerPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifySearchCustFromNameSecTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			searchDocumentPage.navigateToSearchCustomerPage().searchCustomersByCOCNumber(data.get("COC Number"));
			List<String> customerName = searchCustomerPage.getAllValuesFromaAttributeInSearchCustomerResults("Name");
			List<String> bcNumber = searchCustomerPage.getAllValuesFromaAttributeInSearchCustomerResults("BC Number");	
			if(customerName.size()==0)
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("There are no matching results found or service is unavailable").addScreenCaptureFromPath(resultPath);
			}
			else
			{
				if(customerName.contains(data.get("Expected Customer Name")) && bcNumber.contains(data.get("Expected BCNumber")))
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("Expected BC Number Found in the search Results: "+data.get("Expected Customer Name")+" , "+data.get("Expected BCNumber")).addScreenCaptureFromPath(resultPath);;
					Assert.assertTrue(customerName.contains(data.get("Expected Customer Name")));
					Assert.assertTrue(customerName.contains(data.get("Expected BCNumber")));
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Expected BC Number not Found in the search Results: "+data.get("Expected Customer Name")+" , "+data.get("Expected BCNumber")).addScreenCaptureFromPath(resultPath);;
					Assert.fail("Expected BC Number not Found in the search Results: "+data.get("Expected Customer Name")+" , "+data.get("Expected BCNumber"));
				}
			}
			
		} 
			catch (TimeoutException e)
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("Timeout exception occured, please re-look").addScreenCaptureFromPath(resultPath);
				Assert.fail("Timeout exception occured, please re-look");
			}
			
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
	
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

}
