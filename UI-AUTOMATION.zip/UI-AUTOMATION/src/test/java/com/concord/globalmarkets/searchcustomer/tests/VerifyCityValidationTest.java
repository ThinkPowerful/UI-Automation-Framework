package com.concord.globalmarkets.searchcustomer.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchCustomerPage;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyCityValidationTest extends BaseTest
{
	
	SearchDocumentPage searchDocumentPage;
	SearchCustomerPage searchCustomerPage;
	String sheetName="SCP_CityValidationTest";
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("CityValidationTest",authorName.get("CityValidationTest"),moduleName.get("CityValidationTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
			this.searchCustomerPage = new SearchCustomerPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed: "+e);
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyCityValidationTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			searchDocumentPage.navigateToSearchCustomerPage().searchCustomersByName(data.get("Surname"), data.get("Initials"),data.get("Street name"),data.get("House Number"),data.get("City"),data.get("Date of Birth") );
			String actualValiadtionMessage = searchCustomerPage.getValidationMessage("City");
			if(searchCustomerPage.isElementPresent("//div[contains(@ng-messages,'city')]//span[@class='ng-scope']") && actualValiadtionMessage.equals(data.get("Expected Validation Message")))
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass(data.get("Expected Validation Message")+" :Validation exist for City").
				addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(actualValiadtionMessage, data.get("Expected Validation Message"));
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail(data.get("Expected Validation Message")+" :Validation does not exist for City").addScreenCaptureFromPath(resultPath);
				Assert.fail(data.get("Expected Validation Message")+" :Validation does not exist for City");
			}
		} 
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

}
