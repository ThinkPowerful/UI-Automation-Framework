package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;

public class VerifyValidationForContractNumberTest extends BaseTest
{
SearchDocumentPage searchDocumentPage;
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("ValidationsForContractNumberTest",authorName.get("ValidationsForContractNumberTest"),moduleName.get("ValidationsForContractNumberTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyValidationForContractNumberTest(String contractNumber, String validationExpected) throws InterruptedException, AWTException, IOException
	{
		searchDocumentPage.searchDocumentWithOnlyContractNumber(contractNumber);
		try 
		{
			
			String validationActual = searchDocumentPage.getValidationMessage();
			if(searchDocumentPage.isElementPresent("//div[@id='identifierAdministration']//p/span") && validationActual.equals(validationExpected))
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass(validationExpected+" ,Validation for incorrect contract number exist: "+contractNumber).addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(validationActual, validationExpected);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail(validationExpected+" ,Validation for incorrect contract number does not exist: "+contractNumber).addScreenCaptureFromPath(resultPath);
				Assert.fail(validationExpected+" ,Validation for incorrect contract number does not exist: "+contractNumber);
			}
		} 
		catch (TimeoutException e)
		{
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).fail(validationExpected+" ,Validation for incorrect contract number does not exist: "+contractNumber).addScreenCaptureFromPath(resultPath);
			Assert.fail(validationExpected+" ,Validation for incorrect contract number does not exist: "+contractNumber);
		}
		
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		Object[][] data = new Object[4][2];
		
		data[0][0] ="1234abcde";
		data[0][1] ="Only digits are allowed";

		data[1][0] =" ";
		data[1][1] ="Please fill identification number";
		
		data[2][0] ="55555";
		data[2][1] ="A contract number should consist of 8 to 10 digits";
		
		data[3][0] ="1234567891234";
		data[3][1] ="A contract number should consist of 8 to 10 digits";
		
		return data;
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}


}
