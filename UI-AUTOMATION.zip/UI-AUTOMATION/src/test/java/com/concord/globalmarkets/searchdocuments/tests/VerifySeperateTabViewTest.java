package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySeperateTabViewTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="SDP_SeperateTabViewTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("SeperateTabViewTest",authorName.get("SeperateTabViewTest"),moduleName.get("SeperateTabViewTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed: "+e);
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifySeperateTabViewTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDocumentPage.searchDocumentWithBcNumAndDates(data.get("BC Number"), data.get("From Date"), data.get("To Date"));
				String documentsToMerge = data.get("DocumentNames");
				List<String> documentsNames = Arrays.asList(documentsToMerge.split(","));
				searchDocumentPage.selectMultipleBaseDocumentsBasedOnDocumentName(documentsNames);
				searchDocumentPage.viewDocumentsInSeperateTabs();
				int numberOfTabsOpened = searchDocumentPage.getCountOfDocumentsViewedInSeperateTabs();
				Thread.sleep(5000);
				if(documentsNames.size()+1==numberOfTabsOpened)
					{
						Set<String> allWindowHandles=searchDocumentPage.allWindowHandles;
						Iterator<String> it = allWindowHandles.iterator();
						String mainTabWindow = driver.getWindowHandle();
						driver.switchTo().window(mainTabWindow);
						it.next();
						for(int i=0;i<numberOfTabsOpened-1;i++)
						{
							String tab = it.next();
							driver.switchTo().window(tab);
							String documentTitle = driver.findElement(By.xpath("//h4[@id='modalTitle']")).getText();
							String resultPath = searchDocumentPage.takeScreenshot();
							test.get(0).pass("Document viewed in the seperate tab: "+documentTitle).addScreenCaptureFromPath(resultPath);
							driver.close();
							Assert.assertEquals(numberOfTabsOpened,documentsNames.size()+1);
						}
						driver.switchTo().window(mainTabWindow);
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).fail("Seperate tab view functionality is not working as expected").addScreenCaptureFromPath(resultPath);
						Assert.fail("Seperate tab view functionality is not working as expected");
					}
				
			}
				
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}
	

}
