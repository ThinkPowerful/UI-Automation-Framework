package com.concord.globalmarkets.searchcustomer.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchCustomerPage;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyPostalCodeValidationTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchCustomerPage searchCustomerPage;
	String sheetName="SCP_PostalCodeValidationTest";
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("PostalCodeValidationTest",authorName.get("PostalCodeValidationTest"),moduleName.get("PostalCodeValidationTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
			this.searchCustomerPage = new SearchCustomerPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyPostalCodeValidationTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			searchDocumentPage.navigateToSearchCustomerPage().searchCustomersByPostalCode(data.get("Postal code"), data.get("House Number"), data.get("Country"));
			String actualValiadtionMessage = searchCustomerPage.getValidationMessage("Postal code");
			if(searchCustomerPage.isElementPresent("//div[contains(@ng-messages,'postalCode')]//span[@class='ng-scope']") && actualValiadtionMessage.equals(data.get("Expected Validation Message")))
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass(data.get("Expected Validation Message")+" :Validation exist for Postal Code").
				addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(actualValiadtionMessage, data.get("Expected Validation Message"));
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail(data.get("Expected Validation Message")+" :Validation does not exist for Postal Code").addScreenCaptureFromPath(resultPath);
				Assert.fail(data.get("Expected Validation Message")+" :Validation does not exist for Postal Code");
			}
		} 
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}

}
