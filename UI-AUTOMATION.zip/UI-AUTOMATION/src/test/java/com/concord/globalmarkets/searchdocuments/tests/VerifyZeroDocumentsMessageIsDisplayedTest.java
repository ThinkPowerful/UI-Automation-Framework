package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;

public class VerifyZeroDocumentsMessageIsDisplayedTest extends BaseTest
{

SearchDocumentPage searchDocumentPage;
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("ZeroDocumentsMessageIsDisplayedTest",authorName.get("ZeroDocumentsMessageIsDisplayedTest"),moduleName.get("ZeroDocumentsMessageIsDisplayedTest"));
			if(driver==null){
				openBrowser("Chrome");
				}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed: "+e);
		}
	}
	
	@Test
	public void verifyZeroDocumentsMessageIsDisplayedTest() throws InterruptedException, AWTException, IOException
	{
		searchDocumentPage.searchDocumentWithBCNumber("1694", "Driver license", "Concord", "junktexterere", "22-02-2017", "23-05-2018");
		
		try
		{
			if(searchDocumentPage.isZeroDocumentsFoundMessageDisplayed())
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass("0 documents found message is displayed").addScreenCaptureFromPath(resultPath);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("0 documents found message is not displayed").addScreenCaptureFromPath(resultPath);
			}
		}
		
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
		//driver.close();
	}
}
