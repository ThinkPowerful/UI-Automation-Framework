package com.concord.globalmarkets.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySearchDossierWithBCNumTest extends BaseTest
{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	String sheetName="SDP_SearchDossierWithBCNumTest";
	
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("SearchDossierWithBCNumTest",authorName.get("SearchDossierWithBCNumTest"),moduleName.get("SearchDossierWithBCNumTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed: "+e);
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifySearchDossierWithBCNumTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), data.get("From Date"), data.get("To Date"));
				searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierFound(data.get("Expected Dossier"),data.get("Expected Dossier Creation Date")))
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("Expected Dossier found in the search result: "+data.get("Expected Dossier")).addScreenCaptureFromPath(resultPath);
					Assert.assertTrue(true);
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Expected Dossier not found in the search result: "+data.get("Expected Dossier")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected Dossier not found in the search result ");
				}
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}


}
