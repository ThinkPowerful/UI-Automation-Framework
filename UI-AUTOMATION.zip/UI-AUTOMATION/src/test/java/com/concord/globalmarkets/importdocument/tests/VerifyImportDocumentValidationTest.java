package com.concord.globalmarkets.importdocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.constants.ImportDocumentPageObjects;
import com.concord.globalmarkets.pages.CreateDossierPage;
import com.concord.globalmarkets.pages.ImportDocumentPage;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyImportDocumentValidationTest extends BaseTest{

	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	CreateDossierPage createDossierPage;
	ImportDocumentPage importDocumentPage;

	String sheetName = "IDP_SingleDocumentImport";

	@BeforeClass
	private void launchApplication() {
		try {
			init("ImportDocumentValidationsTest", authorName.get("ImportDocumentValidationsTest"),
					moduleName.get("ImportDocumentValidationsTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
			this.createDossierPage = new CreateDossierPage(driver);
			this.importDocumentPage = new ImportDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider = "getData")
	private void verifyImportDocFields(Hashtable<String, String> data)
			throws InterruptedException, AWTException, IOException {
		try {
			SearchDossierPage.navigateToCreateDossierPage();
			createDossierPage.createProcessDossier(data.get("BC Number"), data.get("Contract Number"),
					data.get("Process Name"), data.get("Description"));
			CreateDossierPage.navigateToImportDocumentPage();
			if(importDocumentPage.isMandatoryFieldValidationDisplayed(data.get("Document Name"),data.get("Document Type"))) {
				String resultPath = importDocumentPage.takeScreenshot();
				test.get(0).pass("Document Name and Document Type are mandatory as expected").addScreenCaptureFromPath(resultPath);
				importDocumentPage.cancelAndReturnToSearchScreen();
				//searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Assert.assertTrue(true);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("Mandatory validation not displayed").addScreenCaptureFromPath(resultPath);
				importDocumentPage.cancelAndReturnToSearchScreen();
				//searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Assert.fail("Import document is not successfull");
			}
		} catch (Exception e) 
		{
			String resultPath =importDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			Assert.fail("Skipping the test due to an exception: "+e.getMessage());
		}
	}
	
	

	@DataProvider(name = "getData")
	private Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(
				new Xls_Reader(System.getProperty("user.dir") + "\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun = true)
	private void tearDown() throws IOException {
		//driver.quit();
	}

}
