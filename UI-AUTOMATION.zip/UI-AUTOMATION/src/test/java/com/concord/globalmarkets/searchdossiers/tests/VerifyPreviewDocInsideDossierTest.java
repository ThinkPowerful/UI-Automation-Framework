package com.concord.globalmarkets.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyPreviewDocInsideDossierTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	String sheetName="SDP_PreviewDocInsideDossierTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("PreviewDocInsideDossierTest",authorName.get("PreviewDocInsideDossierTest"),moduleName.get("PreviewDocInsideDossierTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@SuppressWarnings("static-access")
		@Test(dataProvider="getData")
		public void verifyPreviewDocInsideDossierTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), data.get("From Date"), data.get("To Date"));
				searchDocumentPage.waitForInVisiblityOfAllElements(driver.findElements(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierFound(data.get("Dossier Name"),data.get("Dossier Creation Time")))
				{
					//searchDossierPage.expandTheDossierBasedOnDossierNameAndCreationDate(data.get("Dossier Name"), data.get("Dossier Creation Time"));
					searchDossierPage.waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
					searchDossierPage.previewDocumentInsideDossier(data.get("Expected Document to Preview"));
					searchDossierPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("//div[@class='spinner']")));
					if(data.get("Expected Document to Preview").contains("xml") || data.get("Expected Document to Preview").contains("jpg") || data.get("Expected Document to Preview").contains("png"))
					{
						boolean FileViewBlock = searchDocumentPage.isElementPresent("//img[contains(@id,'Block')]"); 
						boolean isDocumentTitleMatches = driver.findElement(By.xpath("//h4[@id='modalTitle']")).getText().equals(data.get("Expected Document to Preview"));
							if(FileViewBlock && isDocumentTitleMatches)
							{
								String resultPath = searchDocumentPage.takeScreenshot();
								test.get(0).pass("Document Preview is as expected: "+data.get("Expected Document to Preview")).addScreenCaptureFromPath(resultPath);
								Assert.assertTrue(FileViewBlock && isDocumentTitleMatches);
							}
							else
							{
								String resultPath = searchDocumentPage.takeScreenshot();
								test.get(0).fail("Document Preview is not as expected: "+data.get("Expected Document to Preview")).addScreenCaptureFromPath(resultPath);
								Assert.fail("Document Preview is not as expected: ");
							}
							searchDocumentPage.closeDocmentPopup();
					}
					else if(data.get("Expected Document to Preview").contains("pdf"))
					{
							driver.switchTo().frame(0);
							boolean pdfToolBarVisible = searchDocumentPage.isElementPresent("(//div[@class='textLayer'])[1]");
							if(pdfToolBarVisible == true)
							{
								String resultPath = searchDocumentPage.takeScreenshot();
								test.get(0).pass("Document Preview is as expected: "+data.get("Expected Document to Preview")).addScreenCaptureFromPath(resultPath);
								Assert.assertEquals(pdfToolBarVisible, true);
							}
							else
							{
								String resultPath = searchDocumentPage.takeScreenshot();
								test.get(0).fail("Document Preview is not as expected: "+data.get("Expected Document to Preview")).addScreenCaptureFromPath(resultPath);
								Assert.fail("Document Preview is not as expected: ");
							}
							driver.switchTo().defaultContent();
							searchDocumentPage.closeDocmentPopup();
					}
					else if(data.get("Expected Document to Preview").contains("txt"))
					{
						boolean FileViewBlock = searchDocumentPage.isElementPresent(".//*[@id='textFileViewBlock']"); 
						boolean isDocumentTitleMatches = driver.findElement(By.xpath("//h4[@id='modalTitle']")).getText().equals(data.get("Expected Document to Preview"));
							if(FileViewBlock && isDocumentTitleMatches)
							{
								String resultPath = searchDocumentPage.takeScreenshot();
								test.get(0).pass("Document Preview is as expected: "+data.get("Expected Document to Preview")).addScreenCaptureFromPath(resultPath);
								Assert.assertTrue(FileViewBlock && isDocumentTitleMatches);
							}
							else
							{
								String resultPath = searchDocumentPage.takeScreenshot();
								test.get(0).fail("Document Preview is not as expected: "+data.get("Expected Document to Preview")).addScreenCaptureFromPath(resultPath);
								Assert.fail("Document Preview is not as expected: ");
							}
							searchDocumentPage.closeDocmentPopup();
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).skip("Document Format Unsupported "+data.get("Expected Document to Preview")).addScreenCaptureFromPath(resultPath);
					}
						
					}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Expected Dossier not found in the search result: "+data.get("Dossier Name")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected Dossier not found in the search result ");
				}
				searchDossierPage.scrollToTop();
			}
			catch(NoSuchElementException e)
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception, No document found "+data.get("Expected Document to Preview")).addScreenCaptureFromPath(resultPath);
				
			}
			
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
