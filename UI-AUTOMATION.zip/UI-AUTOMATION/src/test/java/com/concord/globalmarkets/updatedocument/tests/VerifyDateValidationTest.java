package com.concord.globalmarkets.updatedocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.globalmarkets.pages.UpdateDocumentPage;
import com.concord.globalmarkets.pages.UpdateDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyDateValidationTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	UpdateDossierPage updateDossierPage;
	UpdateDocumentPage updateDocumentPage;
	
	String sheetName="EDP_ReqFieldValidationsTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("ReqFieldValidationsTest",authorName.get("ReqFieldValidationsTest"),moduleName.get("ReqFieldValidationsTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
				this.updateDossierPage = new UpdateDossierPage(driver);
				this.updateDocumentPage= new UpdateDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifySearchDosWithContNumTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), data.get("From Date"), data.get("To Date"));
				searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierFound(data.get("Dossier Name"),data.get("Dossier Creation Date")))
				{
					SearchDossierPage.navigateToUpdateDocumentPage(data.get("Document Name"));
					if(updateDocumentPage.isMandatoryFieldValidationDisplayed())
					{
					String resultPath = updateDocumentPage.takeScreenshot();
					test.get(0).pass("Document Name and Document Type are mandatory as expected").addScreenCaptureFromPath(resultPath);
					updateDocumentPage.cancelAndReturnToSearchScreen();
					updateDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
					Assert.assertTrue(true);
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).fail("Mandatory validation not displayed").addScreenCaptureFromPath(resultPath);
						updateDocumentPage.cancelAndReturnToSearchScreen();
						updateDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
						Assert.fail("Document not updated successfully ");
					}
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).skip("Dossier not found in the search results").addScreenCaptureFromPath(resultPath);
					Assert.fail("Dossier not found in the search results");
				}
				
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
				Assert.fail("Skipping the test due to an exception: "+e.getMessage());
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

	

}
