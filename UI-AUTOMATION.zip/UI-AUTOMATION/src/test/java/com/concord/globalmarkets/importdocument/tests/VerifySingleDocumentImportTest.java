package com.concord.globalmarkets.importdocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.CreateDossierPage;
import com.concord.globalmarkets.pages.ImportDocumentPage;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySingleDocumentImportTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	CreateDossierPage createDossierPage;
	ImportDocumentPage importDocumentPage;
	
	String sheetName="IDP_SingleDocumentImport";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("SingleDocumentImportTest",authorName.get("SingleDocumentImportTest"),moduleName.get("SingleDocumentImportTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
				this.createDossierPage = new CreateDossierPage(driver);
				this.importDocumentPage = new ImportDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		@Test(dataProvider="getData")
		public void verifySingleDocumentImportTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				SearchDossierPage.navigateToCreateDossierPage();
				createDossierPage.createProcessDossier(data.get("BC Number"), data.get("Contract Number"), data.get("Process Name"), data.get("Description"));
				CreateDossierPage.navigateToImportDocumentPage();
				importDocumentPage.importDocument(data.get("Document Name"),data.get("Document Type"));
				if(CreateDossierPage.isElementPresent("//span[text()='Dossier created']") && ImportDocumentPage.isElementPresent("//span[contains(text(),'Document imported successfully')]"))
				{
					String resultPath = createDossierPage.takeScreenshot();
					test.get(0).pass("Import Document is working as expected: "+data.get("Document Name")).addScreenCaptureFromPath(resultPath);
				}
				else
				{
					String resultPath = createDossierPage.takeScreenshot();
					test.get(0).fail("Import Document is not working as expected: "+data.get("Document Name")).addScreenCaptureFromPath(resultPath);
				}
				ImportDocumentPage.navigateToSearchDossierScreen();
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}
}
