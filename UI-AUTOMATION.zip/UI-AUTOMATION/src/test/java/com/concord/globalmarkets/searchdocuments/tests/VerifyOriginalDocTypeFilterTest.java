package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyOriginalDocTypeFilterTest extends BaseTest{
	
SearchDocumentPage searchDocumentPage;
String sheetName="SDP_OriginalDocTypeFilter";
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("OriginalDocTypeFilterTest",authorName.get("OriginalDocTypeFilterTest"),moduleName.get("OriginalDocTypeFilterTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyDocumentTypeFilterTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		searchDocumentPage.searchDocumentWithBcNumberOriginalDocTypeAndDates(data.get("BC Number"), data.get("Original Document Type"), data.get("From"), data.get("To"));
		try 
		{
			List<String> documentTypes = searchDocumentPage.isDocumentFilteredByOriginalDocType();
			if(documentTypes.size()==0)
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).skip("document type array from the search results is empty, check the test scripts").addScreenCaptureFromPath(resultPath);
				Assert.fail("document type array from the search results is empty, check the test scripts");
			}
			for(int i=0; i<documentTypes.size();i++)
			{
				if(documentTypes.get(i).equals(data.get("Expected Original Document Type")))
				{
					test.get(0).pass("Original document type filter is working as expected: "+data.get("Expected Original Document Type"));
					Assert.assertEquals(documentTypes.get(i), data.get("Expected Original Document Type"));
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Original document type filter is not working as expected: "+data.get("Expected Original Document Type")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Original document type filter is not working as expected: "+data.get("Expected Original Document Type"));
				}
			}
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).info("Original document type filter screenshot attached").addScreenCaptureFromPath(resultPath);
		} 
		catch (TimeoutException e)
		{
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).fail("Timeout exception occured, please re-look").addScreenCaptureFromPath(resultPath);
			Assert.fail("Timeout exception occured, please re-look");
		}
		
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}
	

}
