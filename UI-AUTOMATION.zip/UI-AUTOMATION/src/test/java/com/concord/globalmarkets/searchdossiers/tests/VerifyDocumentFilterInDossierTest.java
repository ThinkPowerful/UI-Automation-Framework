package com.concord.globalmarkets.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyDocumentFilterInDossierTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	String sheetName="SDP_DocumentFilterInDossierTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("DocumentFilterInDossierTest",authorName.get("DocumentFilterInDossierTest"),moduleName.get("DocumentFilterInDossierTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyDocumentInsideDossierTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), data.get("From Date"), data.get("To Date"));
				searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierFound(data.get("Dossier Name"),data.get("Dossier Creation Time")))
				{
					//searchDossierPage.expandTheDossierBasedOnDossierNameAndCreationDate(data.get("Dossier Name"), data.get("Dossier Creation Time"));
					BasePage.waitForInVisiblityOfAllElements(driver.findElements(By.xpath("//div[@class='spinner']")));
					searchDossierPage.searchDocumentInsideDossier(data.get("Search Document Name"));
					if(searchDossierPage.isElementPresent("//span[text()='document(s) found']")==false)
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).pass("Search filter for documents inside dossier is working as expected: "+data.get("Search Document Name")).addScreenCaptureFromPath(resultPath);
						Assert.assertFalse(searchDossierPage.isElementPresent("//span[text()='document(s) found']"));
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).fail("Search filter for documents inside dossier is not working as expected: "+data.get("Search Document Name")).addScreenCaptureFromPath(resultPath);
						Assert.fail("Search filter for documents inside dossier is not working as expected: ");
					}
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Expected Dossier not found in the search result: "+data.get("Dossier Name")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected Dossier not found in the search result ");
				}
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
