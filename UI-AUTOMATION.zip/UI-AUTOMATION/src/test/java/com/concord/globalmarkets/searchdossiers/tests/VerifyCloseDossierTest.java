package com.concord.globalmarkets.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.CreateDossierPage;
import com.concord.globalmarkets.pages.ImportDocumentPage;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyCloseDossierTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	CreateDossierPage createDossierPage;
	
	String sheetName="SDP_CloseDossierTest";
	
	
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("CloseDossierTest",authorName.get("CloseDossierTest"),moduleName.get("CloseDossierTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
				this.createDossierPage = new CreateDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyDocumentInsideDossierTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				SearchDossierPage.navigateToCreateDossierPage();
				createDossierPage.createProcessDossier(data.get("BC Number"), data.get("Contract Number"), data.get("Process Name"), data.get("Description"));
				CreateDossierPage.navigateToImportDocumentPage();
				ImportDocumentPage.submitDossierAndDocuments();
				ImportDocumentPage.navigateToSearchDossierScreen();
				//searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"));
				//searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierClosedSuccessfully(data.get("Dossier Name")))
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("Dossier Closed successfully and Import , Edit , Close options are disabled: "+data.get("Dossier Name")).addScreenCaptureFromPath(resultPath);
					Assert.assertTrue(true);
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Dossier not closed successfully, check if Import, Edit Close options are clickable: "+data.get("Dossier Name")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Dossier not closed successfully, check if Import, Edit Close options are clickable: ");
				}
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
