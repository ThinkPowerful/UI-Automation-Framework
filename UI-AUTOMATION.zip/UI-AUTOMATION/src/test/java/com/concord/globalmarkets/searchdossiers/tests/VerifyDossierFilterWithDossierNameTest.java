package com.concord.globalmarkets.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyDossierFilterWithDossierNameTest extends BaseTest{

	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	String sheetName="SDP_DossFilterWithDosNamTest";
	
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("DossierFilterWithDossierNameTest",authorName.get("DossierFilterWithDossierNameTest"),moduleName.get("DossierFilterWithDossierNameTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyDossierFilterWithDossierNameTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), data.get("From Date"), data.get("To Date"));
			searchDossierPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
			Thread.sleep(5000);
			try {
				if(SearchDossierPage.isElementPresent("//h3[text()='System error']")==false)
				{
					List<String> dossierNames = searchDossierPage.getAllDossierNamesFromSearchResults();
					for(int i=0; i<dossierNames.size();i++)
					{
						if(dossierNames.get(i).contains(data.get("Expected String In dossier name")))
						{
							test.get(0).pass("Dossier name filter is working as expected: "+dossierNames.get(i));
							Assert.assertTrue(dossierNames.get(i).contains(data.get("Expected String In dossier name")));
						}
						else
						{
							String resultPath = searchDossierPage.takeScreenshot();
							test.get(0).fail("Dossier name filter is not working as expected: "+dossierNames.get(i)).addScreenCaptureFromPath(resultPath);
							Assert.fail("Dossier name filter is not working as expected: "+dossierNames.get(i));
						}
					}
				}
				else
				{
					String resultPath = searchDossierPage.takeScreenshot();
					test.get(0).fail("Search Dossier operation failed").addScreenCaptureFromPath(resultPath);
					Assert.fail("Search Dossier operation failed");
				}
				String resultPath = searchDossierPage.takeScreenshot();
				test.get(0).info("Dossier name filter screenshot attached").addScreenCaptureFromPath(resultPath);
			} 
			catch (TimeoutException e)
			{
				String resultPath = searchDossierPage.takeScreenshot();
				test.get(0).fail("Timeout exception occured, please re-look").addScreenCaptureFromPath(resultPath);
				Assert.fail("Timeout exception occured, please re-look");
			}
			catch (Exception e) 
			{
				String resultPath =searchDossierPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}
	
}
