package com.concord.globalmarkets.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyPageSizeFilterTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	String sheetName="SDP_PageSizeFilterTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("PageSizeFilterTest",authorName.get("PageSizeFilterTest"),moduleName.get("PageSizeFilterTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyPageSizeFilterTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), data.get("From Date"), data.get("To Date"));
				SearchDocumentPage.waitForInVisiblityOfAllElements(driver.findElements(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierFound(data.get("Dossier Name"),data.get("Dossier Creation Time")))
				{
					searchDossierPage.filterByPageSize(data.get("Dossier Name"),  data.get("Page Size"));
					String countOfDocumentAfterFilter = SearchDossierPage.getCountOfElement("//span[@title='View document']");
					if(countOfDocumentAfterFilter.equals(data.get("Page Size")))
					{
							String resultPath = searchDocumentPage.takeScreenshot();
							test.get(0).pass("Document is filtered bases on the page size Expected: "+data.get("Page Size")+",Actual: "+countOfDocumentAfterFilter).addScreenCaptureFromPath(resultPath);
							Assert.assertTrue(true);
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).fail("Document is not filtered based on the page size: "+data.get("Page Size")+",Actual: "+countOfDocumentAfterFilter).addScreenCaptureFromPath(resultPath);
						Assert.fail("Document is not filtered based on the page size: "+data.get("Page Size")+",Actual: "+countOfDocumentAfterFilter);
					}
				}
			else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).skip("Expected dossier not found in the search results").addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected dossier not found in the search results");
				}
			}
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
