package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyAdditionalIdentifierFilterTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="SDP_AdditionalIdentifierFilter";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("AdditionalIdentifierFilterTest",authorName.get("AdditionalIdentifierFilterTest"),moduleName.get("AdditionalIdentifierFilterTest"));
				if(driver==null){
				openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed: "+e);
			}
		}
		
		@Test(dataProvider="getData")
		public void verifyDocumentTypeFilterTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			searchDocumentPage.searchDocumentWithBcNumberAdditionalIdentificationAndDates(data.get("BC Number"), data.get("Additional Identification Key"), data.get("Additional Identification Value"), data.get("From"), data.get("To"));
			try 
			{
				boolean documentFound = searchDocumentPage.isDocumentFound(data.get("Expected Document Name"), data.get("Expected Document ID"));
					if(documentFound)
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).pass("Additional Identification filter is working as expected: "+data.get("Expected Document ID")).addScreenCaptureFromPath(resultPath);
						Assert.assertEquals(documentFound,true);
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).fail("Additional Identification filter is not working as expected: "+data.get("Expected Document ID")).addScreenCaptureFromPath(resultPath);
						Assert.fail("Additional Identification filter is not working as expected: "+data.get("Expected Document ID"));
					}
			
			} 
			catch (TimeoutException e)
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("Timeout exception occured, please re-look").addScreenCaptureFromPath(resultPath);
				Assert.fail("Timeout exception occured, please re-look");
			}
			
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}
		

}
