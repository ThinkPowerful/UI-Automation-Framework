package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;

public class VerifyInformationMessageTest extends BaseTest
{
SearchDocumentPage searchDocumentPage;
	

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("InformationMessageTest",authorName.get("InformationMessageTest"),moduleName.get("InformationMessageTest"));
			openBrowser("Chrome");
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed: "+e);
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyInformationMessageTest(String field, String infoMessageExpected) throws InterruptedException, AWTException, IOException
	{
		String infoMessageActual=null;
		try 
		{
			infoMessageActual=searchDocumentPage.getTextFromInfoButton(field);
			if(infoMessageActual.equals(infoMessageExpected))
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass(field + " Info message is as expected").addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(infoMessageActual, infoMessageExpected);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail(field +" Info message is as not as expected").addScreenCaptureFromPath(resultPath);
				Assert.fail(field +" Info message is as not as expected");
			}
		} 
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip(field +" Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		Object[][] data = new Object[5][2];
		
		data[0][0] ="Customer";
		data[0][1] ="Please fill in Identifer, so you can find the documents you are looking for";

		data[1][0] ="Document Type";
		data[1][1] ="Please select one or more document types, to specify the search results";
		
		data[2][0] ="Document Source";
		data[2][1] ="Please select one of the document sources, to specify the search results";
		
		data[3][0] ="Document Name";
		data[3][1] ="Please fill in document name/original document type to specify your search. It is allowed to fill in multiple search phrases, use the separators ‘blank space’ or , (comma) or ; (semicolon)";
		
		data[4][0] ="To";
		data[4][1] ="The default date range is six months. Select another date range to limit or extend the search results";

		return data;
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
		//driver.close();
	}
	
	

}
