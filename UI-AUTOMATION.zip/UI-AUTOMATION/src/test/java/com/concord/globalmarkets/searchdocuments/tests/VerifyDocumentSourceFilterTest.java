
package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;

public class VerifyDocumentSourceFilterTest extends BaseTest
{
SearchDocumentPage searchDocumentPage;

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("DocumentSourceFilterTest",authorName.get("DocumentSourceFilterTest"),moduleName.get("DocumentSourceFilterTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	
	@Test(dataProvider="getData")
	public void verifyDocumentSourceFilterTest(String documentSource, String expectedDocumentId) throws InterruptedException, AWTException, IOException
	{
		searchDocumentPage.searchDocumentWithBcNumDocSourceAndDates("1724",documentSource,"16-05-2013", "16-05-2013");
		try 
		{
			boolean isDocumentFound = searchDocumentPage.isEarchiveDocumentPresentInSearchResults(expectedDocumentId);
			if(isDocumentFound)
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("Document source filter is working as expected: "+expectedDocumentId).addScreenCaptureFromPath(resultPath);;
					Assert.assertEquals(isDocumentFound,true);
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Document source filter is not working as expected: "+expectedDocumentId).addScreenCaptureFromPath(resultPath);
					Assert.fail();
				}
		} 
		catch (TimeoutException e)
		{
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).fail("Timeout exception occured, please re-look").addScreenCaptureFromPath(resultPath);
			Assert.fail("Timeout exception occured, please re-look");
		}
		
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		Object[][] data = new Object[1][2];
		
		data[0][0] ="Document Generator";
		data[0][1] ="N015B8AA";
		
		/*data[1][0] ="Scanner";
		data[1][1] ="N004B8AA";
		
		data[2][0] ="Internet Banking";
		data[2][1] ="N003B8AA";
		
		data[3][0] ="Connector";
		data[3][1] ="N024B8AA";*/
		
		return data;
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}	
	
	
	


}
