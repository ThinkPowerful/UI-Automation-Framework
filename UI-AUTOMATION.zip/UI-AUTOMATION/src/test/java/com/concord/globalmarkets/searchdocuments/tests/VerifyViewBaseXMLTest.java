package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyViewBaseXMLTest extends BaseTest
{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="VerifyViewBaseXMLTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("ViewBaseXMLTest",authorName.get("ViewBaseXMLTest"),moduleName.get("ViewBaseXMLTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyViewBaseXMLTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDocumentPage.searchDocumentWithBcNumDocTypeAndDates(data.get("BC Number"), data.get("Document Type"), data.get("From Date"), data.get("To Date"));
				searchDocumentPage.viewBaseDocumentBasedOnDocumentName(data.get("Document Name"));
				searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("//div[@class='spinner']")));
				boolean xmlFileViewBlock = searchDocumentPage.isElementPresent("//div[@id='xmlFileViewBlock']");
				boolean isDocumentTitleMatches = driver.findElement(By.xpath("//h4[@id='modalTitle']")).getText().equals(data.get("Document Name"));
				boolean xmlFileLargeSize = searchDocumentPage.isElementPresent("//span[text()='Document preview is not possible because of large size']");
				if((xmlFileViewBlock == true && isDocumentTitleMatches == true) || (xmlFileLargeSize == true && isDocumentTitleMatches == true))
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("View Base XML is working as expected").
					addScreenCaptureFromPath(resultPath);
					Assert.assertEquals((xmlFileViewBlock || xmlFileLargeSize), true);
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("View Base XML is not working as expected").addScreenCaptureFromPath(resultPath);
					Assert.fail("View Base XML is not working as expected");
				}
				searchDocumentPage.closeDocmentPopup();
			} 
			
			catch (NoSuchElementException e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).fail("No results found in the search results to view the XML file. "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
			
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
