package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyMergePdfTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="SDP_MergePdfTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("MergePdfTest",authorName.get("MergePdfTest"),moduleName.get("MergePdfTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed: "+e);
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyMergePdfTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDocumentPage.searchDocumentWithBcNumAndDates(data.get("BC Number"), data.get("From Date"), data.get("To Date"));
				String documentsToMerge = data.get("DocumentNames");
				List<String> documentsNames = Arrays.asList(documentsToMerge.split(","));
				searchDocumentPage.selectMultipleBaseDocumentsBasedOnDocumentName(documentsNames);
				searchDocumentPage.mergePdfDocuments();
				Thread.sleep(15000);
				if(searchDocumentPage.isPdfMergedSuccessfully())
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).pass("MergePDF functionality is working as expected").addScreenCaptureFromPath(resultPath);
						Assert.assertEquals((searchDocumentPage.isPdfMergedSuccessfully()),true);
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).fail("MergePDF functionality is not working as expected").addScreenCaptureFromPath(resultPath);
						Assert.fail("MergePDF functionality is not working as expected");
					}
				
			}
				
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}


}
