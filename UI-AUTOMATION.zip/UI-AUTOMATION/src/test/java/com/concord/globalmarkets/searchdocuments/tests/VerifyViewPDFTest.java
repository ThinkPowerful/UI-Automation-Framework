package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyViewPDFTest extends BaseTest
{
	
SearchDocumentPage searchDocumentPage;
String sheetName="VerifyViewPDFTest";
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("ViewPDFTest",authorName.get("ViewPDFTest"),moduleName.get("ViewPDFTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	
	@Test(dataProvider="getData")
	public void verifyViewPDFTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		System.out.println(data.get("BC Number"));
		try {
			searchDocumentPage.searchDocumentWithBcNumDocTypeAndDates(data.get("BC Number"), data.get("Document Type"), data.get("From Date"), data.get("To Date"));
			searchDocumentPage.viewBaseDocumentBasedOnDocumentName(data.get("Document Name"));
			searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("//div[@class='spinner']")));
			driver.switchTo().frame(0);
			boolean pdfToolBarVisible = searchDocumentPage.isElementPresent("(//div[@class='textLayer'])[1]");
			if(pdfToolBarVisible == true)
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass("View PDF is working as expected").
				addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(pdfToolBarVisible, true);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("View PDF is not working as expected").addScreenCaptureFromPath(resultPath);
				Assert.fail("View PDF is not working as expected");
			}
			driver.switchTo().defaultContent();
			searchDocumentPage.closeDocmentPopup();
		} 
		
		catch (NoSuchFrameException e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).fail("Unable to view pdf as there no results found: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}
	
}
