package com.concord.globalmarkets.searchdossiers.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyInfoMessageInDossierTest extends BaseTest {
	
SearchDocumentPage searchDocumentPage;
SearchDossierPage searchDossierPage;
String sheetName="SDP_InfoMessageInDossierTest";
	

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("InfoMessageInDossierTest",authorName.get("InfoMessageInDossierTest"),moduleName.get("InfoMessageInDossierTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyInfoMessageInDossierTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		String infoMessageActual=null;
		try 
		{
			infoMessageActual=searchDossierPage.getTextFromInfoButton(data.get("Field Name"));
			if(infoMessageActual.equals(data.get("Expected Information message")))
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass(data.get("Field Name")+" : "+data.get("Expected Information message") + " :Info message is as expected").addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(infoMessageActual, data.get("Expected Information message"));
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail(data.get("Field Name")+" : "+data.get("Expected Information message") + " :Info message is as not as expected").addScreenCaptureFromPath(resultPath);
				Assert.fail(infoMessageActual +" Info message is as not as expected");
			}
		} 
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip(data.get("Field Name") +" Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			
		}
	}
	
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}
	

}
