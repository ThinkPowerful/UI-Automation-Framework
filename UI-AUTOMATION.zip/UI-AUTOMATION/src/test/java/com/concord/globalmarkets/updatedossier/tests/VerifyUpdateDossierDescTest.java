package com.concord.globalmarkets.updatedossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.globalmarkets.pages.SearchDossierPage;
import com.concord.globalmarkets.pages.UpdateDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyUpdateDossierDescTest extends BaseTest
{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	UpdateDossierPage updateDossierPage;
	String sheetName="UDP_UpdateDossierDescTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("UpdateDossierDescTest",authorName.get("UpdateDossierDescTest"),moduleName.get("UpdateDossierDescTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
				this.updateDossierPage = new UpdateDossierPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifySearchDosWithContNumTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), data.get("From Date"), data.get("To Date"));
				searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				if(searchDossierPage.isDossierFound(data.get("Dossier Name"),data.get("Dossier Creation Date")))
				{
					SearchDossierPage.navigateToUpdateDossierPage().updateDossierDescription(data.get("Dossier Description"));
					if(updateDossierPage.isDossierUpdatedSuccessfully())
					{
					String resultPath = updateDossierPage.takeScreenshot();
					test.get(0).pass("Dossier updated successfully with the description: "+data.get("Dossier Description")).addScreenCaptureFromPath(resultPath);
					updateDossierPage.returnToSearchScreen();
					//updateDossierPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
					Assert.assertTrue(true);
					}
					else
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).fail("Dossier not updated successfully").addScreenCaptureFromPath(resultPath);
						updateDossierPage.cancelAndReturnToSearchScreen();
						//updateDossierPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
						Assert.fail("Dossier not updated successfully ");
					}
				}
				
				else
				{
					String resultPath = searchDossierPage.takeScreenshot();
					test.get(0).skip("Dossier not found in the search results").addScreenCaptureFromPath(resultPath);
					Assert.fail("Dossier not found in the search results");
				}
				
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
