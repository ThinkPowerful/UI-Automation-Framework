package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;

public class VerifyClientNameDisplayedWithBcNumTest extends BaseTest
{
SearchDocumentPage searchDocumentPage;
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("ClientNameDisplayedWithBcNumTest",authorName.get("ClientNameDisplayedWithBcNumTest"),moduleName.get("ClientNameDisplayedWithBcNumTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed: "+e);
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyInformationMessageTest(String bcNumber, String clientNameExpected) throws InterruptedException, AWTException, IOException
	{
		
		searchDocumentPage.searchDocumentWithOnlyBCNumber(bcNumber);
		try 
		{
			String clientNameActual = searchDocumentPage.getClientName();
			if(searchDocumentPage.isClientNameDisplayed() && clientNameActual.equals(clientNameExpected))
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass("Client Name is displayed and matches for the bc number: "+bcNumber).addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(clientNameActual, clientNameExpected);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail("Client Name is displayed and not matches for the bc number: "+bcNumber).addScreenCaptureFromPath(resultPath);
				Assert.fail("Client Name is displayed and not matches for the bc number: "+bcNumber);
			}
		}
		catch (TimeoutException e)
		{
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).fail("Client Name is not displayed and hence not matches for the contract number: "+bcNumber).addScreenCaptureFromPath(resultPath);
			Assert.fail("Client Name is not displayed and hence not matches for the contract number: "+bcNumber);
		}
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		Object[][] data = new Object[3][2];
		
		data[0][0] ="1694";
		data[0][1] ="V.I.W.  Vhegzysxn";

		data[1][0] ="76551644";
		data[1][1] ="Dcxgrsqubolnlih";
		
		data[2][0] ="198708629";
		data[2][1] ="Qwvfjh & Pc Cvj Dvqhweg cvhw Qywahto ol Aklwfuxbev";
		
		return data;
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
		//driver.close();
	}
	

}
