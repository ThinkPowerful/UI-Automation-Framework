package com.concord.globalmarkets.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.globalmarkets.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyViewXmlTest extends BaseTest
{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="VerifyViewXmlTest";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("ViewXmlTest",authorName.get("ViewXmlTest"),moduleName.get("ViewXmlTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyViewXmlTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				searchDocumentPage.searchDocumentWithBcNumDocTypeAndDates(data.get("BC Number"), data.get("Document Type"), data.get("From Date"), data.get("To Date"));
				searchDocumentPage.viewBaseDocumentBasedOnDocumentName(data.get("Document Name"));
				searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("//div[@class='spinner']")));
				boolean xmlToolBarVisible = searchDocumentPage.isElementPresent("//div[@id='xmlFileViewBlock']");
				if(xmlToolBarVisible == true)
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("View Xml is working as expected").
					addScreenCaptureFromPath(resultPath);
					Assert.assertEquals(xmlToolBarVisible, true);
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("View Xml is not working as expected").addScreenCaptureFromPath(resultPath);
					Assert.fail("View Xml is not working as expected");
				}
				//driver.switchTo().defaultContent();
				searchDocumentPage.closeDocmentPopup();
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\ConcordTestData.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
