package com.concord.base.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.concord.base.pages.BasePage;
import com.concord.reports.ExtentManager;
import com.concord.utility.Xls_Reader;


public class BaseTest {
	
	public static RemoteWebDriver driver;
	public ExtentReports rep  = ExtentManager.setup();
	public ArrayList<ExtentTest> test =new ArrayList<ExtentTest>();
	public Hashtable<String, String> moduleName=new Hashtable<String, String>();
	public Hashtable<String, String> authorName=new Hashtable<String, String>();
	public static Properties prop = new Properties();
	public InputStream input = null;
	public static String suiteFileName;
	private static final String CHROMIUM_PATH = System.getProperty("user.dir") + "\\chromium\\chrome.exe";
	
	@BeforeSuite
	public static void getSuiteName(ITestContext context){
	   suiteFileName = context.getCurrentXmlTest().getSuite().getName();
		
	}
	
	@BeforeTest
	public void doSetup() throws IOException
	{
		Xls_Reader xls =new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\TestSuite.xlsx");
		int rCount = xls.getRowCount("TestCases");
		for(int rNum=2;rNum<=rCount;rNum++)
		{
			moduleName.put(xls.getCellData("TestCases", 1, rNum),xls.getCellData("TestCases", 2, rNum));
			authorName.put(xls.getCellData("TestCases", 1, rNum),xls.getCellData("TestCases", 3, rNum));
		}

	}
	
	public void init(String testName) throws IOException
	{
		test.add(rep.createTest(testName));
		test.get(0).assignAuthor("Sudheendran");
		test.get(0).assignCategory("Search_Documents_Screen");
		input = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\resources\\config.properties");
		prop.load(input);
	}
	
	public void init(String testName, String author, String testCategory) throws IOException
	{
		System.getProperties().put("http.proxyHost", "nl-proxy-access.net.abnamro.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "nl-proxy-access.net.abnamro.com");
		System.getProperties().put("https.proxyPort", "8080");
		test.add(rep.createTest(testName));
		test.get(0).assignAuthor(author);
		test.get(0).assignCategory(testCategory);
		input = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\resources\\config.properties");
		prop.load(input);
	}
	
	
	public static void openBrowser(String bName) throws MalformedURLException, UnknownHostException
	{
		if(bName.equals("Mozilla"))
		{
			driver = new FirefoxDriver();
			
		}
		else if(bName.equals("Chrome"))
		{
			if(prop.getProperty("EXECUTION").equalsIgnoreCase("Local"))
			{
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\ExeFiles\\chromedriver.exe");
			driver = new ChromeDriver(chromeOptions());
			}
			else
			{
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--incognito");
			DesiredCapabilities caps = DesiredCapabilities.chrome();
			caps.setCapability(ChromeOptions.CAPABILITY, options);
			caps.setCapability("platform", "Windows 10");
			caps.setCapability("build", prop.getProperty("RELEASETEAMBRANCH"));
			caps.setCapability("version", "latest");
			caps.setCapability("parentTunnel", "ABNAMRO_Admin");
			caps.setCapability("tunnelIdentifier", "ipsec-abnamro");
			caps.setCapability("screenResolution", "1280x1024");
			caps.setCapability("maxDuration", 3600);
			caps.setCapability("name", "Concord Regression in: "+prop.getProperty("ENVIRONMENT")+" - "+suiteFileName);
			driver = new RemoteWebDriver(
				    new URL("https://Sudheendran.lakshman:c994d8a1-5284-49e8-bb45-fcad11e7267e@ondemand.eu-central-1.saucelabs.com:443/wd/hub"),caps);
			driver.setFileDetector(new LocalFileDetector());
			}
		}
		else if(bName.equals("ie"))	
		{
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\ExeFiles\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}	
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	
	
	// uncomment the below lines of code is required to execute the scripts on jenkins slave machine or local machine with chromium browser
	
	 private static ChromeOptions chromeOptions() {
        File chromeBinary = new File(CHROMIUM_PATH);
        ChromeOptions options = new ChromeOptions();
        HashMap<String, Object> chromePrefs = new HashMap<>();
        chromePrefs.put("download.default_directory", System.getProperty("user.dir")+"\\ExtentReports\\Snapshots\\DownloadedFiles");
        options.setExperimentalOption("prefs", chromePrefs);
        options.setBinary(chromeBinary.getAbsolutePath());
        options.addArguments("--dns-prefetch-disable");
        options.addArguments("--always-authorize-plugins");
        options.addArguments("--incognito");
        options.addArguments("--window-size=800,600");
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--ignore-ssl-errors");
        options.addArguments("--ssl-protocol=any");
        options.addArguments("--allow-insecure-localhost");
        options.addArguments("--allow-running-insecure-content");
        options.addArguments("--no-sandbox");
        options.addArguments("--v");
        options.addArguments("--disable-setuid-sandbox");
        options.addArguments("--disable-extensions");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--remote-debugging-port=9222");
        options.setExperimentalOption("useAutomationExtension", false);
        return options;
    }
    
	@AfterSuite
	public void flushReport() throws IOException
	{
		rep.flush();
		driver.close();
		BasePage.isApplicationlaunched=false;
		driver=null;
		//driver.quit();
		String killChromeDriver = System.getProperty("user.dir")+"\\BatchFiles\\kill_chromedriver.bat";
		Runtime.getRuntime().exec(killChromeDriver);
	}

}
