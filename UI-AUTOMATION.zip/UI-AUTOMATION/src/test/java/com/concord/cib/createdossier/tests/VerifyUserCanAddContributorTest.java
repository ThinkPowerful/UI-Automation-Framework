package com.concord.cib.createdossier.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.cib.pages.CreateDossierPage;
import com.concord.cib.pages.ImportDocumentPage;
import com.concord.cib.pages.SearchDocumentPage;
import com.concord.cib.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.DateUtil;
import com.concord.utility.Xls_Reader;

public class VerifyUserCanAddContributorTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	CreateDossierPage createDossierPage;
	ImportDocumentPage importDocumentPage;
	String sheetName="UserCanAddContributorTest";
	
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("UserCanAddContributorTest",authorName.get("UserCanAddContributorTest"),moduleName.get("UserCanAddContributorTest"));
				if(driver==null){
					openBrowser("Chrome");
				}
				BasePage.navigateToHomePage(driver);
				this.searchDocumentPage = new SearchDocumentPage(driver);
				this.searchDossierPage = new SearchDossierPage(driver);
				this.createDossierPage= new CreateDossierPage(driver);
				this.importDocumentPage = new ImportDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed: "+e);
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyUserCanAddContributorTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			try {
				SearchDossierPage.navigateToCreateDossierPage();
				createDossierPage.createProtectedProductDossierAndAddContributers(data.get("BC Number"), data.get("Contract Number"), data.get("Product Group"), data.get("Description"), data.get("Contributors"));
				CreateDossierPage.navigateToImportDocumentPage();
				ImportDocumentPage.submitDossierAndDocuments();
				ImportDocumentPage.navigateToSearchDossierScreen();
				searchDossierPage.searchDossierWithBCNumber(data.get("BC Number"), data.get("Dossier Name"), DateUtil.getCurrentdateInddMMyyyyWithHyphen(), DateUtil.getCurrentdateInddMMyyyyWithHyphen());
				searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
				Thread.sleep(5000);
				searchDossierPage.isDossierFound(data.get("Expected Dossier"),DateUtil.getCurrentdateInddMMyyyyWithHyphen());
				String dossier = searchDossierPage.takeScreenshot();
				searchDossierPage.viewMembersOfDossier();
				if(SearchDossierPage.isElementPresent("//h5[contains(text(),'"+ data.get("Contributors")+"')]"))
				{
					String resultPath = searchDossierPage.takeScreenshot();
					test.get(0).info("Members added for the dossier: "+data.get("Expected Dossier")).addScreenCaptureFromPath(dossier);
					test.get(0).pass("Expected Contributor found in the Dossier: "+data.get("Contributors")).addScreenCaptureFromPath(resultPath);
					Assert.assertTrue(true);
				}
				else
				{
					String resultPath = searchDossierPage.takeScreenshot();
					test.get(0).info("Members added for the dossier: "+data.get("Expected Dossier")).addScreenCaptureFromPath(dossier);
					test.get(0).fail("Expected Contributor not found in the Dossier: "+data.get("Contributors")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected Dossier not found in the search result ");
				}
				searchDossierPage.closePopup();
			} 
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\C&IB_NL_Test_Data.xlsx"), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			//driver.quit();
		}

}
