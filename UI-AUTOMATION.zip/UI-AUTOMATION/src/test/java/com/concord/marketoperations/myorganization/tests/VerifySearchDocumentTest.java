package com.concord.marketoperations.myorganization.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.test.BaseTest;
import com.concord.marketsoperations.pages.MyOrgSearchDocumentPage;

import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySearchDocumentTest extends BaseTest{
	
	MyOrgSearchDocumentPage myOrgsearchDocumentPage;
	
	
	String sheetName="MO_MyOrg_SearchDocument";
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("MoSearchDocumentTest",authorName.get("MoSearchDocumentTest"),moduleName.get("MoSearchDocumentTest"));
			openBrowser("Chrome");
			this.myOrgsearchDocumentPage = new MyOrgSearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}
	
	
	@Test(dataProvider="getData")
	public void verifyCreateDocumentTestForMarkets(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			myOrgsearchDocumentPage.searchForDocumentsWithDates(data.get("Search For"), data.get("From Date"), data.get("To Date"));
			if(true)
			{
				String resultPath = myOrgsearchDocumentPage.takeScreenshot();
				test.get(0).pass("Import Document is working as expected: "+data.get("Document Name")).addScreenCaptureFromPath(resultPath);
			}
			else
			{
				String resultPath = myOrgsearchDocumentPage.takeScreenshot();
				test.get(0).fail("Import Document is not working as expected: "+data.get("Document Name")).addScreenCaptureFromPath(resultPath);
			}
			
		}
		catch (Exception e) 
		{
			String resultPath =myOrgsearchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
		
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\Markets_Operations_Test_Data.xlsx"), sheetName);
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		driver.quit();
	}

}
