package com.concord.ctv.importdocument.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.ctv.pages.ImportDocumentPage;
import com.concord.ctv.pages.SearchDocumentPage;
//import com.concord.globalmarkets.pages.CreateDossierPage;
//import com.concord.globalmarkets.pages.SearchDossierPage;
//import com.concord.marketsoperations.pages.SearchDocumentPage;
import com.concord.ctv.pages.SearchDossierPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyMultipleDocumentImportTest extends BaseTest{
	SearchDocumentPage searchDocumentPage;
	SearchDossierPage searchDossierPage;
	ImportDocumentPage importDocumentPage;
	String sheetName = "IDP_MultipleDocumentImport";
	int docCount = 0;

	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException {
		try {
			init("CTVMultipleDocumentImportTest", authorName.get("CTVMultipleDocumentImportTest"),
					moduleName.get("CTVMultipleDocumentImportTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
			this.searchDossierPage = new SearchDossierPage(driver);
			this.importDocumentPage = new ImportDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
	}

	@Test(dataProvider="getData")
	public void verifySingleDocumentImportTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
	{
		try {
			for (String key : data.keySet()) {
				if (key.toLowerCase().startsWith("document name")) {
					docCount = docCount + 1;
				}
			}
			SearchDossierPage.searchDossierWithCTVNumber(data.get("CTV Number"));
			searchDocumentPage.waitForInVisiblityOfElement(driver.findElement(By.xpath("(//div[@ng-if='dossiers.searchObject']//div[@class='spinner'])[1]")));
			searchDocumentPage.navigateToCreateDossierPageForCtv();
			if (docCount != 0) {
				for (int i = 1; i <= docCount; i++) {
					importDocumentPage.importMultipleDocument(data.get("Document Name "+i),data.get("Document Type "+i),data.get("CTV Number"));
				}
			}else {
				String resultPath = importDocumentPage.takeScreenshot();
				test.get(0).fail("Please provide atleast one document as input in the Input Sheet: "+sheetName)
				.addScreenCaptureFromPath(resultPath);
			}
			ImportDocumentPage.submitDossierAndDocuments();
			if (importDocumentPage.isElementPresent("//span[contains(text(),'Document imported successfully')]")) {
				String resultPath = importDocumentPage.takeScreenshot();
				test.get(0).pass("Import Document is working as expected: " + data.get("Document Name 1"))
				.addScreenCaptureFromPath(resultPath);
			} else {
				String resultPath = importDocumentPage.takeScreenshot();
				test.get(0).fail("Import Document is not working as expected: " + data.get("Document Name 1"))
				.addScreenCaptureFromPath(resultPath);
			}
			ImportDocumentPage.navigateToSearchDossierScreen();
		} catch (Exception e) {
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: " + e.getMessage())
			.addScreenCaptureFromPath(resultPath);
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() {
		return DataUtil.loadDataIntoHashTable(
				new Xls_Reader(System.getProperty("user.dir") + "\\ExcelFiles\\Ctv_Test_Data.xlsx"), sheetName);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {
		//driver.quit();
	}

}
