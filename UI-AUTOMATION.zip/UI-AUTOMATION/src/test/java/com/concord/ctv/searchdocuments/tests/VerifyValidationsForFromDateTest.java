package com.concord.ctv.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.ctv.pages.SearchDocumentPage;


public class VerifyValidationsForFromDateTest extends BaseTest{
SearchDocumentPage searchDocumentPage;
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("CTVValidationForFromDateTest",authorName.get("CTVValidationForFromDateTest"),moduleName.get("CTVValidationForFromDateTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed: "+e);
		}
	}
	
	@Test(dataProvider="getData")
	public void verifyInformationMessageTest(String incorrectDate, String validationExpected) throws InterruptedException, AWTException, IOException
	{
		searchDocumentPage.searchDocumentWithCtvNumberDates("987654321", "", "", "", incorrectDate, "24-05-2011");
		try 
		{
			String validationActual = searchDocumentPage.getDateValidationMessage();
			if(searchDocumentPage.isElementPresent("//div[@id='datePicker']//span") && validationActual.equals(validationExpected))
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass(validationExpected+" ,Validation for incorrect date exist: "+incorrectDate).addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(validationActual, validationExpected);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail(validationExpected+" ,Validation for incorrect date does not exist: "+incorrectDate).addScreenCaptureFromPath(resultPath);
				Assert.fail(validationExpected+" ,Validation for incorrect date does not exist: "+incorrectDate);
			}
		} 
		catch (TimeoutException e)
		{
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).fail(validationExpected+" ,Validation for incorrect contract number does not exist: "+incorrectDate).addScreenCaptureFromPath(resultPath);
			Assert.fail(validationExpected+" ,Validation for incorrect contract number does not exist: "+incorrectDate);
		}
		
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		Object[][] data = new Object[3][2];
		
		data[0][0] ="31-31-2018";
		data[0][1] ="This is an invalid date, please type dd-mm-yyyy (in digits)";

		data[1][0] ="abcdefijkl";
		data[1][1] ="This is an invalid date, please type dd-mm-yyyy (in digits)";
		
		data[2][0] ="12-12-2018";
		data[2][1] ="Please select a From date smaller or equal to the To date";
		
		return data;
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}
	

}
