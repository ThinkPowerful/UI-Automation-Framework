package com.concord.ctv.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.pages.BasePage;
import com.concord.base.test.BaseTest;
import com.concord.ctv.pages.SearchDocumentPage;




public class VerifyValidationForCtvNumberTest extends BaseTest {
	
SearchDocumentPage searchDocumentPage;
	
	@BeforeClass
	public void launchApplication() throws InterruptedException, AWTException, IOException
	{
		try {
			init("CTVValidationForCtvNumberTest",authorName.get("CTVValidationForCtvNumberTest"),moduleName.get("CTVValidationForCtvNumberTest"));
			if(driver==null){
				openBrowser("Chrome");
			}
			BasePage.navigateToHomePage(driver);
			this.searchDocumentPage = new SearchDocumentPage(driver);
		} catch (Exception e) {
			test.get(0).skip("@BeforeClass configuration failed");
		}
		
	}
	
	@Test(dataProvider="getData")
	public void verifyValidationsForBCNumberTest(String ctvnumber, String validationExpected) throws InterruptedException, AWTException, IOException
	{
	
		searchDocumentPage.searchDocumentWithOnlyCtvNumber(ctvnumber);
		try 
		{
			String validationActual =searchDocumentPage.getValidationMessage();
			if(searchDocumentPage.isElementPresent("//div[@id='identifierAdministration']//p/span") && validationActual.equals(validationExpected))
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).pass(validationExpected+" Validation for incorrect ctv number exist: "+ctvnumber).addScreenCaptureFromPath(resultPath);
				Assert.assertEquals(validationActual, validationExpected);
			}
			else
			{
				String resultPath = searchDocumentPage.takeScreenshot();
				test.get(0).fail(validationExpected+" Validation for incorrect ctv number does not exist: "+ctvnumber).addScreenCaptureFromPath(resultPath);
				Assert.fail(validationExpected+" Validation for incorrect ctv number does not exist: "+ctvnumber);
			}
		} 
		catch (TimeoutException e)
		{
			String resultPath = searchDocumentPage.takeScreenshot();
			test.get(0).fail(validationExpected+" Validation for incorrect ctv number does not exist: "+ctvnumber).addScreenCaptureFromPath(resultPath);
			Assert.fail(validationExpected+" Validation for incorrect ctv number does not exist: "+ctvnumber);
		}
		
		catch (Exception e) 
		{
			String resultPath =searchDocumentPage.takeScreenshot();
			test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
		}
	}
	
	@DataProvider(name="getData")
	public Object[][] getData() 
	{
		Object[][] data = new Object[3][2];
		
		data[0][0] ="g66$$";
		data[0][1] ="Please use only letters and/or numbers";

		data[1][0] =" ";
		data[1][1] ="Please fill identification number";
		
		data[2][0] ="123456789188";
		data[2][1] ="A CTV number should consist of maximum 10 digits";
		
		
		return data;
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws IOException
	{
		//driver.quit();
	}


}
