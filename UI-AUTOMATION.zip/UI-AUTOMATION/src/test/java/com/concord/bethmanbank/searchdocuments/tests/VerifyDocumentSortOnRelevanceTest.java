package com.concord.bethmanbank.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.test.BaseTest;
import com.concord.bethmanbank.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifyDocumentSortOnRelevanceTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="SDP_ValidationsForAdvanceSearch";
		
		@BeforeClass	
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("DocumentSortOnRelevanceTest",authorName.get("DocumentSortOnRelevanceTest"),moduleName.get("DocumentSortOnRelevanceTest"));
				openBrowser("Chrome");
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyDocumentSortOnRelevanceTest(Hashtable<String, String> data) throws InterruptedException
		{
			try {
				System.out.println("Test");
				searchDocumentPage.filterDocumentsWithAdvanceSearch("Customer Number", "290882", "Account Report", "Concord", "", "06-09-2000", "05-12-2018", "adv", "", "", "", "", "");
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\"+prop.getProperty("BETHMAN_BANK_TEST_DATA")), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			driver.quit();
		}

}
