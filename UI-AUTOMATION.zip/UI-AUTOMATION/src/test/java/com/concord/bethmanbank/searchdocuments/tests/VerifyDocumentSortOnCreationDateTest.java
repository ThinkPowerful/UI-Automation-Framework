package com.concord.bethmanbank.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Hashtable;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.test.BaseTest;
import com.concord.bethmanbank.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.DateUtil;
import com.concord.utility.Xls_Reader;

public class VerifyDocumentSortOnCreationDateTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="SDP_DocumentSortOnCreationDate";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("DocumentSortOnCreationDateTest",authorName.get("DocumentSortOnCreationDateTest"),moduleName.get("DocumentSortOnCreationDateTest"));
				openBrowser("Chrome");
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifyDocumentSortOnCreationDateTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, ParseException
		{
			try {
				searchDocumentPage.SearchDocumentsWithOnlyCustomerNumber(data.get("Customer Number"), data.get("From Date"), data.get("To Date"));
				switch (data.get("Sorting Order"))
				{
				case "Ascending":
					searchDocumentPage.sortDocumentsBasedOnCreationDate("Ascending");
					List<String> creationDatesAsc = searchDocumentPage.getAllValuesFromaAttributeInSearchResults("Created on");
					boolean isDateSortedinAscendingOrder = true;
					for(int i=0;i<creationDatesAsc.size()-1;i++)
					{
						isDateSortedinAscendingOrder = DateUtil.compareDatesAscending(creationDatesAsc.get(i), creationDatesAsc.get(i+1));
						if(isDateSortedinAscendingOrder==false)
						{
							String resultPath = searchDocumentPage.takeScreenshot();
							test.get(0).fail("Document Sort in ascending order is not successfull").addScreenCaptureFromPath(resultPath);
							Assert.fail("Document Sort in ascending order is not successfull");
							break;
						}
					}
					if(isDateSortedinAscendingOrder==true)
					{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("Document Sorted in ascending Order successfully").addScreenCaptureFromPath(resultPath);
					Assert.assertTrue(isDateSortedinAscendingOrder);
					}
					break;
					
				case "Descending":
					searchDocumentPage.sortDocumentsBasedOnCreationDate("Descending");
					List<String> creationDatesDesc = searchDocumentPage.getAllValuesFromaAttributeInSearchResults("Created on");
					boolean isDateSortedinDecendingOrder = true;
					for(int i=0;i<creationDatesDesc.size()-1;i++)
					{
						isDateSortedinDecendingOrder = DateUtil.compareDatesDescending(creationDatesDesc.get(i), creationDatesDesc.get(i+1));
						if(isDateSortedinDecendingOrder==false)
						{
							String resultPath = searchDocumentPage.takeScreenshot();
							test.get(0).fail("Document Sort in descending order is not successfull").addScreenCaptureFromPath(resultPath);
							Assert.fail("Document Sort in descending order is not successfull");
							break;
						}
					}
					if(isDateSortedinDecendingOrder==true)
					{
						String resultPath = searchDocumentPage.takeScreenshot();
						test.get(0).pass("Document Sorted in descending Order successfully").addScreenCaptureFromPath(resultPath);
						Assert.assertTrue(isDateSortedinDecendingOrder);
					}
					break;
				}
			}
			catch (Exception e) 
			{
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
			
			
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\"+prop.getProperty("BETHMAN_BANK_TEST_DATA")), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			driver.quit();
		}

}
