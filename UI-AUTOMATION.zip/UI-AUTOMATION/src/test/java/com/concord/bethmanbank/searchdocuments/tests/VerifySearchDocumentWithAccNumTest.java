package com.concord.bethmanbank.searchdocuments.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.concord.base.test.BaseTest;
import com.concord.bethmanbank.pages.SearchDocumentPage;
import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class VerifySearchDocumentWithAccNumTest extends BaseTest{
	
	SearchDocumentPage searchDocumentPage;
	String sheetName="SDP_SearchDocumentWithAccNum";
		
		@BeforeClass
		public void launchApplication() throws InterruptedException, AWTException, IOException
		{
			try {
				init("SearchDocumentWithAccNumTest",authorName.get("SearchDocumentWithAccNumTest"),moduleName.get("SearchDocumentWithAccNumTest"));
				openBrowser("Chrome");
				this.searchDocumentPage = new SearchDocumentPage(driver);
			} catch (Exception e) {
				test.get(0).skip("@BeforeClass configuration failed");
			}
		}
		
		
		@Test(dataProvider="getData")
		public void verifySearchDocumentWithAccNumTest(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException
		{
			
			try {
				searchDocumentPage.SearchDocumentsWithOnlyAccountNumber(data.get("Account Number"), data.get("From Date"), data.get("To Date"));
				boolean documentFound = searchDocumentPage.isDocumentPresentInSearchResults(data.get("Expected Document Name"), data.get("Expected Document ID"));
				if(documentFound){
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).pass("Expected document found in the search results: "+data.get("Expected Document Name")+" , "+data.get("Expected Document ID")).addScreenCaptureFromPath(resultPath);
					Assert.assertTrue(documentFound);
				}
				else
				{
					String resultPath = searchDocumentPage.takeScreenshot();
					test.get(0).fail("Expected document not found in the search results: "+data.get("Expected Document Name")+" , "+data.get("Expected Document ID")).addScreenCaptureFromPath(resultPath);
					Assert.fail("Expected document not found in the search results: "+data.get("Expected Document Name")+" , "+data.get("Expected Document ID"));
				}
			} catch (Exception e) {
				String resultPath =searchDocumentPage.takeScreenshot();
				test.get(0).skip("Skipping the test due to an exception: "+e.getMessage()).addScreenCaptureFromPath(resultPath);
			}
			
		}
		
		@DataProvider(name="getData")
		public Object[][] getData() 
		{
			return DataUtil.loadDataIntoHashTable(new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\"+prop.getProperty("BETHMAN_BANK_TEST_DATA")), sheetName);
		}
		
		@AfterClass(alwaysRun=true)
		public void tearDown() throws IOException
		{
			driver.quit();
		}
	

}
