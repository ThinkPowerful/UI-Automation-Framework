/*package only.learning;

import lotus.domino.NotesThread;

public class EmailReport extends NotesThread{

	String host,username,password;
	
	@Test
	public void main() throws NotesException
	{
		Session dominoSession = NotesFactory.createSession( "NLAMSM221/SRV/ABNAMRO/NL", "sudheendran.lakshman@nl.abnamro.com", "Xafasp2rak" );
		System.out.println("USER Detail : "+dominoSession.getUserName());
	    //Database dominoDb = dominoSession.getDatabase( host, mailbox );
		
	}
	
	
	public static void main(String argv[])    
    {    
		EmailReport t = new EmailReport();        
        t.start();        
            }            
            public void runNotes() // entry point for Notes thread            
            {            
            try            
                {                
                    Session s = NotesFactory.createSession();                
                    // Operational code goes here                
                }                
                catch (Exception e)
            {            
                e.printStackTrace();
        }
		System.out.println(System.getProperty("sun.arch.data.model"));
    }
	
}
*/