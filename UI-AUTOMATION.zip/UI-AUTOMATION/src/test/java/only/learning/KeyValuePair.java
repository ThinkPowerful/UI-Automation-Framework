package only.learning;

import java.util.Hashtable;

import org.testng.annotations.Test;

import com.concord.utility.DataUtil;
import com.concord.utility.Xls_Reader;

public class KeyValuePair {
	
	
	public static Object[][] loadTestNamesIntoHashTable(Xls_Reader xls, String sheetName)
	{
		int rCount = xls.getRowCount(sheetName);
		System.out.println("Row Count: "+rCount);
		int cCount = xls.getColumnCount(sheetName);
		System.out.println("Coloumn Count: "+cCount);
		Object[][] data = new Object[cCount-1][1];
		int index = 0;
		Hashtable<String, String> table=null;
		//for(int rNum=2;rNum<=rCount;rNum++)
		for(int cNum=2;cNum<=cCount;cNum++)
		{
			table=new Hashtable<String, String>();
			//for(int cNum=0;cNum<=cCount;cNum++)
			for(int rNum=0;rNum<=rCount;rNum++)
			{
				//String key = xls.getCellData(sheetName, cNum, 1);
				String key = xls.getCellData(sheetName, rNum, 1);
				System.out.println(key);
				String value = xls.getCellData(sheetName, cNum, rNum);
				//String value = xls.getCellData(sheetName, rNum, cNum);
				System.out.println(value);
				table.put(key, value);
			}
			data[index][0] = table;
			index++;
		}
		
		return data;
		
	}

	@Test
	public void main()
	{
		Xls_Reader xls =new Xls_Reader("C:\\Users\\C47273\\workspace\\concordautomation\\ExcelFiles\\Dummy.xlsx");
		//System.out.println(getData());
		Hashtable<String, String> moduleName=new Hashtable<String, String>();
		Hashtable<String, String> authorName=new Hashtable<String, String>();
		int rCount = xls.getRowCount("sheet1");
		int cCount = xls.getColumnCount("sheet1");
		for(int rNum=2;rNum<=rCount;rNum++)
		{
			//for(int cNum=0;cNum<=cCount;cNum++)
			//{
			moduleName.put(xls.getCellData("sheet1", 0, rNum),xls.getCellData("sheet1", 1, rNum));
			authorName.put(xls.getCellData("sheet1", 0, rNum),xls.getCellData("sheet1", 2, rNum));
			//System.out.println(table.get(xls.getCellData("sheet1", 0, rNum)));
			//}
		}
		System.out.println(moduleName.get("Test4"));
		System.out.println(authorName.get("Test4"));
		
		
		
		
	}
	
	public static Object[][] getData() 
	{
		return loadTestNamesIntoHashTable(new Xls_Reader("C:\\Users\\C47273\\workspace\\concordautomation\\ExcelFiles\\Dummy.xlsx"), "Sheet1");
	}
}
