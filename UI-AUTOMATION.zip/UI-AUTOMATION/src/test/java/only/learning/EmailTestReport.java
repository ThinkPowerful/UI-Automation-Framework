/*package only.learning;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.testng.annotations.Test;

public class EmailTestReport {
	
	Properties props = new Properties();
	//Authenticator auth;
	
	@Test
	public void sendTestReport()
	{
	props.put("mail.smtp.host", "NLAMSM221/SRV/ABNAMRO/NL");
	//props.put("mail.smtp.socketFactory.port", "465");
	//props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
	props.put("mail.smtp.auth", "true");
	props.put("mail.smtp.port", "25");
	props.put("mail.from", "sudheendran.lakshman@nl.abnamro.com");
    props.put("mail.smtp.starttls.enable", "true");
	
	
	// This will handle the complete authentication
		Session session = Session.getDefaultInstance(props,new Authenticator()
		{
			protected PasswordAuthentication getPasswordAuthentication() 
			{
			return new PasswordAuthentication("sudheendran.lakshman@nl.abnamro.com", "Xafasp2rak");
			}
		});
		
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("sudheendran.lakshman@nl.abnamro.com"));
			message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("sudheendran.lakshman@nl.abnamro.com"));
			message.setSubject("Testing Subject");
			BodyPart messageBodyPart1 = new MimeBodyPart();
			messageBodyPart1.setText("This is message body");
			//MimeBodyPart messageBodyPart2 = new MimeBodyPart();
			//String filename = "C:\\Users\\C47273\\workspace\\concordautomation\\testng.xml";
			//DataSource source = new FileDataSource(filename);
			//messageBodyPart2.setDataHandler(new DataHandler(source));
			//messageBodyPart2.setFileName(filename);
			Multipart multipart = new MimeMultipart();
			//multipart.addBodyPart(messageBodyPart2);
			multipart.addBodyPart(messageBodyPart1);
			message.setContent(multipart);
			Transport.send(message);
			System.out.println("=====Email Sent=====");
		}
		catch (MessagingException e) 
		{
			throw new RuntimeException(e);
		}
	}
	
}
*/