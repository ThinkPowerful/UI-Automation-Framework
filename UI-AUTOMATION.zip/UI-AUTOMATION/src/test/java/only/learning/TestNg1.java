package only.learning;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import com.concord.utility.SMSessionCreator;

public class TestNg1 extends BaseTestNG
{
	
	@Test
	public void verifyKeyMatchSearchTests() throws InterruptedException
	{
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--dns-prefetch-disable");
        options.addArguments("--always-authorize-plugins");
        options.addArguments("--incognito");
        options.addArguments("--window-size=800,600");
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--ignore-ssl-errors");
        options.addArguments("--ssl-protocol=any");
        options.addArguments("--allow-insecure-localhost");
        options.addArguments("--allow-running-insecure-content");
        options.addArguments("--no-sandbox");
        options.addArguments("--v");
        options.addArguments("--disable-setuid-sandbox");
        options.addArguments("--disable-extensions");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--remote-debugging-port=9222");
        options.setExperimentalOption("useAutomationExtension", false);

        System.setProperty("webdriver.chrome.driver","C:\\Users\\C47273\\Xen Desktop\\Workspaces\\concordautomation\\ExeFiles\\chromedriver.exe");
		WebDriver driver=new ChromeDriver(options);
		driver.get("http://vm400016310.nl.eu.abnamro.com:12867/");
		//driver.get("http://s05ast0058-c03.nl.eu.abnamro.com:14691/");
		Cookie ck = null;
		ck = new Cookie("SMSESSION", SMSessionCreator.employeeSession("e52235", "testen#1", "launcherq","ET"),".nl.eu.abnamro.com","/", null);
		System.out.println(ck);
		driver.manage().addCookie(ck);
		driver.navigate().refresh();
		Thread.sleep(3000);
		driver.get("http://vm400016310.nl.eu.abnamro.com:12867/eacu/adminconsoleIntranet");
		//driver.get("http://s05ast0058-c03.nl.eu.abnamro.com:14691/gdc/web/client/documents");
		driver.manage().addCookie(ck);

	}
	
}
