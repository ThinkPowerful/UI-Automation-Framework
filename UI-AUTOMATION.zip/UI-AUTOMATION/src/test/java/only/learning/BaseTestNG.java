package only.learning;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.concord.reports.ExtentManager;
import com.concord.utility.Xls_Reader;


public class BaseTestNG 
{
	public Hashtable<String, String> moduleName= new Hashtable<String, String>();
	public Hashtable<String, String> authorName= new Hashtable<String, String>();
	public ExtentReports rep  = ExtentManagerDummy.setup();
	public ArrayList<ExtentTest> test =new ArrayList<ExtentTest>();
	
	@BeforeSuite
	public void startSeleniumServer() throws IOException
	{
		Runtime.getRuntime().exec("C:\\Users\\C47273\\Synergy\\Artifacts\\StartSeleniumServer.bat");
	}
	
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("Before Test method");
		/*System.out.println("beforeClass");
		Xls_Reader xls =new Xls_Reader(System.getProperty("user.dir")+"\\ExcelFiles\\TestSuite.xlsx");
		int rCount = xls.getRowCount("TestCases");
		//this.moduleName = new Hashtable<String, String>();
		//this.authorName = new Hashtable<String, String>();
		for(int rNum=2;rNum<=rCount;rNum++)
		{
			this.moduleName.put(xls.getCellData("TestCases", 1, rNum),xls.getCellData("TestCases", 2, rNum));
			this.authorName.put(xls.getCellData("TestCases", 1, rNum),xls.getCellData("TestCases", 3, rNum));
		}*/
	}
	
	public void init(String testName)
	{
		test.add(rep.createTest(testName));
		test.get(0).assignAuthor("Sudheendran");
		test.get(0).assignCategory("Search_Documents_Screen");
	}
	
	public void init(String testName, String author, String testCategory)
	{
		test.add(rep.createTest(testName));
		test.get(0).assignAuthor(author);
		test.get(0).assignCategory(testCategory);
	}
	
	@AfterSuite
	public void afterSuite()
	{
		System.out.println("After Suite");
		rep.flush();
	}

}
