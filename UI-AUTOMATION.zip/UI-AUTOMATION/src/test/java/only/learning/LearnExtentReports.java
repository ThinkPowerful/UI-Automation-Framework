package only.learning;

import java.io.IOException;

import org.testng.annotations.Test;

import com.concord.base.test.BaseTest;

public class LearnExtentReports extends BaseTest
{
	@Test
	public void main() 
	{
		System.out.println("Test");
		//init("test1");
		test.get(0).pass("Passed");
	}
}
